"""Unit tests of the output checks, the consensus weighting and the schema helpers.
No model, parser or benchmark data needed:  python -m pytest tests/"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import docquorum  # noqa: F401  (puts the package modules on sys.path)
import conform
import dupcap
import emptyrows
import extract
import medoidroute
import pagegrid
import typosnap
import xarray


def test_conform_fills_only_nullable_fields():
    schema = {"type": "object", "properties": {
        "a": {"type": ["string", "null"]}, "b": {"type": "string"},
        "rows": {"type": "array", "items": {"type": "object", "properties": {
            "x": {"type": ["number", "null"]}, "y": {"type": ["string", "null"]}}}}}}
    out = conform.conform_record({"b": "B", "rows": [{"x": 1}]}, schema)
    assert out["a"] is None and "b" in out and out["rows"][0] == {"x": 1, "y": None}
    assert "missing" not in out


def test_emptyrows_drops_label_only_rows():
    rows = [{"type": "Surface", "size": "9-5/8", "depth": "2823", "cement": "H"},
            {"type": "Intermediate", "size": None, "depth": None, "cement": None},
            {"type": "Long String", "size": "5-1/2", "depth": "7100", "cement": "H"}]
    stat = {"dropped": 0}
    out = emptyrows.strip({"casing": rows}, stat)
    assert [r["type"] for r in out["casing"]] == ["Surface", "Long String"] and stat["dropped"] == 1


def test_xarray_removes_cross_field_copies_but_keeps_aggregates():
    checks = [{"check_number": f"0103398{i}", "amount": f"70{i}.88", "vendor": f"V{i}"} for i in range(4)]
    batches = [{"batch_year": "26", "batch_number": c["check_number"], "amount": c["amount"]} for c in checks]
    stat = []
    out = xarray.clean({"checks": list(checks), "batches": batches}, stat)
    assert out["batches"] == [] and stat
    lines = [{"vendor_name": f"Vendor {i}", "amount": f"1{i}0.00", "memo": f"item {i}"} for i in range(4)]
    subtotals = [{"vendor_name": l["vendor_name"], "amount": l["amount"]} for l in lines]
    stat = []
    out = xarray.clean({"line_items": lines, "vendor_subtotals": subtotals}, stat)
    assert len(out["vendor_subtotals"]) == 4 and not stat      # same-named fields: legitimate


def test_dupcap_caps_identical_records_at_printed_count():
    pages = [dupcap.norm("NAME ON FILE ADDRESS ON FILE\n" * 2), dupcap.norm("NAME ON FILE ADDRESS ON FILE\n")]
    row = {"name": "NAME ON FILE", "address": "ADDRESS ON FILE", "source_page": 1}
    rows = [dict(row) for _ in range(5)]
    stat = {"dropped": 0, "moved": 0}
    out = dupcap.cap_array(rows, "source_page", pages, stat)
    assert len(out) == 3 and stat["moved"] == 1 and stat["dropped"] == 2   # 2 on page 1, 1 moved to page 2


def test_typosnap_copies_only_the_page_quotes():
    page = typosnap.Page(["Minimum education: Bachelor’s degree f rom an accredited college"])
    assert page.render("Bachelor's degree from an accredited college") == \
        "Bachelor’s degree from an accredited college"          # kerning split not copied


def test_pagegrid_folio_smoothing():
    raw = {2: 1, 3: 2, 4: 3, 6: 5, 7: 6, 21: 2, 20: 19, 22: 21}
    sm = pagegrid.smooth_folios(raw, 22)
    assert sm[5] == 4 and sm[21] == 20                                   # gap filled, stray '2' fixed


def test_pagegrid_monotone_assignment_uses_neighbours():
    votes = [{1: 2.0}, {}, {2: 1.0}, {1: 0.4, 3: 1.0}]
    seq = pagegrid.monotone_assign(votes, 3)
    assert seq == sorted(seq)                               # document order: pages never go back
    assert (seq[0], seq[2], seq[3]) == (1, 2, 3)            # rows with evidence land on their page
    assert seq[1] in (1, 2)                                 # a row without evidence joins a neighbour


def test_consensus_weighting_is_recall_heavy():
    assert medoidroute.fbeta(0.5, 1.0, 2) > medoidroute.fbeta(1.0, 0.5, 2)
    assert medoidroute.fbeta(0.0, 1.0, 2) == 0.0


def test_template_round_trip():
    t = {"name": "", "items": [{"nm": "", "price": ""}], "total": {"amount": ""}}
    assert extract.is_template(t) and not extract.is_template({"type": "object", "properties": {}})
    s = extract.to_schema(t)
    assert s["properties"]["items"]["items"]["properties"]["price"]["type"] == ["string", "null"]
    out = extract.to_template({"name": "Cafe", "items": [{"nm": "tea", "price": None}]}, t)
    assert out == {"name": "Cafe", "items": [{"nm": "tea", "price": ""}], "total": {"amount": ""}}


def test_numsnap_restores_the_printed_figure():
    import numsnap
    num = {"type": "object", "properties": {"net_income": {"type": ["number", "null"]},
                                            "ebitda": {"type": ["number", "null"]},
                                            "wells": {"type": ["integer", "null"]},
                                            "margin": {"type": ["number", "null"]}}}
    text = "Net income $26.1 million ... 26,107 ... Adjusted EBITDA $7.7B ... 7,681 ... 3 wells ... 39.1%"
    out, log = numsnap.fix(num, {"net_income": 26.11, "ebitda": 7700, "wells": 3, "margin": 39.06}, text)
    assert out["net_income"] == 26.107 and out["ebitda"] == 7681      # roundings of printed figures
    assert out["wells"] == 3 and out["margin"] == 39.06                # integer field; not a rounding
    out, _ = numsnap.fix(num, {"net_income": 26.11}, "26,107 and 26,114")
    assert out["net_income"] == 26.11                                   # two candidates: no snap
    out, _ = numsnap.fix(num, {"net_income": 26.11}, "26.11 ... 26,107")
    assert out["net_income"] == 26.11                                   # printed as is: no snap


def test_require_all_makes_added_requirements_nullable():
    import pipeline
    s = {"type": "object", "required": ["a"], "properties": {
        "a": {"type": "string"}, "b": {"type": "string"}, "e": {"enum": ["X", "Y"]},
        "rows": {"type": "array", "items": {"type": "object", "properties": {"x": {"type": "number"}}}}}}
    t = pipeline.require_all(s)
    assert t["required"] == ["a", "b", "e", "rows"] and t["properties"]["a"]["type"] == "string"
    assert t["properties"]["b"]["type"] == ["string", "null"] and None in t["properties"]["e"]["enum"]
    assert t["properties"]["rows"]["items"]["required"] == ["x"]
    assert s["properties"]["b"]["type"] == "string"                     # the input is not modified


def test_conform_writes_the_declared_default_for_an_empty_list():
    schema = {"type": "object", "properties": {
        "codes": {"anyOf": [{"type": "array", "items": {"type": "string"}}, {"type": "null"}], "default": None},
        "rows": {"type": "array", "items": {"type": "string"}}}}
    out = conform.conform_record({"codes": [], "rows": []}, schema)
    assert out["codes"] is None and out["rows"] == []        # only a list whose default is null


def test_conform_keeps_output_schema_valid():
    # a null in an optional property that does not admit null is dropped; a missing required
    # object is added empty (its own required list too); null items leave a list of strings
    schema = {"type": "object", "required": ["meta", "income"], "properties": {
        "meta": {"type": "object", "properties": {"email": {"type": "string"},
                                                  "phone": {"type": ["string", "null"]}}},
        "income": {"$ref": "#/$defs/Income"},
        "tags": {"type": "array", "items": {"type": "string"}}},
        "$defs": {"Income": {"type": "object", "required": ["revenue"], "properties": {
            "revenue": {"type": "array", "items": {"type": "number"}}}}}}
    out = conform.conform_record({"meta": {"email": None, "phone": None}, "tags": ["a", None]}, schema)
    assert out["meta"] == {"phone": None}
    assert out["income"] == {"revenue": []}
    assert out["tags"] == ["a"]


def test_text_windows_cover_every_page_once_within_budget():
    import wholedoc
    pages = ["x" * 30000] * 7 + ["y" * 90000] + ["z" * 1000] * 5
    wins = wholedoc.text_windows_of(pages, budget_tokens=60000)
    covered = [p for a, b in wins for p in range(a, b + 1)]
    assert covered == list(range(1, len(pages) + 1))
    assert all(sum(len(t) for t in pages[a - 1:b]) <= 60000 * 3 for a, b in wins)
    assert len(wins) == 2
