#!/bin/bash
# Consensus over several prepared readings of the same split: per document, the reading that
# agrees most with the others (recall-weighted agreement, beta = 2, measured with the
# benchmark's own scorer). Tie-break order = the order the readings are given in.
#
#   benchmarks/extractbench/consensus.sh <split> <out_dir> <reading_dir> [<reading_dir> ...]
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"; PKG="$HERE/../../docquorum"
PY=${DQ_PYTHON:-python}
S=$1; OUT=$2; shift 2
READINGS=$(IFS=,; echo "$*")
EB_SPLIT=$S CONSENSUS_BETA=${CONSENSUS_BETA:-2} $PY "$PKG/medoidroute.py" "$READINGS" "$READINGS" "$OUT" > /dev/null
echo "consensus: $# readings -> $OUT ($(ls "$OUT"/*.json | grep -vc _medoid) documents)"
