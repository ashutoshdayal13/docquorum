"""Documents without a text layer, from the documents themselves (no annotation).

    python scans.py <split>                      line 1: every such document; line 2: those of
                                                 <= 12 pages (they fit one call)
    python scans.py --copy <src> <dst> <a,b,..>  copy those documents' readings from src to dst
"""
import json
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "docquorum"))
import settings as S  # noqa: E402
import imgview  # noqa: E402

MAX_ONE_CALL_PAGES = 12


def scans(split):
    every, short = [], []
    for line in open(S.DATA / f"{split}.jsonl"):
        if not line.strip():
            continue
        r = json.loads(line)
        pdf = S.DATA / "docs" / r["pdf"].replace("docs/", "", 1)
        n = imgview.npages(pdf)
        text = subprocess.run([S.PDFTOTEXT, str(pdf), "-"], capture_output=True, text=True).stdout
        if len(text.strip()) < 50 * max(1, n):
            every.append(r["id"].split("/")[-1])
            if n <= MAX_ONE_CALL_PAGES:
                short.append(r["id"].split("/")[-1])
    return every, short


if __name__ == "__main__":
    if sys.argv[1] == "--copy":
        src, dst = Path(sys.argv[2]), Path(sys.argv[3])
        for d in sys.argv[4].split(","):
            if (src / f"{d}.json").exists():
                shutil.copy(src / f"{d}.json", dst)
    else:
        every, short = scans(sys.argv[1])
        print(",".join(every))
        print(",".join(short))
