"""Score a run directory with ExtractBench's own scorer. Run with ./ebenv/bin/python."""
import sys as _sys
from pathlib import Path as _P
_sys.path.insert(0, str(_P(__file__).resolve().parents[2] / "docquorum"))   # the pipeline package
import os
import argparse
import json
from pathlib import Path

import ebscore

# published long-split value F1 (ExtractBench paper / leaderboard), for reference
PUBLISHED_LONG = [
    # Long-split column of eb_repo/leaderboard.csv (read directly, 2026-09-25). An earlier
    # version of this list had LlamaExtract Agentic Plus at 94.4; the leaderboard says 90.18.
    ("Pulse (Effort), commercial", 93.51),
    ("Reducto Deep Extract, commercial", 92.01),
    ("LlamaExtract Agentic, commercial", 91.83),
    ("Extend (Max Context), commercial", 90.46),
    ("LlamaExtract Agentic Plus, commercial", 90.18),
    ("Claude Code (Opus 4.8), coding agent", 88.07),
    ("Codex (GPT-5.5 Evidence), coding agent", 87.97),
    ("Codex (GPT-5.5), coding agent", 78.88),
    ("best open-weight (Qwen3.8 27B)", 38.45),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--only", default="", help="comma-separated case names")
    ap.add_argument("--json", default="", help="also write per-case {name: [f1, p, r]} here")
    args = ap.parse_args()
    d = Path(args.run)
    recs = {r["id"].split("/")[-1]: r for r in ebscore.load_records(os.environ.get("EB_SPLIT", "long"))}
    if args.only:
        keep = set(args.only.split(","))
        recs = {k: v for k, v in recs.items() if k in keep}
    rows = []
    for name, rec in recs.items():
        f = d / (name + ".json")
        if not f.exists():
            continue
        pred = json.loads(f.read_text())
        m = ebscore.score(rec, pred)["metrics"]
        rows.append((name, m.get("extract_unified_value_f1", 0.0),
                     m.get("extract_unified_value_precision", 0.0),
                     m.get("extract_unified_value_recall", 0.0)))
    if not rows:
        print("no predictions found")
        return
    print(f"{'case':44s} {'f1':>7s} {'prec':>7s} {'recall':>7s}")
    for n, f1, p, r in sorted(rows):
        print(f"{n[:44]:44s} {100*f1:7.2f} {100*p:7.2f} {100*r:7.2f}")
    if args.json:
        Path(args.json).write_text(json.dumps({n: [f1, p, r] for n, f1, p, r in rows}, indent=1))
    mf1 = 100 * sum(x[1] for x in rows) / len(rows)
    mp = 100 * sum(x[2] for x in rows) / len(rows)
    mr = 100 * sum(x[3] for x in rows) / len(rows)
    print(f"\n{'MEAN over ' + str(len(rows)) + ' cases':44s} {mf1:7.2f} {mp:7.2f} {mr:7.2f}")
    # The comparison list is the LONG column; printing it under a short or medium run made
    # every medium score look like it beat the long-split leaders.
    if len(rows) < len(recs):
        print(f"\n(partial run: {len(rows)}/{len(recs)} cases -- not comparable to published means)")
    elif not args.only and os.environ.get("EB_SPLIT", "long") == "long":
        print("\npublished long-split value F1:")
        for nm, v in PUBLISHED_LONG:
            mark = "  <-- we beat this" if mf1 > v else ""
            print(f"  {nm:38s} {v:6.1f}{mark}")


if __name__ == "__main__":
    main()
