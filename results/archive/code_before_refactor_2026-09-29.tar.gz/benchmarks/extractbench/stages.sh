#!/bin/bash
# The output stages every reading passes through before consensus:
#   conform   -- every schema property present; null where the schema admits null
#   boolblank -- a blank check box is false where the field's description says so
#   emptyrows -- drop template rows (only the printed row label filled)
#   xarray    -- drop rows one array copied from another (a printed line is one record)
#   dupcap    -- copies of an identical record capped at what the text layer prints
#   pagegrid  -- printed page numbers located from the document's own text
#   typosnap  -- quotes/apostrophes as the page prints them
#   numsnap   -- a rounded or rescaled figure replaced by the one printed figure it restates
#
#   benchmarks/extractbench/stages.sh <split> <in_dir> <out_dir>     (absolute or relative dirs)
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"; PKG="$HERE/../../docquorum"
PY=${DQ_PYTHON:-python}
S=$1; IN=$2; OUT=$3
export EB_SPLIT=$S
T="$OUT.__stages"; rm -rf "$T"; mkdir -p "$T"
$PY "$PKG/conform.py"   "$IN"       "$T/c0"  > /dev/null
$PY "$PKG/boolblank.py" "$T/c0"     "$T/c"   > /dev/null
$PY "$PKG/emptyrows.py" "$T/c"      "$T/ce"  > /dev/null
$PY "$PKG/xarray.py"    "$T/ce"     "$T/cx"  > /dev/null
$PY "$PKG/dupcap.py"    "$T/cx"     "$T/cd"  > /dev/null
$PY "$PKG/pagegrid.py"  "$T/cd"     "$T/cp"  > /dev/null
$PY "$PKG/typosnap.py"  "$T/cp"     "$T/ct"  > /dev/null
$PY "$PKG/numsnap.py"   "$T/ct"     "$OUT"   > /dev/null
rm -rf "$T"
[ -f "$IN/_medoid.json" ] && cp "$IN/_medoid.json" "$OUT/" || true
echo "stages: $(basename "$IN") -> $OUT ($(ls "$OUT"/*.json | grep -vc _medoid) documents)"
