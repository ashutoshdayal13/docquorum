#!/bin/bash
# Run DocQuorum end to end on an ExtractBench split (fresh model calls) and score it.
#
#   benchmarks/extractbench/run.sh <short|medium|long> [doc_workers]
#
# Needs: the extraction model served at $DQ_LLM_URL (serve/serve_qwen38_27b.sh), the MinerU
# parser at $DQ_PARSER_URL for scans (serve/serve_mineru.sh; parses are cached in
# cache/parse), ExtractBench's data at data/extractbench. Outputs go to $DQ_RUNS (runs/).
#
# The rule (RESULTS section 14), one rule for both benchmarks:
#   * a document that carries a text layer (born-digital, or a scan with an OCR layer) is read
#     once, by the agentic reader on its text and page images;
#   * a document WITHOUT a text layer is read through its MinerU parse (OCR text + page images,
#     pairs of pages side by side for 13-24 pages); when it fits one call (<= 12 pages) it is
#     also read from the page images alone and by the one-shot reader, and the quorum keeps
#     the reading the others agree with most (UNIKIE's images are all of this kind).
# Layout readers (column flow, ruled scans) replace the reading where the document's own
# layout evidence selects them. Every reading passes the repairs and the output stages
# (benchmarks/extractbench/stages.sh).
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"; ROOT="$HERE/../.."; PKG="$ROOT/docquorum"
PY=${DQ_PYTHON:-python}
S=$1; DW=${2:-8}
export EB_SPLIT=$S EB_GUIDED=1 EB_NOTHINK=1 EB_WHOLE=1 DQ_RUNS=${DQ_RUNS:-$ROOT/runs}
R=$DQ_RUNS; mkdir -p "$R" "$ROOT/logs"
cd "$ROOT"

echo "[1/4] primary reading (text layer + page images; page images alone for scans)"
$PY "$PKG/agentic.py" --tag ${S}_primary --workers 8 --doc-workers $DW > logs/${S}_primary.log 2>&1
"$HERE/prep.sh" $S primary "$R/${S}_primary" "$R/${S}_primary_final"
rm -rf "$R/${S}_final"; cp -r "$R/${S}_primary_final" "$R/${S}_final"

# documents without a text layer: all of them (SCANS) and those that fit one call (IMG)
$PY "$HERE/scans.py" "$S" > "$R/${S}_scans.txt"
SCANS=$(sed -n 1p "$R/${S}_scans.txt"); IMG=$(sed -n 2p "$R/${S}_scans.txt")
if [ -n "$SCANS" ]; then
  echo "[2/4] parse reading for $(echo "$SCANS" | tr ',' '\n' | wc -l) documents without a text layer"
  $PY "$PKG/agentic.py" --tag ${S}_parse --parsed --only "$SCANS" --workers 8 --doc-workers $DW > logs/${S}_parse.log 2>&1
  "$HERE/prep.sh" $S parse "$R/${S}_parse" "$R/${S}_parse_final"
  cp "$R/${S}_parse_final"/*.json "$R/${S}_final/"          # a scan is read through its parse
fi
if [ -n "$IMG" ]; then
  echo "      one-shot reading and quorum for the $(echo "$IMG" | tr ',' '\n' | wc -l) that fit one call"
  $PY "$PKG/oneshot.py" "$IMG" "$R/${S}_oneshot" > logs/${S}_oneshot.log 2>&1
  "$HERE/prep.sh" $S oneshot "$R/${S}_oneshot" "$R/${S}_oneshot_final"
  T="$R/${S}_quorum_in"; rm -rf "$T"; mkdir -p "$T/image"
  $PY "$HERE/scans.py" --copy "$R/${S}_primary_final" "$T/image" "$IMG"
  "$HERE/consensus.sh" $S "$R/${S}_quorum" "$T/image" "$R/${S}_parse_final" "$R/${S}_oneshot_final"
  cp "$R/${S}_quorum"/*.json "$R/${S}_final/"
  rm -f "$R/${S}_final/_medoid.json"
fi
if [ "$S" != short ]; then
  echo "[3/4] layout readers (column flow / ruled scans) where the layout evidence selects them"
  mkdir -p "$PKG/runs" "$PKG/logs"      # layout_stage writes runs/ and logs/ relative to its folder
  (cd "$PKG" && $PY layout_stage.py > "$ROOT/logs/${S}_layout.log" 2>&1) || true
  for d in "$PKG/runs/${S}_colflow" "$PKG/runs/${S}_ruled"; do
    [ -d "$d" ] && "$HERE/stages.sh" $S "$d" "$d.final" && cp "$d.final"/*.json "$R/${S}_final/"
  done
fi
echo "[4/4] score"
$PY "$HERE/score_run.py" --run "$R/${S}_final" --json "$R/${S}_scores.json" | tail -n 1
