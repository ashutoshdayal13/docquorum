#!/bin/bash
# One raw reading -> a reading ready for consensus / output, the same chain as the
# single-document tool (docquorum/extract.py):
#   primary : schema-driven repairs, then the output stages
#   parse   : snap parsed strings onto the text layer, repairs, then the output stages
#   oneshot : the output stages only (no chunking artifacts to repair)
#
#   benchmarks/extractbench/prep.sh <split> <kind: primary|parse|oneshot> <raw_dir> <out_dir>
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"; PKG="$HERE/../../docquorum"
PY=${DQ_PYTHON:-python}
S=$1; KIND=$2; RAW=$3; OUT=$4
export EB_SPLIT=$S
T="$OUT.__prep"; rm -rf "$T"; mkdir -p "$T"
CUR="$RAW"
if [ "$KIND" = parse ]; then
  $PY "$PKG/reconcile.py" "$CUR" "$T/snap" > /dev/null; CUR="$T/snap"
fi
if [ "$KIND" != oneshot ]; then
  $PY "$PKG/headfill.py"  --run "$CUR"  --out "$T/r1"             > /dev/null
  $PY "$PKG/pagefix.py"   --run "$T/r1" --out "$T/r2" --no-locate > /dev/null
  $PY "$PKG/dedupe.py"    --run "$T/r2" --out "$T/r3"             > /dev/null
  $PY "$PKG/stackfold.py" --run "$T/r3" --out "$T/fx"             > /dev/null
  CUR="$T/fx"
fi
"$HERE/stages.sh" "$S" "$CUR" "$OUT"
rm -rf "$T"
