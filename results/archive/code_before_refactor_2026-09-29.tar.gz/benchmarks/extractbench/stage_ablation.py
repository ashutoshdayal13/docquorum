"""
Isolated effect of each output stage, split by whether a document is of the TYPE that
motivated the stage (RESULTS.md §8) -- the part of the gain that is not the motivating
document type is the evidence that a stage generalises.

Base = for every document, the reading the final assembly routed to, BEFORE the output
stages. Each stage is applied alone to the base; only documents whose output changed are
scored. Document type = identical data_schema (the grouping of RESULTS.md §7.1).

    python stage_ablation.py short runs/short_final        (routing read from _medoid.json)
    python stage_ablation.py medium runs/med_all_At2
    python stage_ablation.py long runs/i5_beta2
"""
import sys as _sys
from pathlib import Path as _P
_sys.path.insert(0, str(_P(__file__).resolve().parents[2] / "docquorum"))   # the pipeline package
import filecmp
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

E = "./ebenv/bin/python"
STAGES = {  # stage -> (command, document that motivated it)
    "conform":   (["conform.py"], "caterpillar_spec_sheet_330_excavator"),
    "emptyrows": (["emptyrows.py"], "W14-2nd Sub 53269 Revised W14"),
    "xarray":    (["xarray.py"], "real_pueblo_oct_2025"),
    "dupcap":    (["dupcap.py"], "real_ftx_full"),
    "pagegrid":  (["pagegrid.py"], "real_credit_strategies_full"),
    "typosnap":  (["typosnap.py"], "gsa_mas_it_labor_0011"),
    "numsnap":   (["numsnap.py"], "byline_bancorp_investor_deck_q2_2023"),
    "boolblank": (["boolblank.py"], "W2-27-217184_213122"),
}
UNSTAGED = {"short_all_A2_fs": "short_all_A2", "sp_parse_fs": "fx_sp_parse_snap",
            "short_all_C_fs": "short_all_C"}


def schema_types():
    out = {}
    for split in ("short", "medium", "long"):
        for line in open(f"eb_data/{split}.jsonl"):
            r = json.loads(line)
            s = r["data_schema"] if isinstance(r["data_schema"], str) else json.dumps(r["data_schema"], sort_keys=True)
            out[r["id"].split("/")[-1]] = hashlib.md5(s.encode()).hexdigest()[:10]
    return out


def score(split, run, names):
    if not names:
        return {}
    out = f"/tmp/claude-1059/abl_{split}_{Path(run).name}.json"
    subprocess.run([E, "score_run.py", "--run", run, "--only", ",".join(sorted(names)), "--json", out],
                   env={**os.environ, "EB_SPLIT": split}, capture_output=True, text=True, check=True)
    return json.load(open(out))


def main():
    split, final = sys.argv[1], Path(sys.argv[2])
    base = Path(f"runs/_abl_base_{split}")
    shutil.rmtree(base, ignore_errors=True)
    base.mkdir(parents=True)
    med = final / "_medoid.json"
    if med.exists():                      # routed split: the chosen reading, unstaged
        for name, v in json.load(open(med)).items():
            src = Path("runs") / UNSTAGED.get(Path(v["pick"]).name, Path(v["pick"]).name) / f"{name}.json"
            shutil.copy(src, base / f"{name}.json")
    else:
        for f in final.glob("*.json"):
            if not f.name.startswith("_"):
                shutil.copy(f, base / f.name)
    types = schema_types()
    report = {}
    for stage, (cmd, motive) in STAGES.items():
        out = Path(f"runs/_abl_{split}_{stage}")
        shutil.rmtree(out, ignore_errors=True)
        subprocess.run([E, *cmd, str(base), str(out)], env={**os.environ, "EB_SPLIT": split},
                       capture_output=True, text=True, check=True)
        changed = {f.stem for f in base.glob("*.json")
                   if (out / f.name).exists() and not filecmp.cmp(f, out / f.name, shallow=False)}
        before, after = score(split, str(base), changed), score(split, str(out), changed)
        rows = []
        for n in sorted(changed):
            d = 100 * (after[n][0] - before[n][0])
            rows.append((n, d, types[n] == types[motive]))
        report[stage] = rows
        tot = sum(d for _, d, _ in rows)
        oth = [(n, d) for n, d, m in rows if not m]
        print(f"{split:6s} {stage:9s} changed {len(rows):3d} docs | total {tot:+8.2f} pts "
              f"| other types: {sum(d for _, d in oth):+8.2f} pts on {len(oth)} docs "
              f"(+{sum(1 for _, d in oth if d > 1e-6)} / -{sum(1 for _, d in oth if d < -1e-6)})", flush=True)
    Path(f"logs/stage_ablation_{split}.json").write_text(json.dumps(report, indent=1))


if __name__ == "__main__":
    main()
