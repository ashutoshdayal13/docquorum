"""
Place the held-out UNIKIE-BENCH arms (runs/unikie/scores.json, written by
`unikie_eval.py score`) against the 15 systems of the benchmark paper's Table 4.

    python unikie_report.py
"""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
T = json.load(open(HERE / "unikie_published_table4.json"))
COLS = T["columns"][:-1]                       # the 11 scenarios; last column is the average


def main():
    import sys; sys.path.insert(0, str(HERE)); import unikie_eval as UE
    ours = json.load(open(UE.OUT / "scores.json"))
    published = {**{f"{k} (closed)": v for k, v in T["closed_source"].items()},
                 **{f"{k} (open)": v for k, v in T["open_source"].items()}}
    rows = {name: dict(zip(COLS, vals[:-1])) | {"MACRO": vals[-1]} for name, vals in published.items()}
    labels = {"oneshot_raw": "Qwen3.8-27B, official one-shot (raw)",
              "oneshot": "Qwen3.8-27B, official one-shot (conformed)",
              "image": "pipeline image reading", "parse": "pipeline parse reading",
              "consensus": "** PIPELINE (consensus) **"}
    for arm, per in ours.items():
        if len(per) == len(COLS):
            rows[labels.get(arm, arm)] = dict(per) | {"MACRO": sum(per.values()) / len(per)}
    ranked = sorted(rows.items(), key=lambda kv: -kv[1]["MACRO"])
    print(f"{'system':46s} {'MACRO':>6s}  " + " ".join(f"{c[:6]:>6s}" for c in COLS))
    for name, r in ranked:
        print(f"{name[:46]:46s} {r['MACRO']:6.2f}  " + " ".join(f"{r[c]:6.2f}" for c in COLS))
    best = {c: max((r[c], n) for n, r in rows.items() if not n.startswith(("Qwen3.8", "pipeline", "**")))
            for c in COLS}
    if "** PIPELINE (consensus) **" in rows:
        p = rows["** PIPELINE (consensus) **"]
        wins = [c for c in COLS if p[c] > best[c][0]]
        print(f"\npipeline beats every published system on {len(wins)} of 11 scenarios: {', '.join(wins)}")


if __name__ == "__main__":
    main()
