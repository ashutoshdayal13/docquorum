#!/bin/bash
# DocQuorum on UNIKIE-BENCH (all 11 constrained scenarios, 4,472 images), official evaluator,
# every input capped at the benchmark's 1,605,632 pixels.
#
#   benchmarks/unikie/run.sh score            re-score the stored readings (exact reproduction)
#   benchmarks/unikie/run.sh read             fresh readings with the main model (27B):
#                                             oneshot, image, parse, oneshot_text
#   benchmarks/unikie/run.sh read-extra MODEL fresh one-shot readings from a second model served
#                                             at $DQ_LLM_URL (MODEL = 32 -> oneshot32, 8 -> oneshot8)
#
# Frozen configuration (held-out): consensus over image, parse, oneshot   -> 80.64 macro
# Tuned configuration (dev/test split): + oneshot_text, oneshot32, oneshot8 -> 82.37 macro
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
PY=${DQ_PYTHON:-python}
export UNIKIE_FAIR=1 EB_GUIDED=1 EB_NOTHINK=1
cd "$HERE"
case "$1" in
  read)
    $PY unikie_eval.py parse-images --workers 24          # needs the MinerU parser
    for r in oneshot image parse oneshot_text; do $PY unikie_eval.py read --reading $r --workers 32; done ;;
  read-extra)
    UNIKIE_MAX_IMAGES=$([ "$2" = 32 ] && echo 2 || echo 4) $PY unikie_eval.py read --reading oneshot$2 --workers 32 ;;
  score|*)
    $PY - <<'EOF' 2>&1 | grep -v donut
import unikie_dev as D, unikie_protocol as U
D.SPLIT["full"] = {sc: D.SPLIT["dev"][sc] + D.SPLIT["test"][sc] for sc in U.SCENARIOS}
for label, arms in (("frozen", ["image", "parse", "oneshot"]),
                    ("tuned", ["image", "oneshot_text", "oneshot", "parse", "oneshot32", "oneshot8"])):
    for split in ("test", "full"):
        m, per = D.evaluate(arms, "medoid", split, verbose=False)
        print(f"{label:6s} {split:4s} macro {m:6.2f}  " + " ".join(f"{s[:5]}={v:5.2f}" for s, v in per.items()))
EOF
    ;;
esac
