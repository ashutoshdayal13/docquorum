"""
Held-out evaluation of the FROZEN pipeline (FROZEN_2026-09-27.json) on UNIKIE-BENCH
(ACL 2026), scored with the benchmark's own evaluator. Nothing here was developed on
UNIKIE data; the only UNIKIE-specific code is input/output plumbing.

UNIKIE documents are single images with a JSON template; there is no text layer, so the
text-layer stages (dupcap, pagegrid, typosnap) have nothing to act on and pass through.
What is tested is the part of the method that transfers to any document:

  readings   oneshot -- the benchmark's own protocol (its prompt prefix, image size,
                        post-processing), our backbone: the controlled baseline
             image   -- the pipeline's whole-document call (WHOLE_PROMPT, schema-guided
                        decoding) on the page image
             parse   -- the same call with the MinerU parse of the image as its text
                        (the parse view)
  consensus  medoid over the three readings, recall-weighted (beta=2), agreement measured
             with the benchmark's own evaluator (as medoidroute.py does with ExtractBench's)
  output     conform to the template: every templated key present, absent -> the
             template's empty value "" (UNIKIE's evaluator scores null as the string "None")

    python unikie_eval.py read --reading oneshot|image|parse [--scenarios ...]
    python unikie_eval.py parse-images                       (MinerU cache; parser on :8081)
    python unikie_eval.py consensus
    python unikie_eval.py score
"""
import argparse
import base64
import io
import json
import sys
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]                                   # the docquorum/ project folder
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(ROOT / "docquorum"))
import unikie_protocol as U          # the protocol replication (prompt, image size, parser, scorer)
import wholedoc
import pipeline as P

import os
# UNIKIE_FAIR=1: every pipeline input capped at the benchmark's 1,605,632 pixels (§10.2)
FAIR = os.environ.get("UNIKIE_FAIR", "0") == "1"
OUT = Path(os.environ.get("DQ_UNIKIE_READINGS", ROOT / "results" / "unikie" / ("readings" if FAIR else "readings_2p6mp")))
PCACHE = ROOT / "cache" / ("unikie_parse_1p6" if FAIR else "unikie_parse")
READ_PX = U.TARGET_MAX_PIXELS if FAIR else 2_600_000
PARSE_PX = U.TARGET_MAX_PIXELS if FAIR else 9_000_000
BASE_URL = "http://localhost:8079/v1"
# Qwen3-VL-32B's proven server config accepts 2 images per request (30 three-page
# Commercial invoices therefore get no 32B reading; the consensus uses the others)
MAX_IMAGES = int(os.environ.get("UNIKIE_MAX_IMAGES", "12"))
BETA = 2.0


# ---------- template <-> schema ----------
def to_schema(t):
    if isinstance(t, dict):
        return {"type": "object", "additionalProperties": False,
                "properties": {k: to_schema(v) for k, v in t.items()}}
    if isinstance(t, list):
        return {"type": "array", "items": to_schema(t[0] if t else "")}
    return {"type": ["string", "null"]}


def conform(pred, t):
    """The template's shape with the reading's values; absent or null -> ''."""
    if isinstance(t, dict):
        pred = pred if isinstance(pred, dict) else {}
        return {k: conform(pred.get(k), v) for k, v in t.items()}
    if isinstance(t, list):
        item = t[0] if t else ""
        return [conform(x, item) for x in pred] if isinstance(pred, list) else []
    if pred is None or isinstance(pred, (dict, list)):
        return ""
    return str(pred)


# ---------- images ----------
def encode(path, max_pixels):
    from PIL import Image
    with Image.open(path) as im:
        im = im.convert("RGB")
        w, h = im.size
        if w * h > max_pixels:
            sc = (max_pixels / (w * h)) ** 0.5
            im = im.resize((max(1, int(w * sc)), max(1, int(h * sc))), Image.LANCZOS)
        buf = io.BytesIO()
        im.save(buf, format="JPEG", quality=95, optimize=True)
        return base64.b64encode(buf.getvalue()).decode()


def records(scenario):
    ds = U.DATASETS / scenario
    for q in U.load_qa(scenario):
        imgs = U.resolve_images(ds, q["url"])
        yield U.image_name(q["url"]), imgs, json.loads(q["prompt"])


# ---------- readings ----------
def read_oneshot(client, imgs, template):
    content = [{"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{U.encode_image(p)}"}}
               for p in imgs]
    content.append({"type": "text", "text": U.PREFIX + json.dumps(template, ensure_ascii=False)})
    r = client.chat.completions.create(model="qwen3vl", temperature=0.0, max_tokens=4096,
                                       messages=[{"role": "user", "content": content}],
                                       extra_body={"chat_template_kwargs": {"enable_thinking": False}})
    got, _err = U.post_process_to_json(r.choices[0].message.content)
    return got


LIST_RULE = ("- A list field's item schema describes ONE element: return one element per entry "
             "the document prints, never several entries merged into one element.")
# v3: the dominant rendering error on Commercial (dev): a '$' the invoice does not print
CURRENCY_RULE = ("- Do not add a currency symbol, unit or any other character that is not printed "
                 "next to the value itself; keep its separators and decimal marks as printed.")


def read_oneshot_text(client, imgs, template, text):
    """The benchmark's own prompt, with the page's OCR text appended (v2 reading)."""
    content = [{"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{U.encode_image(p)}"}}
               for p in imgs]
    body = "\n".join(text)
    content.append({"type": "text", "text": U.PREFIX + json.dumps(template, ensure_ascii=False) +
                    "\nThe OCR text of the document, for reference:\n" + body})
    r = client.chat.completions.create(model="qwen3vl", temperature=0.0, max_tokens=4096,
                                       messages=[{"role": "user", "content": content}],
                                       extra_body={"chat_template_kwargs": {"enable_thinking": False}})
    got, _err = U.post_process_to_json(r.choices[0].message.content)
    return got


def read_whole(client, imgs, template, text=None, list_rule=False, currency_rule=False, ocr=False):
    """The pipeline's whole-document call (wholedoc.extract), on image input. ocr=True labels
    the parser's text as machine-read (wholedoc's DQ_OCR_AWARE wording)."""
    schema = to_schema(template)
    b64 = [encode(p, READ_PX) for p in imgs]
    if text is not None:
        body = "\n\n".join(f"--- PAGE {i + 1} ---\n{t}" for i, t in enumerate(text))
        if ocr:
            text_block = ("OCR text of the scanned pages (machine-read: it can misread characters and "
                          "drop decimal points, spaces or punctuation; where it disagrees with the page "
                          f"images, follow the images):\n{body}\n--- END TEXT ---\n\n")
            modality = "Its pages are scanned images, attached, and their OCR text is below."
        else:
            text_block = f"The document's text layer (exact characters):\n{body}\n--- END TEXT ---\n\n"
            modality = "Its pages are attached as images, and its text is below."
    else:
        text_block, modality = "", "Its pages are attached as images (the document has no text layer)."
    rules = "\n".join(r for r, on in ((LIST_RULE, list_rule), (CURRENCY_RULE, currency_rule)) if on)
    prompt = wholedoc.WHOLE_PROMPT.format(numbers_rule=rules, task="", n=len(imgs), modality=modality,
                                          text_block=text_block, schema=json.dumps(schema, indent=1))
    content = [{"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b}"}} for b in b64]
    content.append({"type": "text", "text": prompt})
    r = client.chat.completions.create(model="qwen3vl", temperature=0.0, max_tokens=8000,
                                       messages=[{"role": "user", "content": content}],
                                       extra_body=P.extra_body(schema))
    return wholedoc.parse_object(r.choices[0].message.content or "")


def parsed_text(scenario, name, n):
    d = PCACHE / scenario / Path(name).stem
    got = [d / f"{i:04d}.txt" for i in range(1, n + 1)]
    return [f.read_text() for f in got] if all(f.exists() for f in got) else None


def cmd_read(args):
    from openai import OpenAI
    client = OpenAI(base_url=BASE_URL, api_key="EMPTY", timeout=900, max_retries=4)
    scen = U.SCENARIOS if args.scenarios == "all" else args.scenarios.split(",")
    for sc in scen:
        dst = OUT / args.reading / f"{sc}.json"
        dst.parent.mkdir(parents=True, exist_ok=True)
        done = json.loads(dst.read_text()) if dst.exists() else {}
        keep = set(json.load(open(HERE / "unikie_split.json"))[args.split][sc]) if args.split else None
        todo = [r for r in records(sc) if r[0] not in done and (keep is None or r[0] in keep)]
        lock, failed = threading.Lock(), []

        def one(rec):
            name, imgs, template = rec
            try:
                if len(imgs) > MAX_IMAGES:
                    raise RuntimeError(f"{len(imgs)} images > server limit {MAX_IMAGES}")
                if args.reading in ("oneshot", "oneshot32"):
                    got = read_oneshot(client, imgs, template)
                elif args.reading in ("image", "image_v2", "image_v3", "image32"):
                    got = read_whole(client, imgs, template, list_rule=args.reading[-3:] in ("_v2", "_v3"),
                                     currency_rule=args.reading.endswith("_v3"))
                else:
                    text = parsed_text(sc, name, len(imgs))
                    if text is None:
                        raise RuntimeError("no parse cached")
                    if args.reading in ("oneshot_text", "oneshot_text32"):
                        got = read_oneshot_text(client, imgs, template, text)
                    else:
                        got = read_whole(client, imgs, template, text,
                                         list_rule=args.reading[-3:] in ("_v2", "_v3"),
                                         currency_rule=args.reading.endswith("_v3"),
                                         ocr=args.reading == "parse_ocr")
            except Exception as e:                      # never write a failure as a reading
                with lock:
                    failed.append(f"{name}: {type(e).__name__}: {str(e)[:80]}")
                return
            with lock:
                done[name] = got if isinstance(got, (dict, list)) else {}

        with ThreadPoolExecutor(args.workers) as ex:
            list(ex.map(one, todo))
        dst.write_text(json.dumps(done, ensure_ascii=False))
        print(f"{args.reading:8s} {sc:18s} {len(done)} read, {len(failed)} failed", flush=True)
        for f in failed[:3]:
            print("   !", f)


def cmd_parse(args):
    import docparse
    from PIL import Image
    client = docparse.make_client()
    scen = U.SCENARIOS if args.scenarios == "all" else args.scenarios.split(",")

    def one(item):
        sc, name, imgs = item
        d = PCACHE / sc / Path(name).stem
        d.mkdir(parents=True, exist_ok=True)
        for i, p in enumerate(imgs, 1):
            f = d / f"{i:04d}.txt"
            if f.exists():
                continue
            with Image.open(p) as im:
                im = im.convert("RGB")
                w, h = im.size
                if w * h > PARSE_PX:
                    sc_ = (PARSE_PX / (w * h)) ** 0.5
                    im = im.resize((max(1, int(w * sc_)), max(1, int(h * sc_))))
                try:
                    f.write_text(docparse.blocks_to_text(client.two_step_extract(im)))
                except Exception as e:
                    print(f"   ! parse {sc}/{name}: {type(e).__name__}: {str(e)[:80]}", flush=True)

    items = [(sc, name, imgs) for sc in scen for name, imgs, _ in records(sc)]
    with ThreadPoolExecutor(args.workers) as ex:
        list(ex.map(one, items))
    print(f"parsed {len(items)} documents")


# ---------- consensus ----------
def prf(pred, gold):
    """(precision, recall) of pred against gold under the benchmark's own matching."""
    ev = U.kie_evaluator
    p = ev.flatten(ev.normalize_dict(U.kie_evaluator.normalize_values_of_nested_dict(pred, U.normalize_func)))
    g = ev.flatten(ev.normalize_dict(U.kie_evaluator.normalize_values_of_nested_dict(gold, U.normalize_func)))
    g_left, tp = list(g), 0
    for f in p:
        if f in g_left:
            tp += 1
            g_left.remove(f)
    prec = tp / len(p) if p else (1.0 if not g else 0.0)
    rec = tp / len(g) if g else (1.0 if not p else 0.0)
    return prec, rec


def fbeta(p, r, b=BETA):
    return 0.0 if p <= 0 or r <= 0 else (1 + b * b) * p * r / (b * b * p + r)


def cmd_consensus(args):
    readings = ["image", "parse", "oneshot"]
    for sc in U.SCENARIOS:
        views = {v: json.loads((OUT / v / f"{sc}.json").read_text()) for v in readings
                 if (OUT / v / f"{sc}.json").exists()}
        templates = {name: t for name, _i, t in records(sc)}
        out, picks = {}, {}
        for name, t in templates.items():
            cand = {v: conform(d.get(name), t) for v, d in views.items() if name in d}
            if not cand:
                continue
            score = {}
            for c in cand:
                others = [o for o in cand if o != c]
                score[c] = round(sum(fbeta(*prf(cand[c], cand[o])) for o in others) / len(others), 9) \
                    if others else 0.0
            best = max(cand, key=lambda c: (score[c], -readings.index(c)))
            out[name], picks[name] = cand[best], best
        (OUT / "consensus").mkdir(parents=True, exist_ok=True)
        (OUT / "consensus" / f"{sc}.json").write_text(json.dumps(out, ensure_ascii=False))
        from collections import Counter
        print(f"{sc:18s} {len(out)} docs  picks {dict(Counter(picks.values()))}", flush=True)


def cmd_score(args):
    runs = ["oneshot_raw", "oneshot", "image", "parse", "consensus"]
    table = {}
    for sc in U.SCENARIOS:
        templates = {name: t for name, _i, t in records(sc)}
        for r in runs:
            f = OUT / r.replace("_raw", "") / f"{sc}.json"
            if not f.exists():
                continue
            d = json.loads(f.read_text())
            if r.endswith("_raw"):      # official post-processing only: the published protocol
                preds = {n: d[n] for n in templates if isinstance(d.get(n), (dict, list))}
            else:
                preds = {n: conform(d.get(n), t) for n, t in templates.items()}
            table.setdefault(r, {})[sc] = 100 * U.score(preds, sc)[0]
    print(f"{'scenario':18s} " + " ".join(f"{r:>9s}" for r in runs))
    for sc in U.SCENARIOS:
        print(f"{sc:18s} " + " ".join(f"{table.get(r, {}).get(sc, float('nan')):9.2f}" for r in runs))
    print(f"{'MACRO':18s} " + " ".join(
        f"{sum(table[r].values()) / len(table[r]):9.2f}" if r in table and len(table[r]) == len(U.SCENARIOS)
        else f"{'partial':>9s}" for r in runs))
    (OUT / "scores.json").write_text(json.dumps(table, indent=1))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["read", "parse-images", "consensus", "score"])
    ap.add_argument("--reading", choices=["oneshot", "image", "parse", "parse_ocr", "image_v2", "parse_v2", "image_v3",
                                          "parse_v3", "oneshot_text",
                                          # the same calls served by Qwen3-VL-32B (second model)
                                          "oneshot32", "oneshot_text32", "image32", "parse32"])
    ap.add_argument("--split", default="", help="dev|test: restrict reading to that part of runs/unikie_split.json")
    ap.add_argument("--scenarios", default="all")
    ap.add_argument("--workers", type=int, default=24)
    args = ap.parse_args()
    {"read": cmd_read, "parse-images": cmd_parse, "consensus": cmd_consensus,
     "score": cmd_score}[args.cmd](args)


if __name__ == "__main__":
    main()
