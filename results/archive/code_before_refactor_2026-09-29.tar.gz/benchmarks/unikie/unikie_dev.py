"""
UNIKIE-BENCH development harness for the tuned (v2) attempt -- DEV THIRD ONLY.

The frozen, held-out result is RESULTS.md §10.2 (80.64 at the 1.6 MP cap). Everything
here is development on `runs/unikie_split.json`'s dev documents; the final configuration
is run once on the test documents and reported separately, labelled as tuned.

    python unikie_dev.py eval --arms image,parse,oneshot [--combine medoid|vote] [--split dev]
"""
import argparse
import json
import os
import sys
from collections import Counter
from pathlib import Path

os.environ.setdefault("UNIKIE_FAIR", "1")
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import unikie_eval as UE
import unikie_protocol as U

SPLIT = json.load(open(HERE / "unikie_split.json"))
ARMDIR = UE.OUT


def load(arm, sc):
    f = ARMDIR / arm / f"{sc}.json"
    return json.loads(f.read_text()) if f.exists() else None


def norm(v):
    return U.normalize_func(v) if isinstance(v, str) else v


def vote(cands, order):
    """Field-level vote over conformed readings (same template shape). Scalars: the value
    most readings give (evaluator normalisation), ties to the earlier reading in `order`.
    Lists: taken whole from the reading whose list agrees most with the others."""
    first = cands[order[0]]
    if isinstance(first, dict):
        return {k: vote({a: c[k] for a, c in cands.items()}, order) for k in first}
    if isinstance(first, list):
        best, best_s = order[0], -1.0
        for a in order:
            s = sum(UE.fbeta(*UE.prf({"x": cands[a]}, {"x": cands[b]}), 1.0)
                    for b in order if b != a)
            if s > best_s:
                best, best_s = a, s
        return cands[best]
    counts = Counter(norm(cands[a]) for a in order)
    top = max(counts.values())
    for a in order:
        if counts[norm(cands[a])] == top:
            return cands[a]


def medoid(cands, order, beta=UE.BETA):
    # rounded: tied readings tie exactly, so the tie goes to the earlier reading on every
    # Python version (3.12 changed float sum() rounding; 3.10 broke ties on rounding noise)
    sc = {c: round(sum(UE.fbeta(*UE.prf(cands[c], cands[o]), beta) for o in cands if o != c) /
                   max(1, len(cands) - 1), 9) for c in cands}
    return cands[max(cands, key=lambda c: (sc[c], -order.index(c)))]


def evaluate(arms, combine, split="dev", verbose=True):
    per = {}
    for sc in U.SCENARIOS:
        keep = set(SPLIT[split][sc])
        templates = {n: t for n, _i, t in UE.records(sc) if n in keep}
        views = {a: load(a, sc) for a in arms}
        preds = {}
        for n, t in templates.items():
            cands = {a: UE.conform(v.get(n), t) for a, v in views.items() if v is not None}
            if not cands:
                continue
            if len(arms) == 1 or combine == "single":
                preds[n] = cands[arms[0]]
            elif combine == "vote":
                preds[n] = vote(cands, arms)
            else:
                preds[n] = medoid(cands, arms)
        per[sc] = 100 * U.score(preds, sc, subset_only=True)[0]
    macro = sum(per.values()) / len(per)
    if verbose:
        print(f"{split} {'+'.join(arms):28s} {combine:7s} MACRO {macro:6.2f}  " +
              " ".join(f"{sc[:5]}={v:5.2f}" for sc, v in per.items()), flush=True)
    return macro, per


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["eval"])
    ap.add_argument("--arms", default="image,parse,oneshot")
    ap.add_argument("--combine", default="medoid")
    ap.add_argument("--split", default="dev")
    a = ap.parse_args()
    evaluate(a.arms.split(","), a.combine, a.split)


if __name__ == "__main__":
    main()


# ---- OCR snap (v2 candidate) ----
def snapped(arm, sc, names_templates):
    """The arm's conformed readings with ocrsnap applied against the 1.6 MP MinerU text."""
    import ocrsnap
    v = load(arm, sc) or {}
    out, stat = {}, {}
    for n, (imgs, t) in names_templates.items():
        pc = UE.PCACHE / sc / Path(n).stem
        text = "\n".join(f.read_text() for f in sorted(pc.glob("*.txt"))) if pc.is_dir() else ""
        page = ocrsnap.PageText(text)
        fn = ocrsnap.edge_only if os.environ.get("SNAP_MODE") == "edge" else ocrsnap.snap
        out[n] = fn(UE.conform(v.get(n), t), page, stat)
    return out, stat.get("changed", 0)


def evaluate_snap(arms, split="dev", snap_arms=None, combine="medoid"):
    snap_arms = set(snap_arms or arms)
    per, changed = {}, 0
    for sc in U.SCENARIOS:
        keep = set(SPLIT[split][sc])
        nt = {n: (i, t) for n, i, t in UE.records(sc) if n in keep}
        views = {}
        for a in arms:
            if a in snap_arms:
                views[a], c = snapped(a, sc, nt)
                changed += c
            else:
                v = load(a, sc) or {}
                views[a] = {n: UE.conform(v.get(n), t) for n, (_i, t) in nt.items()}
        preds = {n: (views[arms[0]][n] if len(arms) == 1 else
                     (vote if combine == "vote" else medoid)({a: views[a][n] for a in arms}, arms))
                 for n in nt}
        per[sc] = 100 * U.score(preds, sc, subset_only=True)[0]
    macro = sum(per.values()) / len(per)
    print(f"{split} snap[{','.join(sorted(snap_arms))}] {'+'.join(arms):24s} MACRO {macro:6.2f} (changed {changed})  " +
          " ".join(f"{sc[:5]}={v:5.2f}" for sc, v in per.items()), flush=True)
    return macro, per
