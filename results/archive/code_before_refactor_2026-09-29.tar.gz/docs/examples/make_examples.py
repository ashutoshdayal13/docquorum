"""
Build docs/examples/: the six ExtractBench documents of Table 1 in docquorum.pdf, with the output
after every stage of the pipeline.

The model readings are the stored ones (the runs that produced the reported results); every stage
after them -- repairs, page checks, quorum -- is replayed here by the pipeline's own scripts, in
the pipeline's order, and each intermediate output is scored with ExtractBench's own scorer. The
replayed final output is compared with the stored final result.

    source configs/local.env && $DQ_PYTHON docs/examples/make_examples.py
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]            # the docquorum project folder
PKG = ROOT / "docquorum"
sys.path.insert(0, str(PKG))
import settings as S          # noqa: E402
import pipeline as P          # noqa: E402
import ebscore                # noqa: E402

PY = sys.executable
OUT = Path(__file__).resolve().parent
RUNS = ROOT / "runs"

# the stages, in the pipeline's order (benchmarks/extractbench/prep.sh and stages.sh)
REPAIRS = [("headfill", ["--run", "{i}", "--out", "{o}"]),
           ("pagefix", ["--run", "{i}", "--out", "{o}", "--no-locate"]),
           ("dedupe", ["--run", "{i}", "--out", "{o}"]),
           ("stackfold", ["--run", "{i}", "--out", "{o}"])]
CHECKS = [(m, ["{i}", "{o}"]) for m in ("conform", "boolblank", "emptyrows", "xarray", "dupcap",
                                          "pagegrid", "typosnap", "numsnap")]
CHAIN = {"primary": REPAIRS + CHECKS,
         "parse": [("reconcile", ["{i}", "{o}"])] + REPAIRS + CHECKS,
         "oneshot": CHECKS,
         "layout": CHECKS}
WHAT = {
    "reconcile": "repair: snap parser strings to the text layer's exact characters (only where the PDF has one)",
    "headfill": "repair: carry a value printed once down to the rows it governs (where the schema says so)",
    "pagefix": "repair: report the printed page number where the schema asks for it",
    "dedupe": "repair: one row per key where the list's description says each entry appears once",
    "stackfold": "repair: join a record printed over several stacked lines back into one row",
    "conform": "check: every schema field present (null where allowed); output valid against the schema",
    "boolblank": "check: a blank tick box is false where the field's description says so",
    "emptyrows": "check: drop template rows (only the printed label filled) and blank pre-printed lines",
    "xarray": "check: drop rows copied from one list into another",
    "dupcap": "check: cap identical records at the number of times the page prints them",
    "pagegrid": "check: locate each row's page from its words; report the printed page number",
    "typosnap": "check: quote characters as the page prints them",
    "numsnap": "check: a rounded or rescaled number replaced by the one printed number it restates",
}

EXAMPLES = [
    dict(slug="1_purchase_order_digital", split="short",
         name="oklahoma_county_purchase_order_avl_systems",
         title="Oklahoma County purchase order -- one-page digital PDF (Figure 1 of the document)",
         route="A digital PDF (made by software, so its text is exact): read once by the reader "
               "agent, on its text layer and the page image at 220 dpi. The agent's first reply "
               "left schema fields out -- among them the printed requisition number -- so the "
               "document was read again with every field required. Then the repairs and checks.",
         readings=[("reader_agent", "short_primary_hr_req", "primary")],
         first_reply="short_primary_hr",
         logs=["short_primary_hr.log", "short_primary_hr_req.log"]),
    dict(slug="2_purchase_order_scan", split="short",
         name="oklahoma_county_purchase_order_avl_systems_corrupted",
         title="The same purchase order as a degraded scan, with no text in the PDF",
         route="A scan without text: read three ways -- the reader agent on the page image, the "
               "reader agent on the MinerU parse, and the one-shot reader. Each reading passes the "
               "repairs and checks; the quorum then keeps the reading the other two agree with most.",
         readings=[("reading_A_agent_on_page_image", "short_primary_hr_req", "primary"),
                   ("reading_B_agent_on_parse", "short_parse_hr", "parse"),
                   ("reading_C_one_shot", str(ROOT.parent / "Recent_Papers/multi_agent_test_9/runs/test_short_oneshot"),
                    "oneshot")],        # the benchmark's own one-shot reader, 150 dpi (as in the results)
         quorum=True,
         logs=["short_primary_hr_req.log", "short_parse_hr.log"]),
    dict(slug="3_w14_scan_with_ocr_text", split="short", name="W14-58025_W14 Admin Reviewed",
         title="Texas W-14 oil-and-gas well form -- a scan whose PDF carries OCR text",
         route="The PDF has a text layer, but it is OCR text over a scanned page. The reader agent "
               "reads it with the text labelled machine-read and the page image at 220 dpi deciding "
               "where they disagree. The schema (180,285 characters) still fits one call.",
         readings=[("reader_agent", "short_primary_hr_ocr", "primary")],
         logs=["short_primary_hr_ocr.log"]),
    dict(slug="4_tax_return_scan", split="medium", name="bar-lev-2022",
         title="bar-lev-2022 -- a 25-page scanned tax return with a 537,786-character schema",
         route="No text in the PDF and too long for one call's page images; the schema does not fit "
               "one call either. The reader agent reads the MinerU parse, splits the schema into "
               "groups of fields, and reads each group in windows of up to 8 pages with those pages' "
               "images and OCR text; the windows are merged. Then the repairs and checks.",
         readings=[("reader_agent_on_parse", "medium_taxwin", "parse")],
         logs=["medium_taxwin.log"]),
    dict(slug="5_register_column_flow", split="long", name="real_oklahoma_unclaimed_2024",
         title="Oklahoma unclaimed-property register -- 59 pages, seven columns per page, 26,725 records",
         route="The page geometry shows at least three text columns of near-equal width (seven "
               "here), so the document goes to the column-flow reader: each column is cut out of the "
               "page image and read top to bottom, one model call per column. Then the checks.",
         readings=[("column_flow_reader", "colflow27", "layout")],
         reader_log=PKG / "logs" / "long_colflow_real_oklahoma_unclaimed_2024.log",
         pages=(2,)),
    dict(slug="6_creditor_list_ruled", split="long", name="real_ftx_full_corrupted",
         title="FTX creditor list -- 114 scanned pages of ruled tables, 7,554 rows",
         route="No text in the PDF; its parsed tables map onto the schema's fields, so the document "
               "goes to the ruled-table reader: on each page the printed ruling lines are found, the "
               "rows between them counted, and each band of up to 12 rows is read with its header "
               "row and told the exact row count. Then the checks.",
         readings=[("ruled_table_reader", str(PKG / "runs" / "long_ruled"), "layout")],
         reader_log=PKG / "logs" / "long_ruled_real_ftx_full_corrupted.log",
         pages=(2,)),
]


def records(split):
    return {r["id"].split("/")[-1]: r for r in ebscore.load_records(split)}


def f1(rec, pred):
    m = ebscore.score(rec, pred)["metrics"]
    return round(100 * m.get("extract_unified_value_f1", 0.0), 2)


def dump(path, obj, big):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False) if big else
                    json.dumps(obj, indent=1, ensure_ascii=False))


def flat(o, pre=""):
    if isinstance(o, dict):
        out = {}
        for k, v in o.items():
            out.update(flat(v, f"{pre}.{k}" if pre else k))
        return out
    if isinstance(o, list):
        out = {f"{pre}[#rows]": len(o)}
        for i, v in enumerate(o):
            out.update(flat(v, f"{pre}[{i}]"))
        return out
    return {pre: o}


def diff(a, b, keep=3):
    fa, fb = flat(a), flat(b)
    keys = sorted(set(fa) | set(fb))
    changed = [k for k in keys if fa.get(k, "<absent>") != fb.get(k, "<absent>") or (k in fa) != (k in fb)]
    rows = [k for k in changed if k.endswith("[#rows]")]
    vals = [k for k in changed if not k.endswith("[#rows]")]
    parts = []
    for k in rows[:keep]:
        parts.append(f"{k[:-7] or '(top)'}: {fa.get(k, 0)} -> {fb.get(k, 0)} rows")
    for k in vals[:keep]:
        parts.append(f"{k}: {json.dumps(fa.get(k, '<absent>'), ensure_ascii=False)[:40]} -> "
                     f"{json.dumps(fb.get(k, '<absent>'), ensure_ascii=False)[:40]}")
    if not changed:
        return "no change"
    more = len(vals) - min(len(vals), keep)
    return f"{len(vals)} value(s) changed" + (f", row counts changed in {len(rows)} list(s)" if rows else "") + \
        ": " + "; ".join(parts) + (f"; ... {more} more" if more > 0 else "")


def run_stage(mod, args, src_file, name, split):
    with tempfile.TemporaryDirectory() as td:
        i, o = Path(td) / "in", Path(td) / "out"
        i.mkdir()
        shutil.copy(src_file, i / f"{name}.json")
        cmd = [PY, str(PKG / f"{mod}.py")] + [a.format(i=i, o=o) for a in args]
        r = subprocess.run(cmd, env={**os.environ, "EB_SPLIT": split}, capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError(f"{mod} failed: {r.stderr[-800:]}")
        f = o / f"{name}.json"
        return json.loads(f.read_text()) if f.exists() else json.loads(src_file.read_text())


def front_end(ex, rec, d):
    fe = d / "0_front_end"
    fe.mkdir(parents=True, exist_ok=True)
    pdf = S.DATA / "docs" / rec["pdf"].replace("docs/", "", 1)
    pages = ex.get("pages", (1,))
    for pg in pages:
        subprocess.run([S.PDFTOPPM, "-r", "100", "-f", str(pg), "-l", str(pg), "-png", "-singlefile",
                        str(pdf), str(fe / f"page-{pg}")], capture_output=True)
    txt = subprocess.run([S.PDFTOTEXT, "-layout", "-f", str(pages[0]), "-l", str(pages[-1]), str(pdf), "-"],
                         capture_output=True).stdout.decode("utf-8", "replace")
    n_pages = int(next(l.split()[-1] for l in subprocess.run([S.PDFINFO, str(pdf)], capture_output=True)
                       .stdout.decode("utf-8", "replace").splitlines() if l.startswith("Pages")))
    all_text = sum(len(t.strip()) for t in P.page_texts(pdf))
    kind = json.load(open(ROOT / "results/extractbench/provenance.json"))[ex["split"]].get(ex["name"], {})
    plain = {"born-digital": "digital PDF (made by software; its text is exact)",
             "ocr-layer": "scan with OCR text (text read from the page images; can contain misreads)",
             "no text layer": "scan without text (page images only)"}
    has_text = all_text >= 50 * n_pages
    info = {"pages": n_pages, "characters in the PDF's text layer": all_text,
            "kind of PDF": plain.get(kind.get("kind"), "digital PDF (made by software; its text is exact)"
                                     if has_text else "scan without text (page images only)"),
            "schema characters (compact)": len(json.dumps(rec["data_schema"], separators=(",", ":")))}
    dump(fe / "front_end.json", info, False)
    if txt.strip():
        (fe / f"text_layer_page{'s' if len(pages) > 1 else ''}-{'-'.join(map(str, pages))}.txt").write_text(txt)
    cache = S.PARSE_CACHE / ex["name"]
    for pg in (pages if not has_text else ()):     # the parser is used only for scans without text
        f = cache / f"{pg:04d}.txt"
        if f.exists():
            shutil.copy(f, fe / f"mineru_parse_page-{pg}.txt")
    shutil.copy(pdf, d / "input" / "document.pdf") if pdf.stat().st_size < 3_000_000 else \
        (d / "input" / "document.txt").write_text(f"{pdf.stat().st_size // 1_000_000} MB, not copied: "
                                                  f"data/extractbench/{rec['pdf']}\n")
    return info


def log_lines(ex):
    out = []
    for lg in ex.get("logs", []):
        f = ROOT / "logs" / lg
        if f.exists():
            hits = [l.rstrip() for l in f.read_text(errors="ignore").splitlines()
                    if l.strip().startswith(ex["name"][:40]) and "mode=" in l]
            import re
            for h in hits:
                g = lambda k: (re.search(k + r"=\s*(\S+)", h) or [None, "-"])[1]
                t = (re.search(r"(\d+)s mode=", h) or [None, "-"])[1]
                out.append(f"{lg}: plan={g('mode')} model_calls={g('calls')} cut_off_replies={g('trunc')} "
                           f"pages_asked_again={g('reasked')} seconds={t}")
    if ex.get("reader_log") and Path(ex["reader_log"]).exists():
        out += [l.rstrip() for l in Path(ex["reader_log"]).read_text(errors="ignore").splitlines()]
    return out


def build(ex, rec):
    d = OUT / ex["slug"]
    if d.exists():
        shutil.rmtree(d)
    (d / "input").mkdir(parents=True)
    big = ex["split"] == "long"
    dump(d / "input" / "schema.json", rec["data_schema"], False)
    dump(d / "input" / "answer_key.json", rec["expected_output"], big)
    fe = front_end(ex, rec, d)
    table, finals = [], {}
    lines = log_lines(ex)
    if lines:
        (d / "1_reader_log.txt").write_text(
            "The reader's log for this document. plan: whole = one whole-document call; partitioned = "
            "schema groups x page windows; chunked = page chunks. For the layout readers, one line per "
            "page (columns found / records read, or ruled bands / rows counted / rows returned).\n\n"
            + "\n".join(lines) + "\n")
    if ex.get("first_reply"):
        first = json.loads((RUNS / ex["first_reply"] / f"{ex['name']}.json").read_text())
        dump(d / "1_reader_agent" / "reply_1.json", first, big)
        miss = P.missing_keys(rec["data_schema"], first)
        table.append(("1_reader_agent/reply_1.json",
                      f"the agent's first reply: {miss} schema field(s) left out "
                      f"(e.g. requisition_number: {'present' if 'requisition_number' in first else 'absent'})",
                      f1(rec, first)))
    for label, run, kind in ex["readings"]:
        src = (Path(run) if Path(run).is_absolute() else RUNS / run) / f"{ex['name']}.json"
        cur = json.loads(src.read_text())
        sub = d / (f"2_{label}" if len(ex["readings"]) > 1 else "2_stages")
        step = 0
        name0 = ("reply_2_every_field_required.json" if ex.get("first_reply") else "reading.json")
        dump(sub / f"{step:02d}_{name0}", cur, big)
        what = ("the agent's re-read with every schema field required" if ex.get("first_reply")
                else f"the stored {label.replace('_', ' ')} output")
        table.append((f"{sub.name}/{step:02d}_{name0}", what, f1(rec, cur)))
        prev = cur
        tmp = Path(tempfile.mkdtemp())
        f = tmp / f"{ex['name']}.json"
        f.write_text(json.dumps(cur))
        for mod, args in CHAIN[kind]:
            step += 1
            nxt = run_stage(mod, args, f, ex["name"], ex["split"])
            dump(sub / f"{step:02d}_after_{mod}.json", nxt, big)
            table.append((f"{sub.name}/{step:02d}_after_{mod}.json", f"{WHAT[mod]} -- {diff(prev, nxt)}",
                          f1(rec, nxt)))
            f.write_text(json.dumps(nxt))
            prev = nxt
        finals[label] = f
    if ex.get("quorum"):
        with tempfile.TemporaryDirectory() as td:
            dirs = []
            for label, f in finals.items():
                dd = Path(td) / label
                dd.mkdir()
                shutil.copy(f, dd / f.name)
                dirs.append(str(dd))
            q = Path(td) / "quorum"
            subprocess.run([PY, str(PKG / "medoidroute.py"), ",".join(dirs), ",".join(dirs), str(q)],
                           env={**os.environ, "EB_SPLIT": ex["split"], "CONSENSUS_BETA": "2"},
                           capture_output=True, text=True, check=True)
            med = json.loads((q / "_medoid.json").read_text())[ex["name"]]
            final = json.loads((q / f"{ex['name']}.json").read_text())
            agree = {Path(k).name: round(v, 4) for k, v in med["agreement"].items()}
            dump(d / "3_quorum" / "agreement.json",
                 {"agreement (recall-weighted F-score, beta=2, of each reading against the others)": agree,
                  "kept": Path(med["pick"]).name}, False)
            table.append(("3_quorum/agreement.json",
                          f"quorum: agreement {agree}; keeps {Path(med['pick']).name}", f1(rec, final)))
    else:
        final = json.loads(next(iter(finals.values())).read_text())
    dump(d / "final.json", final, big)
    stored = json.loads((ROOT / "results/extractbench/predictions" / ex["split"] / f"{ex['name']}.json").read_text())
    same = final == stored
    table.append(("final.json", "the output" + (" -- identical to the stored final result" if same else
                  " -- differs from the stored final result (see README)"), f1(rec, final)))
    scores = [{"file": a, "what happened": b, "value F1": c} for a, b, c in table]
    dump(d / "scores.json", scores, False)
    readme = [f"# {ex['title']}", "", f"ExtractBench `{ex['split']}` split, document `{ex['name']}`.", "",
              "**Route.** " + ex["route"], "",
              "**Front end** (`0_front_end/`): " + "; ".join(f"{k}: {v}" for k, v in fe.items()) + ".", "",
              "**Stage by stage** (value F1 against the answer key, x100):", "",
              "| file | what happened | F1 |", "|---|---|---:|"]
    readme += [f"| `{a}` | {b} | {c:.2f} |" for a, b, c in table]
    readme += ["", "`input/answer_key.json` is the benchmark's annotated answer (used only for scoring here).",
               "Files under `2_*` are complete outputs after each stage; for long documents they are "
               "written without indentation."]
    (d / "README.md").write_text("\n".join(readme) + "\n")
    return same, table[-1][2]


def main():
    recs = {s: records(s) for s in ("short", "medium", "long")}
    for ex in EXAMPLES:
        same, score = build(ex, recs[ex["split"]][ex["name"]])
        print(f"{ex['slug']:28s} final F1 {score:6.2f}  replay == stored final: {same}", flush=True)


if __name__ == "__main__":
    main()
