"""Schema walking with no model-client dependency, so the scoring venv can import it.

Mirrors pipeline.find_array_field / find_all_arrays; kept separate because pipeline
pulls in the OpenAI client and ebenv (Python 3.12, needed by the harness) has no
inference deps installed.
"""


def find_array_field(schema):
    defs = schema.get("$defs") or schema.get("definitions") or {}

    def resolve(node, depth=0):
        if depth > 6 or not isinstance(node, dict):
            return node
        if "$ref" in node:
            return resolve(defs.get(node["$ref"].split("/")[-1], {}), depth + 1)
        for comb in ("anyOf", "oneOf", "allOf"):
            if comb in node:
                for opt in node[comb]:
                    r = resolve(opt, depth + 1)
                    if isinstance(r, dict) and r.get("type") == "array":
                        return r
                return resolve(node[comb][0], depth + 1)
        return node

    arrays = []
    for name, prop in (schema.get("properties") or {}).items():
        r = resolve(prop)
        if isinstance(r, dict) and r.get("type") == "array":
            item = resolve(r.get("items") or {})
            desc = prop.get("description") or r.get("description") or ""
            arrays.append((name, item, desc))
    if not arrays:
        return None
    arrays.sort(key=lambda a: -len((a[1].get("properties") or {})))
    return arrays[0]


def find_all_arrays(schema):
    defs = schema.get("$defs") or schema.get("definitions") or {}
    out = []
    for name, prop in (schema.get("properties") or {}).items():
        a = find_array_field({"properties": {name: prop}, "$defs": defs})
        if a:
            out.append(a)
    out.sort(key=lambda a: -len((a[1].get("properties") or {})))
    return out
