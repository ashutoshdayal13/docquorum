"""
Split tables the parser glued together from side-by-side panels.

A page printed as two panels, each a 'Security | Par (000) | Value' table, sometimes comes
back from the parser as ONE six-column table whose header reads
'Security | Par (000) | Value | Security | Par (000) | Value' -- every row then holds two
unrelated records. On three ishares pages (pdf 40, 45, 48) both Qwen3-VL-8B and -32B
returned no records at all for such a table; on the neighbouring page, where the parser
split the panels correctly, they read it fine.

A header that is the same column sequence repeated k times is k panels. Each row is cut
into k segments and the panels are emitted in reading order (all of panel 1, then panel
2, ...). Nothing here is document-specific: the test is the header's own repetition.
"""
import re

TABLE = re.compile(r"<table[^>]*>.*?</table>", re.S | re.I)
ROW = re.compile(r"<tr[^>]*>(.*?)</tr>", re.S | re.I)
CELL = re.compile(r"<t([dh])[^>]*>(.*?)</t[dh]>", re.S | re.I)


def _key(c):
    return re.sub(r"[^a-z0-9]", "", re.sub(r"<[^>]+>", "", c).lower())


def repeat_factor(header):
    """k >= 2 when the header is one sequence of n >= 2 cells repeated k times."""
    keys = [_key(c) for c in header]
    m = len(keys)
    # n >= 3: a repeated TWO-cell sequence is common inside a single table -- before/after
    # columns ('QUANTITY AMOUNT QUANTITY AMOUNT' on a contract modification, 'Destination
    # Government Destination Government' on an inspect/accept table) -- and splitting those
    # would break their rows. Three or more identical cells repeated is a duplicated panel.
    for n in range(3, m // 2 + 1):
        if m % n == 0 and any(keys[:n]):
            if all(keys[i * n:(i + 1) * n] == keys[:n] for i in range(m // n)):
                return m // n, n
    return 1, m


def split_table(tbl):
    rows = [[(t, c) for t, c in CELL.findall(r)] for r in ROW.findall(tbl)]
    if len(rows) < 2:
        return tbl, 1
    k, n = repeat_factor([c for _, c in rows[0]])
    if k < 2:
        return tbl, 1
    out = []
    for i in range(k):
        seg = []
        for r in rows:
            if len(r) != k * n:
                continue
            cells = r[i * n:(i + 1) * n]
            if i > 0 and r is rows[0]:
                pass
            if any(_key(c) for _, c in cells):
                seg.append("<tr>" + "".join(f"<t{t}>{c}</t{t}>" for t, c in cells) + "</tr>")
        out.append("<table>" + "".join(seg) + "</table>")
    return "\n".join(out), k


def fix_page(text):
    """Return (text, number of glued tables split)."""
    n_split = 0

    def repl(m):
        nonlocal n_split
        new, k = split_table(m.group(0))
        if k > 1:
            n_split += 1
        return new

    return TABLE.sub(repl, text), n_split
