"""
Reconcile parsed structure with verbatim source text.

The problem this solves, measured: oklahoma is caught between two front ends. The text path
carries the exact characters but scrambles a 6-column layout; the parse path fixes the
layout but its OCR drops spaces -- and the scorer collapses whitespace RUNS while still
treating a missing space as a mismatch ('POBOX757' != 'PO BOX 757'). Neither front end gives
layout and verbatim text at once.

So take the records from the parsed run (right structure, right cardinality) and snap each
string value onto the verbatim span in the PDF's own text layer. Matching ignores case and
non-alphanumerics, so an OCR value whose characters are right but whose spacing or casing is
wrong is replaced by what the page actually prints. Values with no verbatim match are left
untouched, so a wrong reading cannot be "corrected" into a different wrong reading.

This is the mechanism that worked on UNIKIE-BENCH (Commercial 50.65 -> 52.49): emit the
page's own rendering rather than the model's paraphrase of it.
"""
import os
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import pipeline as P


def key(s):
    return "".join(ch.lower() for ch in str(s) if ch.isalnum())


def build_verbatim_set(pages, max_span=14):
    """Every verbatim span on the page, so an already-correct value is never touched."""
    seen = set()
    for text in pages:
        for line in text.splitlines():
            toks = line.split()
            for i in range(len(toks)):
                for j in range(i, min(len(toks), i + max_span)):
                    seen.add(" ".join(toks[i:j + 1]))
    return seen


def build_index(pages, max_span=14):
    """
    Map alphanumeric key -> verbatim span, built from consecutive words on each line.

    Indexed per line rather than across the whole page so a span cannot be assembled from
    text that never appeared together.
    """
    idx = {}
    counts = {}
    for text in pages:
        for line in text.splitlines():
            toks = line.split()
            for i in range(len(toks)):
                acc = []
                for j in range(i, min(len(toks), i + max_span)):
                    acc.append(toks[j])
                    span = " ".join(acc)
                    k = key(span)
                    if len(k) < 3:
                        continue
                    # keep the shortest verbatim rendering for a given key
                    prev = idx.get(k)
                    if prev is None or len(span) < len(prev):
                        idx[k] = span
                    d = counts.setdefault(k, set())
                    if len(d) < 3:
                        d.add(span)
    # Only keep keys with ONE distinct verbatim rendering. A correct value that wraps across
    # lines is not in the verbatim set, so without this it gets rewritten to some other span
    # sharing its key -- which is what cost ofac 74.44 -> 60.37 and 13F_0026 97.79 -> 90.29.
    return {k: v for k, v in idx.items() if len(counts.get(k, ())) == 1}


def snap_value(v, idx, verbatim=None):
    """
    Replace v with the page's own rendering only when v is NOT already verbatim.

    Without that check the snap actively corrupts correct values: the index keeps the
    shortest span for each key, so a correct value could be swapped for a shorter
    coincidental match elsewhere on the page. On ofac 31% of values were being rewritten
    and the case fell 74.44 -> 60.37. A short key is also unsafe, so the floor is raised.
    """
    if not isinstance(v, str) or not v.strip():
        return v, False
    k = key(v)
    if len(k) < 6:
        return v, False
    if verbatim is not None and v in verbatim:
        return v, False
    got = idx.get(k)
    if got is None or got == v:
        return v, False
    # Only repair the failure actually diagnosed: spacing. The measured defect is OCR
    # dropping spaces ('POBOX757' for 'PO BOX 757'), which the scorer counts as a mismatch
    # because it collapses whitespace RUNS but not absent whitespace. Matching on the
    # alphanumeric key alone also rewrote values whose difference was punctuation or case,
    # and those were usually already right: ofac fell 74.44 -> 60.37 and 13F_0026
    # 97.79 -> 90.29. Requiring the two to be identical once spaces are removed keeps the
    # oklahoma repair and drops the rest.
    if v.replace(" ", "") != got.replace(" ", ""):
        return v, False
    return got, True


def snap_obj(o, idx, stat):
    if isinstance(o, dict):
        return {k: snap_obj(x, idx, stat) for k, x in o.items()}
    if isinstance(o, list):
        return [snap_obj(x, idx, stat) for x in o]
    new, changed = snap_value(o, idx, stat.get("verbatim"))
    if changed:
        stat["snapped"] += 1
    elif isinstance(o, str) and o.strip():
        stat["kept"] += 1
    return new


def main():
    src = Path(sys.argv[1])
    dst = Path(sys.argv[2])
    dst.mkdir(parents=True, exist_ok=True)
    DATA = P.DATA
    names = [json.loads(l)["id"].split("/")[-1]
             for l in (DATA / (os.environ.get("EB_SPLIT", "long") + ".jsonl")).open() if l.strip()]
    for nm in names:
        f = src / f"{nm}.json"
        if not f.exists():
            continue
        pred = json.loads(f.read_text())
        pages = P.page_texts(DATA / "docs" / os.environ.get("EB_SPLIT", "long") / f"{nm}.pdf")
        if sum(len(p.strip()) for p in pages) < 50 * max(1, len(pages)):
            (dst / f"{nm}.json").write_text(json.dumps(pred))   # no text layer to snap to
            print(f"  {nm[:40]:40s} no text layer, passed through")
            continue
        idx = build_index(pages)
        stat = {"snapped": 0, "kept": 0, "verbatim": build_verbatim_set(pages)}
        out = snap_obj(pred, idx, stat)
        (dst / f"{nm}.json").write_text(json.dumps(out))
        tot = stat["snapped"] + stat["kept"]
        print(f"  {nm[:40]:40s} index={len(idx):8d}  snapped {stat['snapped']:6d} "
              f"of {tot:6d} ({100*stat['snapped']/max(1,tot):4.1f}%)")


if __name__ == "__main__":
    main()
