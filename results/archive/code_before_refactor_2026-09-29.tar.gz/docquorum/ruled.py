"""
Geometry of a ruled table on a scanned page: deskew it, then find the row rules.

Used where a model cannot be trusted to count. On ftx_corrupted most rows are identical
('NAME ON FILE' / 'ADDRESS ON FILE'); both the parser and the extractor fall into repetition
loops on them (208 parsed rows for a ~67-row page; 143 consecutive identical rows from the
extractor). The rules printed between table rows say exactly how many rows there are, so
the count comes from the page instead of from generation.

Deskew: the scan is rotated by a fraction of a degree, which smears every horizontal rule
across many pixel rows. The angle that makes the row-ink profile sharpest is the one that
makes the rules horizontal again.
"""
import numpy as np
from PIL import Image


def deskew(img, span=1.5, step=0.05):
    small = img.resize((img.width // 2, img.height // 2))
    best, best_a = -1, 0.0
    for a in np.arange(-span, span + 1e-9, step):
        r = np.asarray(small.rotate(a, resample=Image.BILINEAR, fillcolor=255)) < 128
        prof = r.sum(axis=1).astype(np.float64)
        s = float(((prof[1:] - prof[:-1]) ** 2).sum())
        if s > best:
            best, best_a = s, a
    return img.rotate(best_a, resample=Image.BILINEAR, fillcolor=255), best_a


def rules(img, min_frac=0.55, dark=140):
    """(top, bottom) of each horizontal rule: pixel rows mostly dark across the table."""
    a = np.asarray(img) < dark
    cols = np.where(a.mean(axis=0) > 0.02)[0]
    if len(cols) == 0:
        return []
    x0, x1 = cols.min(), cols.max()
    frac = a[:, x0:x1].mean(axis=1)
    ys = np.where(frac > min_frac)[0]
    out = []
    for y in ys:
        if out and y - out[-1][1] <= 2:
            out[-1][1] = y
        else:
            out.append([y, y])
    return [tuple(g) for g in out]


def row_bands(img, max_rows=12):
    """(header_crop, [(band_crop, n_rows), ...]) for a ruled table page, or None.

    Two header styles occur. ftx prints the header between two thin rules; imedia fills
    the header row solid, so its top and bottom borders merge into one thick dark band.
    Treating that band as a single thin rule swallowed the first data row on every imedia
    page (77 rows counted against 78 printed). A band much thicker than the other rules is
    therefore taken as the header itself, and the data rows start at its lower edge.
    """
    im, ang = deskew(img)
    groups = rules(im)
    if len(groups) < 4:
        return None, ang, groups
    thick = [b - a for a, b in groups]
    med = float(np.median(thick[1:]))
    mids = [(a + b) // 2 for a, b in groups]
    if thick[0] > 3 * med + 2:                       # filled header band
        header_box = (groups[0][0], groups[0][1])
        bounds = [groups[0][1]] + mids[1:]
    else:
        header_box = (mids[0], mids[1])
        bounds = mids[1:]
    W = im.width
    header = im.crop((0, max(0, header_box[0] - 4), W, header_box[1] + 4))
    rows = list(zip(bounds[:-1], bounds[1:]))
    bands = []
    for i in range(0, len(rows), max_rows):
        grp = rows[i:i + max_rows]
        bands.append((im.crop((0, max(0, grp[0][0] - 3), W, grp[-1][1] + 3)), len(grp)))
    return (header, bands), ang, groups
