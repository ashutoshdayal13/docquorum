"""
Split a multi-column register page into its columns before reading it.

real_oklahoma_unclaimed_2024 is the worst document on the long split (F1 ~21 against a
76.61 mean). It prints ~460 records per page in seven narrow columns, each an alphabetical
run of records, and the PDF has no text layer. Two things go wrong at once:

  * reading order -- the parser emits one table row per horizontal slice of the page, so
    reading left to right interleaves seven unrelated people, while gold reads each column
    top to bottom (PLAINS BRIDGE CONTRACTING, PORTER NATHANIEL, POWELL RICK E, ...);
  * resolution -- a whole page of small type in one pass gives "BT 1 ROY 320" for
    "RT 1 BOX 220" and merges records into "RITBOX220JOHNSONJOH".

Cropping to one column fixes both: the crop is read in the order the records run, and a
narrow strip reaches the model at native resolution instead of a downsampled page.

Column bounds come from the ink: a vertical projection of dark pixels has a wide, nearly
empty gutter between columns. No model, no gold.
"""
import os
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
import settings as _S
PDFTOPPM = _S.PDFTOPPM


def render(pdf, page, dpi=300):
    from PIL import Image
    with tempfile.TemporaryDirectory() as td:
        subprocess.run([PDFTOPPM, "-png", "-r", str(dpi), "-f", str(page), "-l", str(page),
                        str(pdf), str(Path(td) / "pg")], capture_output=True, timeout=600)
        f = sorted(Path(td).glob("pg*.png"))
        return Image.open(f[0]).convert("L").copy() if f else None


def column_spans(img, dark=160, gutter_frac=0.008, min_col_frac=0.05):
    """(x0, x1) of each text column, from runs of near-empty pixel columns.

    A pixel column counts as empty when almost none of its pixels are dark. A gap is a
    gutter only if it is at least `gutter_frac` of the page wide -- wide enough to skip the
    spaces between words inside a column, narrow enough to catch the separation between
    columns. Spans narrower than `min_col_frac` (rules, stray marks) are dropped.
    """
    import numpy as np
    a = np.asarray(img)
    H, W = a.shape
    body = a[int(0.06 * H):int(0.97 * H)]          # skip running header / footer
    ink = (body < dark).sum(axis=0)
    empty = ink <= max(2, int(0.001 * body.shape[0]))
    gut = max(3, int(gutter_frac * W))
    spans, x = [], 0
    while x < W:
        if empty[x]:
            x += 1
            continue
        x0 = x
        gap = 0
        while x < W:
            if empty[x]:
                gap += 1
                if gap >= gut:
                    break
            else:
                gap = 0
            x += 1
        x1 = x - gap
        if x1 - x0 >= min_col_frac * W:
            spans.append((x0, x1))
    return spans


def crops(pdf, page, dpi=300, pad=8):
    img = render(pdf, page, dpi)
    if img is None:
        return [], None
    W, H = img.size
    sp = column_spans(img)
    return [img.crop((max(0, x0 - pad), 0, min(W, x1 + pad), H)) for x0, x1 in sp], img


if __name__ == "__main__":
    pdf = _S.DATA / "docs" / os.environ.get("EB_SPLIT", "long") / (sys.argv[1] + ".pdf")
    pages = [int(x) for x in (sys.argv[2] if len(sys.argv) > 2 else "2,5,30").split(",")]
    for p in pages:
        img = render(pdf, p)
        if img is None:
            print(f"page {p}: render failed")
            continue
        sp = column_spans(img)
        print(f"page {p:3d} size={img.size} columns={len(sp)} "
              f"widths={[b - a for a, b in sp]}")
