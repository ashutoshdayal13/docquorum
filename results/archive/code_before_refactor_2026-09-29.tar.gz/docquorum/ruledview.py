"""
Extract a ruled scanned table in bands whose row count is fixed by the page's own rules.

ruled.py deskews the page and counts the rows between printed rules (63/63, 68/68, 67/67,
67/67 against gold on the pages checked, including the ones where the parser looped). Each
band of <= 12 rows is sent with the table's header row stacked above it, and the output
array is constrained to exactly that many items (minItems = maxItems = N): a repetition
loop has no room to add rows, and a skipped row has no way to go unnoticed.
"""
import os
import argparse
import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from openai import OpenAI
from PIL import Image

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import imgview as V
import ruled

# Instructions and schema come FIRST and are identical for every band of a document, so
# vLLM's prefix cache holds one copy of them; the image and the per-band count come after.
# With the image first no two requests shared a prefix, and the KV cache sat at 99.8%
# with half the requests queued.
PROMPT = """You will be shown an image cut from a scanned document: the header row of a
table followed by a band of data rows.

{task}You are collecting the list called "{array_name}".
{array_desc}
Each entry of that list is one JSON object with this schema:
{item_schema}

Return one entry for each data row below the header, top to bottom, copying each cell
exactly as printed. Rows that look identical are still separate rows. If a cell is blank
use null."""
TAIL = "This band is from page {page} and holds exactly {n} data rows; return exactly {n} entries."


def stack(header, band):
    W = max(header.width, band.width)
    out = Image.new("L", (W, header.height + band.height), 255)
    out.paste(header, (0, 0))
    out.paste(band, (0, header.height))
    return out


def do_page(client, pdf, page, dpi, meta):
    arr_name, item, arr_desc, guide, task = meta
    img = V.render(pdf, page, dpi)
    res, ang, ys = ruled.row_bands(img)
    if not res:
        return [], {"bands": 0, "rows": 0}
    header, bands = res
    rows = []
    for band, n in bands:
        schema = V.P.array_schema(guide, minItems=n, maxItems=n)
        prompt = PROMPT.format(task=task, array_name=arr_name,
                               array_desc=(arr_desc + "\n") if arr_desc else "",
                               item_schema=json.dumps(item, indent=1)[:16000])
        r = client.chat.completions.create(
            model=__import__("settings").MODEL, temperature=0.0, max_tokens=6000,
            messages=[{"role": "user", "content": [
                {"type": "text", "text": prompt},
                {"type": "image_url",
                 "image_url": {"url": f"data:image/png;base64,{V.b64(stack(header, band))}"}},
                {"type": "text", "text": TAIL.format(page=page, n=n)}]}],
            extra_body=V.P.extra_body(schema))
        try:
            got = json.loads(r.choices[0].message.content)
        except Exception:
            got = []
        for x in got:
            if isinstance(x, dict):
                x["source_page"] = page
                rows.append(x)
    return rows, {"bands": len(bands), "rows": sum(n for _, n in bands)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--doc", required=True)
    ap.add_argument("--pages", required=True)
    ap.add_argument("--out", default="runs/ruled_view")
    ap.add_argument("--dpi", type=int, default=200)
    ap.add_argument("--workers", type=int, default=8)
    args = ap.parse_args()
    recs = [json.loads(l) for l in (__import__("settings").DATA / (os.environ.get("EB_SPLIT", "long") + ".jsonl")).open() if l.strip()]
    rec = next(r for r in recs if r["id"].split("/")[-1] == args.doc)
    for k in ("data_schema", "expected_output"):
        if isinstance(rec.get(k), str):
            rec[k] = json.loads(rec[k])
    meta = V.build(rec)
    pdf = __import__("settings").DATA / "docs" / os.environ.get("EB_SPLIT", "long") / f"{args.doc}.pdf"
    pages = [int(x) for x in args.pages.split(",") if x]
    client = OpenAI(base_url=__import__("settings").LLM_URL, api_key="EMPTY",
                    timeout=1800, max_retries=4)
    t0, out = time.time(), []
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futs = {p: ex.submit(do_page, client, pdf, p, args.dpi, meta) for p in pages}
        for p in pages:
            got, st = futs[p].result()
            out.extend(got)
            print(f"  page {p:3d} bands={st['bands']} ruled-rows={st['rows']} got={len(got)}",
                  flush=True)
    dst = HERE / args.out
    dst.mkdir(parents=True, exist_ok=True)
    (dst / f"{args.doc}.json").write_text(json.dumps({meta[0]: out}))
    print(f"rows={len(out)} {time.time() - t0:.0f}s")


if __name__ == "__main__":
    main()
