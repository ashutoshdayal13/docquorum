"""
Generic column-flow reader: pages printed as several independent columns of records.

Generalises okextract.py, which was written for one document (a hand-written prompt about
unclaimed-property notices and a hard-coded two-field record). Here nothing is specific:

  * trigger -- page geometry, not schema wording: >= 3 text columns of near-equal width
    (coefficient of variation < 0.12) on most sampled pages. Table columns are never equal
    width (a name column is wide, a state column narrow), so tables do not trigger it;
    checked on all 20 long documents and 45 sampled short/medium ones.
  * prompt -- the document's own task description, array description and item schema, as
    for every other reader; the output is the schema's own item type under structured
    decoding, with the page stamped from where the crop came from.
  * continuations -- a record can begin at the foot of one column and finish at the top of
    the next. The model is asked to return such a leading fragment with the record's first
    required text field set to null; the fragment is then merged into the previous record
    (empty fields filled, text fields appended).
"""
import argparse, json, os, statistics, sys, time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from openai import OpenAI

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import okcols
import imgview as V

PROMPT = """You will be shown ONE column cut from a page of a document whose pages are
printed as several independent columns of records. Read this column top to bottom.

{task}You are collecting the list called "{array_name}".
{array_desc}
Each entry of that list is one JSON object with this schema:
{item_schema}

Return every entry of "{array_name}" in this column, top to bottom, copying values exactly
as printed. Headings that are not entries (section, county, city or category titles) are
not entries. If the column STARTS with the continuation of an entry that began in the
previous column (its first line is missing), return that fragment first with "{lead}" set
to null."""


def is_column_flow(pdf, npages, sample=4, min_cols=3, max_cv=0.12):
    pages = sorted({max(1, min(npages, p)) for p in
                    (2, npages // 3, (2 * npages) // 3, npages - 1)})[:sample]
    hits = 0
    for p in pages:
        img = okcols.render(pdf, p, dpi=100)
        if img is None:
            continue
        w = [b - a for a, b in okcols.column_spans(img)]
        if len(w) >= min_cols and statistics.pstdev(w) / statistics.mean(w) < max_cv:
            hits += 1
    return hits >= max(1, (len(pages) + 1) // 2)


def lead_field(item):
    props = item.get("properties") or {}
    for f in (item.get("required") or list(props)):
        t = (props.get(f) or {}).get("type")
        ts = t if isinstance(t, list) else [t]
        if "string" in ts and "page" not in f.lower():
            return f
    return next(iter(props), None)


def do_page(client, pdf, page, meta, lead, dpi):
    arr_name, item, arr_desc, guide, task = meta
    strips, _ = okcols.crops(pdf, page, dpi=dpi)
    g = dict(guide)
    g["properties"] = dict(guide["properties"])
    if lead in g["properties"]:                 # the lead field may be null for a fragment
        spec = dict(g["properties"][lead]); t = spec.get("type")
        if isinstance(t, str): spec["type"] = [t, "null"]
        elif isinstance(t, list) and "null" not in t: spec["type"] = t + ["null"]
        g["properties"][lead] = spec
    schema = V.P.array_schema(g, maxItems=400)
    prompt = PROMPT.format(task=task, array_name=arr_name, lead=lead,
                           array_desc=(arr_desc + "\n") if arr_desc else "",
                           item_schema=json.dumps(item, indent=1)[:16000])
    cols = []
    for s in strips:
        r = client.chat.completions.create(
            model=__import__("settings").MODEL, temperature=0.0, max_tokens=12000,
            messages=[{"role": "user", "content": [
                {"type": "text", "text": prompt},
                {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{V.b64(s)}"}},
                {"type": "text", "text": f"This column is from page {page}."}]}],
            extra_body=V.P.extra_body(schema))
        try:
            rows = json.loads(r.choices[0].message.content)
        except Exception:
            rows = []
        cols.append([x for x in rows if isinstance(x, dict)])
    return cols


def merge_into(prev, frag):
    for k, v in frag.items():
        if v in (None, "", []):
            continue
        if prev.get(k) in (None, "", []):
            prev[k] = v
        elif isinstance(v, str) and isinstance(prev.get(k), str) and k != "source_page":
            prev[k] = f"{prev[k]}, {v}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--doc", required=True)
    ap.add_argument("--out", default="runs/colflow")
    ap.add_argument("--pages", default="")
    ap.add_argument("--dpi", type=int, default=300)
    ap.add_argument("--workers", type=int, default=16)
    ap.add_argument("--scalars-from", default="")
    ap.add_argument("--force", action="store_true", help="skip the geometric trigger")
    a = ap.parse_args()
    split = os.environ.get("EB_SPLIT", "long")
    recs = [json.loads(l) for l in (__import__("settings").DATA / f"{split}.jsonl").open() if l.strip()]
    rec = next(r for r in recs if r["id"].split("/")[-1] == a.doc)
    for k in ("data_schema",):
        if isinstance(rec.get(k), str): rec[k] = json.loads(rec[k])
    meta = V.build(rec)
    pdf = __import__("settings").DATA / "docs" / split / f"{a.doc}.pdf"
    n = V.npages(pdf)
    if not a.force and not is_column_flow(pdf, n):
        print(f"{a.doc}: not a column flow; nothing to do"); return
    lead = lead_field(meta[1])
    pages = [int(x) for x in a.pages.split(",")] if a.pages else list(range(1, n + 1))
    client = OpenAI(base_url=__import__("settings").LLM_URL, api_key="EMPTY", timeout=1800, max_retries=4)
    t0, out = time.time(), []
    with ThreadPoolExecutor(max_workers=a.workers) as ex:
        futs = {p: ex.submit(do_page, client, pdf, p, meta, lead, a.dpi) for p in pages}
        for p in pages:
            cols = futs[p].result(); got = 0
            for col in cols:
                for x in col:
                    x["source_page"] = p
                    if x.get(lead) in (None, "") and out:
                        merge_into(out[-1], {k: v for k, v in x.items() if k != "source_page"})
                    else:
                        out.append(x); got += 1
            print(f"  page {p:3d} columns={len(cols)} records={got}", flush=True)
    base = {}
    if a.scalars_from and (Path(a.scalars_from) / f"{a.doc}.json").exists():
        base = {k: v for k, v in json.loads((Path(a.scalars_from) / f"{a.doc}.json").read_text()).items()
                if not isinstance(v, list)}
    base[meta[0]] = out
    Path(a.out).mkdir(parents=True, exist_ok=True)
    (Path(a.out) / f"{a.doc}.json").write_text(json.dumps(base))
    print(f"records={len(out)} {time.time() - t0:.0f}s")


if __name__ == "__main__":
    main()
