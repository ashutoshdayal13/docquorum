"""
Ground the COUNT of repeated records in the text layer.

Measured defect: on highly repetitive pages the reader loses count. ftx's creditor matrix
prints redacted creditors as identical 'NAME ON FILE / ADDRESS ON FILE' lines; the text
layer's count of that line per page equals the gold row count on every page checked
(35, 29, 49, 55, 37, 50, ...), while the extractions gave 131 on a page printing 35 and
123 on one printing 49 -- and 0 on pages next to them, whose rows were labelled with the
neighbour's page. (The MinerU parse repeats rows too, 234 on a page printing 50, so the
text layer is the reference.)

Records with identical content are interchangeable, so only their per-page COUNT can be
wrong, and the page's own text says what it is: a record is printed once per occurrence
of its least frequent value. For each repeated record (>= 3 identical copies):
  1. keep up to the page's occurrence count on the page it was labelled with;
  2. move the excess to the nearest page (within 2) that prints more copies than we have;
  3. drop what is still in excess -- copies the document does not print.
Nothing is invented and no value is changed. Documents whose text layer does not contain
the record's text (scans, corrupted layers) are left alone.

    python dupcap.py <run_dir> <out_dir>      (EB_SPLIT selects the records)
"""
import json
import os
import re
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import pipeline as P

_WS = re.compile(r"\s+")
PAGE_FIELD_RE = re.compile(r"^(source_)?page(_number|_no|_num)?$", re.I)
PRINTED_RE = re.compile(r"as printed|not the PDF|printed page numbering", re.I)


def norm(s):
    return _WS.sub(" ", s).strip().casefold()


def signature(row, pf):
    return json.dumps({k: v for k, v in row.items() if k != pf}, sort_keys=True)


def occurrences(row, pf, page_text):
    vals = [norm(v) for k, v in row.items() if k != pf and isinstance(v, str) and len(v.strip()) >= 4]
    if not vals:
        return None
    return min(page_text.count(v) for v in vals)


def cap_array(rows, pf, pages, stat):
    groups = defaultdict(list)
    for i, r in enumerate(rows):
        if isinstance(r, dict):
            groups[signature(r, pf)].append(i)
    drop = set()
    for sig, idx in groups.items():
        if len(idx) < 3:
            continue
        sample = rows[idx[0]]
        occ_doc = occurrences(sample, pf, "\n".join(pages))
        if not occ_doc:
            continue                          # text not in the layer: cannot ground
        if pf is None:
            if len(idx) > occ_doc:
                drop.update(idx[occ_doc:])
                stat["dropped"] += len(idx) - occ_doc
            continue
        occ = {p: occurrences(sample, pf, pages[p - 1]) or 0 for p in range(1, len(pages) + 1)}
        by_page = defaultdict(list)
        for i in idx:
            pg = rows[i].get(pf)
            by_page[int(pg) if isinstance(pg, (int, float)) or (isinstance(pg, str) and pg.isdigit()) else None].append(i)
        excess, room = [], {}
        for p, ids in by_page.items():
            cap = occ.get(p, 0) if p is not None else 0
            excess.extend((p, i) for i in ids[cap:])
        kept = {p: min(len(ids), occ.get(p, 0)) for p, ids in by_page.items() if p is not None}
        for p in range(1, len(pages) + 1):
            room[p] = occ[p] - kept.get(p, 0)
        for p, i in excess:
            target = None
            if p is not None:
                for d in (1, -1, 2, -2):
                    q = p + d
                    if 1 <= q <= len(pages) and room.get(q, 0) > 0:
                        target = q
                        break
            if target is None:
                drop.add(i)
                stat["dropped"] += 1
            else:
                room[target] -= 1
                old = rows[i][pf]
                rows[i][pf] = str(target) if isinstance(old, str) else target
                stat["moved"] += 1
    return [r for i, r in enumerate(rows) if i not in drop]


def main():
    src, dst = Path(sys.argv[1]), Path(sys.argv[2])
    dst.mkdir(parents=True, exist_ok=True)
    split = os.environ.get("EB_SPLIT", "long")
    for line in open(P.DATA / f"{split}.jsonl"):
        if not line.strip():
            continue
        rec = json.loads(line)
        schema = json.loads(rec["data_schema"]) if isinstance(rec["data_schema"], str) else rec["data_schema"]
        name = rec["id"].split("/")[-1]
        f = src / f"{name}.json"
        if not f.exists():
            continue
        pred = json.loads(f.read_text())
        pages = None
        for aname, item, _d in P.find_all_arrays(schema):
            rows = pred.get(aname)
            if not isinstance(rows, list) or len(rows) < 3:
                continue
            if pages is None:
                pdf = P.DATA / "docs" / rec["pdf"].replace("docs/", "", 1)
                pages = [norm(t) for t in P.page_texts(pdf)]
            if sum(len(t) for t in pages) < 50 * max(1, len(pages)):
                break                         # no text layer to count in
            pf = next((k for k in (item.get("properties") or {}) if PAGE_FIELD_RE.match(k)), None)
            if pf and PRINTED_RE.search(item["properties"][pf].get("description") or ""):
                # printed page numbers are not PDF indices, so per-page counts would be read
                # off the wrong page; cap at document level only (pagegrid places the rows)
                pf = None
            stat = {"dropped": 0, "moved": 0}
            before = len(rows)
            pred[aname] = cap_array(rows, pf, pages, stat)
            if stat["dropped"] or stat["moved"]:
                print(f"  {name[:40]:40s} {aname}: {before} -> {len(pred[aname])} rows "
                      f"(dropped {stat['dropped']}, moved {stat['moved']})", flush=True)
        (dst / f"{name}.json").write_text(json.dumps(pred))


if __name__ == "__main__":
    main()
