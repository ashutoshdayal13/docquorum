"""
Drop template rows: array records whose only filled cell is the row's printed label.

Measured defect: a W-14 prints a fixed casing grid (Surface / Intermediate / Long String /
Liner / Other). The schema says "Emit a row object only for rows that have at least one
filled cell", yet the reader returned all five rows, three of them carrying nothing but
the pre-printed label (precision 72 on three W-14s). A label alone is part of the form, not
something the filer entered, so it is not a record.

A row is a template row when exactly one of its cells is filled while at least one other
row of the same array has three or more filled cells, i.e. the array demonstrably has
records with content and this one has none. On the gold records this pattern is rare
(2 of 4,421 short rows, 1 of 13,146 medium, 0 of 89,538 long).

    python emptyrows.py <run_dir> <out_dir>
"""
import json
import os
import re
import sys
from pathlib import Path


def n_filled(row):
    return sum(1 for v in row.values() if v not in (None, "", [], {}))


_ZERO = re.compile(r"^\s*[$]?\s*0+(\.0+)?\s*$")


def blank_value(v):
    """Nothing printed: null, empty, or a bare zero ("0", "0.00", "$0.00")."""
    if v in (None, "", [], {}):
        return True
    if isinstance(v, bool):
        return False
    if isinstance(v, (int, float)):
        return v == 0
    if isinstance(v, str):
        return bool(_ZERO.match(v))
    if isinstance(v, dict):
        return all(blank_value(x) for x in v.values())
    return False


def blank_row(row):
    """A row with no printed content at all: a pre-printed empty line read as a record (a
    well form's four gatherer lines, each read as {name: null, amt: "0", id: null})."""
    return len(row) >= 2 and all(blank_value(v) for v in row.values())


BLANKROWS = os.environ.get("DQ_BLANKROWS", "1") == "1"


def strip(o, stat):
    if isinstance(o, dict):
        return {k: strip(v, stat) for k, v in o.items()}
    if isinstance(o, list):
        items = [strip(x, stat) for x in o]
        if BLANKROWS and items and all(isinstance(x, dict) for x in items):
            kept = [x for x in items if not blank_row(x)]
            stat["blank"] = stat.get("blank", 0) + len(items) - len(kept)
            items = kept
        rows = [x for x in items if isinstance(x, dict)]
        if len(rows) >= 2 and len(rows) == len(items):
            counts = [n_filled(x) for x in rows]
            if any(c >= 3 for c in counts):
                keep = [x for x, c in zip(rows, counts) if not (c == 1 and len(x) >= 4)]
                stat["dropped"] += len(rows) - len(keep)
                return keep
        return items
    return o


def main():
    src, dst = Path(sys.argv[1]), Path(sys.argv[2])
    dst.mkdir(parents=True, exist_ok=True)
    stat = {"dropped": 0}
    for f in sorted(src.glob("*.json")):
        if f.name.startswith("_"):
            continue
        (dst / f.name).write_text(json.dumps(strip(json.loads(f.read_text()), stat)))
    print(f"emptyrows: dropped {stat['dropped']} template rows -> {dst}")


if __name__ == "__main__":
    main()
