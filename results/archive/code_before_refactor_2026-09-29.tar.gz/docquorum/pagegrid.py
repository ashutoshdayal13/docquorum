"""
Assign each record's page from the document's own text, in document order.

Measured defect (pagefix.py, offset mode): it assumed the model always reports the PDF
index and translated every value through the page's printed folio. Once the task
description reached the prompt, the model often reported the PRINTED number itself, as the
schema asks, and the second translation scrambled it: on credit_strategies 375 of 588 page
values came out wrong, collapsing 19 printed pages onto 12. The same pattern cost
sm0801_eco (316 of 949), fidelity_northstar (415 of 712), blackrock_schedule (162 of 321)
and vg_divappr (156 of 340).

So the incoming value is not trusted at all. Every row is scored against every page by its
rare tokens (tokens printed on few pages, weighted by how few), and the page sequence is
solved jointly: records come out in document order, so the best NON-DECREASING sequence
is found by dynamic programming, and a row with no identifying text takes its neighbours'
page instead of a guess. The page is then reported the way the schema asks: the PDF index,
or, when the schema says the document's printed numbering differs from the PDF index, the
folio printed on that page.

A document is left alone unless its confidently located rows are themselves in page order
(>= 90% of consecutive pairs), which is what makes the order assumption safe.

    python pagegrid.py <run_dir> <out_dir>      (EB_SPLIT selects the records)
"""
import json
import os
import re
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import pipeline as P

CACHE = __import__("settings").PARSE_CACHE
PRINTED_RE = re.compile(r"as printed|not the PDF|printed page numbering", re.I)
TOKEN_RE = re.compile(r"[a-z0-9][a-z0-9.\-/]{3,}")
PAGE_FIELD_RE = re.compile(r"^(source_)?page(_number|_no|_num)?$", re.I)


def load_pages(split, name, pdf):
    """Per-page text: the text layer and the MinerU parse together when both exist and
    agree on the page count (the parse covers scans; the text layer is exact)."""
    layer = P.page_texts(pdf)
    d = CACHE / name
    parsed = [f.read_text(errors="ignore") for f in sorted(d.glob("*.txt"))] if d.is_dir() else []
    if parsed and len(parsed) == len(layer):
        return [a + "\n" + b for a, b in zip(layer, parsed)], parsed
    if sum(len(t.strip()) for t in layer) >= 50 * max(1, len(layer)):
        return layer, parsed
    return (parsed or layer), parsed


PAGE_OF_RE = re.compile(r"\bpage\s+(\d{1,4})\s+of\s+\d{1,4}\b", re.I)


def folio_map(pages):
    """pdf page (1-based) -> the number printed on it. Two printed forms are read: a
    'Page X of Y' label anywhere on the page (clinical listings print '(Page 1 of 65)'
    beside the listing title, one page after a cover), else the last short all-digit line
    (a folio alone beneath the running footer). Whichever form covers more pages wins, so a
    document is read with one convention throughout."""
    labelled, bare = {}, {}
    for i, t in enumerate(pages, 1):
        m = PAGE_OF_RE.search(t)
        if m:
            labelled[i] = int(m.group(1))
        for line in reversed(t.strip().splitlines()[-6:]):
            line = line.strip().strip("|*#- ")
            if line.isdigit() and len(line) <= 4:
                bare[i] = int(line)
                break
    raw = labelled if len(labelled) >= len(bare) else bare
    return smooth_folios(raw, len(pages))


def smooth_folios(raw, n_pages, reach=3):
    """Folios read off single pages are noisy: a lone '2' in a table cell was taken as
    page 21's folio on enotes (true 20), and the corrupted copy yielded no folio at all
    on six pages, which then fell back to the PDF index (off by one). Printed numbering
    is a run of constant offsets (pdf page - folio), so a page takes the offset its
    nearest detected neighbours on BOTH sides agree on -- filling gaps and overriding a
    lone outlier. Section breaks (the offset really changes) are left as read."""
    off = {i: i - f for i, f in raw.items()}
    out = dict(raw)
    for i in range(1, n_pages + 1):
        before = [off[j] for j in range(i - 1, max(0, i - reach) - 1, -1) if j in off][:1]
        after = [off[j] for j in range(i + 1, min(n_pages, i + reach) + 1) if j in off][:1]
        if before and after and before[0] == after[0]:
            if off.get(i) != before[0] and i - before[0] >= 1:
                out[i] = i - before[0]
    return out


_THOUSANDS = re.compile(r"(?<=\d),(?=\d{3}\b)")


def tokens(text):
    """Rare-token candidates. Thousands separators are removed first: without that a
    holding's share count and value ('12,345', '1,234,567') split into fragments shorter
    than a token, and only the security NAME voted -- which a summary page repeats, so
    vg_healthcare's rows drifted onto the summary page (99.82 -> 96.14)."""
    return set(TOKEN_RE.findall(_THOUSANDS.sub("", text.casefold())))


def token_index(pages, max_share=0.15):
    inv = {}
    for i, t in enumerate(pages, 1):
        for tok in tokens(t):
            inv.setdefault(tok, []).append(i)
    limit = max(2, int(len(pages) * max_share))
    return {tok: ps for tok, ps in inv.items() if len(ps) <= limit}


def row_votes(row, fields, inv):
    votes = Counter()
    for f in fields:
        v = row.get(f)
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            v = str(v)
        if not isinstance(v, str) or len(v) < 4:
            continue
        for tok in tokens(v):
            ps = inv.get(tok)
            if ps:
                w = 1.0 / len(ps)
                for p in ps:
                    votes[p] += w
    return votes


def monotone_assign(votes, n_pages, move_cost=0.05):
    """Best non-decreasing page sequence: sum of row votes minus a small cost per move."""
    NEG = float("-inf")
    pages = range(1, n_pages + 1)
    prev = [NEG] + [votes[0].get(p, 0.0) for p in pages]
    back = [list(range(n_pages + 1))]
    for v in votes[1:]:
        cur = [NEG] * (n_pages + 1)
        arg = [0] * (n_pages + 1)
        best_val, best_q = NEG, 0          # best previous score over pages q < p
        for p in pages:
            stay = prev[p]                 # same page as the previous row
            come = best_val - move_cost    # moved forward from an earlier page
            if stay >= come:
                cur[p], arg[p] = stay + v.get(p, 0.0), p
            else:
                cur[p], arg[p] = come + v.get(p, 0.0), best_q
            if prev[p] > best_val:
                best_val, best_q = prev[p], p
        back.append(arg)
        prev = cur
    p = max(pages, key=lambda q: prev[q])
    out = [0] * len(votes)
    for i in range(len(votes) - 1, -1, -1):
        out[i] = p
        p = back[i][p]
    return out


def arrays_with_page(schema):
    """(array name, item schema, page field) for top-level arrays whose items have a page."""
    out = []
    for aname, item, _d in P.find_all_arrays(schema):
        for f, spec in (item.get("properties") or {}).items():
            if PAGE_FIELD_RE.match(f) and isinstance(spec, dict):
                out.append((aname, item, f))
    return out


def fix_record(rec, pred, split, log=None):
    schema = rec["data_schema"]
    name = rec["id"].split("/")[-1]
    targets = arrays_with_page(schema)
    if not targets:
        return pred, None
    pdf = P.DATA / "docs" / rec["pdf"].replace("docs/", "", 1)
    pages, parsed = load_pages(split, name, pdf)
    if len(pages) < 2:
        return pred, None
    inv = token_index(pages)
    report = []
    for aname, item, pf in targets:
        rows = pred.get(aname)
        if not isinstance(rows, list):
            continue
        idx = [i for i, r in enumerate(rows) if isinstance(r, dict)]
        if len(idx) < 3:
            continue
        fields = [f for f in (item.get("properties") or {}) if f != pf]
        votes = [row_votes(rows[i], fields, inv) for i in idx]
        # order check on the confidently located rows only
        conf = []
        for v in votes:
            top = v.most_common(2)
            if top and (len(top) == 1 or top[0][1] >= 1.5 * top[1][1]) and top[0][1] >= 0.5:
                conf.append(top[0][0])
        if len(conf) < max(3, len(idx) // 5):
            report.append(f"{aname}: too few located rows ({len(conf)}/{len(idx)})")
            continue
        mono = sum(1 for a, b in zip(conf, conf[1:]) if b >= a) / max(1, len(conf) - 1)
        if mono < 0.9:
            report.append(f"{aname}: rows not in page order ({mono:.2f})")
            continue
        desc = (item["properties"][pf].get("description") or "")
        printed = bool(PRINTED_RE.search(desc))
        if not printed:
            # Where the schema asks for the PDF index the model's own page was the better
            # reading (ftx 84.47 -> 83.82, ftx_corrupted 92.80 -> 91.73 when overridden):
            # it labels pages by the same PDF-index markers the prompt shows it.
            report.append(f"{aname}.{pf}: pdf index, model's pages kept")
            continue
        seq = monotone_assign(votes, len(pages))
        fmap = folio_map(parsed or pages) if printed else {}
        changed = 0
        for i, pg in zip(idx, seq):
            new = fmap.get(pg, pg) if printed else pg
            spec = item["properties"][pf]
            t = spec.get("type")
            if (t == "string" or (isinstance(t, list) and "string" in t and "integer" not in t)):
                new = str(new)
            if rows[i].get(pf) != new:
                changed += 1
            rows[i][pf] = new
        report.append(f"{aname}.{pf}: {'printed' if printed else 'pdf'} located={len(conf)}/{len(idx)} "
                      f"order={mono:.2f} folios={len(fmap)} changed={changed}")
    return pred, report


def main():
    src, dst = Path(sys.argv[1]), Path(sys.argv[2])
    dst.mkdir(parents=True, exist_ok=True)
    split = os.environ.get("EB_SPLIT", "long")
    only = set(sys.argv[3].split(",")) if len(sys.argv) > 3 else None
    for line in open(P.DATA / f"{split}.jsonl"):
        if not line.strip():
            continue
        rec = json.loads(line)
        for k in ("data_schema", "expected_output"):
            if isinstance(rec.get(k), str):
                rec[k] = json.loads(rec[k])
        name = rec["id"].split("/")[-1]
        f = src / f"{name}.json"
        if not f.exists():
            continue
        pred = json.loads(f.read_text())
        if only is None or name in only:
            pred, rep = fix_record(rec, pred, split)
            if rep:
                print(f"  {name[:40]:40s} " + "; ".join(rep), flush=True)
        (dst / f"{name}.json").write_text(json.dumps(pred))


if __name__ == "__main__":
    main()
