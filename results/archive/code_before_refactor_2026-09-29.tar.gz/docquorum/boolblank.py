"""
A blank check box is `false` when the schema says so (`boolblank`).

Measured defect: RRC well forms describe every check box as "Boolean: true only if this box
is marked/checked on the scan, false if left blank", and the reader returns null for the
unmarked boxes -- 16-24 wrong values on each W-2 form (all false in the gold). The schema
itself states what a blank box means, so a null boolean becomes false wherever the field's
own description says false stands for a blank/unmarked/unchecked box, and does not also give
null a meaning. No model call, no annotation.

    python boolblank.py <run_dir> <out_dir>     (EB_SPLIT selects the records)
"""
import json
import os
import re
import sys
from pathlib import Path

FALSE_WHEN_BLANK = re.compile(
    r"false\s+(if|when|otherwise|for)\b[^.;]{0,60}?\b(blank|unmarked|unchecked|not\s+(marked|checked|"
    r"ticked|selected|filled)|empty|left\s+blank|otherwise)|false\s+otherwise", re.I)
NULL_MEANING = re.compile(r"\bnull\s+(if|when|only|for)\b", re.I)


def _defs(root):
    return root.get("$defs") or root.get("definitions") or {}


def _resolve(s, root, depth=0):
    while isinstance(s, dict) and "$ref" in s and depth < 20:
        s = _defs(root).get(s["$ref"].split("/")[-1], {})
        depth += 1
    return s if isinstance(s, dict) else {}


def _is_bool(s, root):
    s = _resolve(s, root)
    ts = s.get("type")
    ts = set(ts) if isinstance(ts, list) else {ts}
    for alt in s.get("anyOf") or []:
        a = _resolve(alt, root)
        t = a.get("type")
        ts |= set(t) if isinstance(t, list) else {t}
    ts -= {None, "null"}
    return ts == {"boolean"}


def blank_is_false(s, root):
    s = _resolve(s, root)
    d = s.get("description") or ""
    return _is_bool(s, root) and bool(FALSE_WHEN_BLANK.search(d)) and not NULL_MEANING.search(d)


def _branch(o, s, root):
    for alt in s.get("anyOf") or []:
        a = _resolve(alt, root)
        if isinstance(o, dict) and "properties" in a:
            return a
        if isinstance(o, list) and "items" in a:
            return a
    return s


def fix(o, s, root, stat):
    s = _branch(o, _resolve(s, root), root)
    if isinstance(o, dict) and isinstance(s.get("properties"), dict):
        out = dict(o)
        for k, sub in s["properties"].items():
            if k in out and out[k] is None and blank_is_false(sub, root):
                out[k] = False
                stat["filled"] = stat.get("filled", 0) + 1
            elif k in out:
                out[k] = fix(out[k], sub, root, stat)
        return out
    if isinstance(o, list) and isinstance(s.get("items"), dict):
        return [fix(x, s["items"], root, stat) for x in o]
    return o


def fix_record(pred, schema):
    schema = json.loads(schema) if isinstance(schema, str) else schema
    stat = {}
    return fix(pred, schema, schema, stat), stat


def main():
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import settings as _S
    src, dst = Path(sys.argv[1]), Path(sys.argv[2])
    dst.mkdir(parents=True, exist_ok=True)
    split = os.environ.get("EB_SPLIT", "long")
    n = 0
    for line in open(_S.DATA / f"{split}.jsonl"):
        if not line.strip():
            continue
        rec = json.loads(line)
        name = rec["id"].split("/")[-1]
        f = src / f"{name}.json"
        if not f.exists():
            continue
        out, stat = fix_record(json.loads(f.read_text()), rec["data_schema"])
        (dst / f.name).write_text(json.dumps(out))
        if stat.get("filled"):
            n += 1
            print(f"  {name[:40]:40s} {stat['filled']} blank boxes -> false", flush=True)
    print(f"boolblank: {n} documents changed")


if __name__ == "__main__":
    main()
