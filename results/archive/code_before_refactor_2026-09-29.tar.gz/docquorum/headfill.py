"""
Values that are printed once and govern the rows beneath them.

Two spellings of the same structure appear in the ExtractBench long-split schemas:

  * a section heading ("Industry heading the row sits under", "Asset-class band the
    holding sits under") -- printed once above a block of rows;
  * an explicit carry-forward ("Check number ...; printed only on the check's first
    line -- carry forward for continuation lines", "Subject number; carried forward
    on continuation rows").

Gold repeats the value on every row it governs -- `check_number` is filled on
3308/3308 gold rows. Our extractor emits it only where the ink sits and leaves the
rest null or empty, so the block is scored wrong for a reason that has nothing to do
with reading the page. Carrying the value down recovers it with no model call.

The field is identified from the description text the benchmark gives us as input;
no gold is read. The confusable case is a description using the same words about a
COLUMN of the row itself ("COLUMN 5 - VALUE", "column '23. UNIT PRICE'"), which is a
per-row value and must never be carried -- so the heading rule is vetoed by per-row
language, while an explicit carry-forward statement is taken at its word.
"""
import os
import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ebscore
from schemautil import find_all_arrays

# the schema says outright that the value carries -- decisive, no veto applied
CARRY_RE = re.compile(
    r"carried forward|carries forward|carry forward|continuation row|continuation line|"
    r"repeated? from the (previous|preceding) row|inherited from",
    re.I,
)
# the schema describes a heading/band that rows sit under
HEADING_RE = re.compile(r"\bheading\b|\bheader\b|sits under|top-level class", re.I)
# ... but not when it is talking about one row's own column or cell
PER_ROW_RE = re.compile(
    r"\bcolumn\b|\bthis item\b|\bthis row\b|\bthis line\b|\bthis cell\b", re.I
)


def scoped_fields(item_schema):
    out = []
    for name, spec in (item_schema.get("properties") or {}).items():
        if not isinstance(spec, dict):
            continue
        desc = spec.get("description") or ""
        if CARRY_RE.search(desc):
            out.append(name)
        elif HEADING_RE.search(desc) and not PER_ROW_RE.search(desc):
            out.append(name)
    return out


def _blank_elsewhere(row, fields):
    """True when the row has nothing of its own besides the scoped fields: a pre-printed empty
    line. A governing value (a heading, a check number) belongs to rows that carry data."""
    import emptyrows
    own = {k: v for k, v in row.items() if k not in fields}
    return bool(own) and all(emptyrows.blank_value(v) for v in own.values())


def fill(rows, fields, hier=False):
    """Carry each scoped value down the emitted row order. '' counts as missing:
    the extractor writes 4,859 empty strings where it means 'nothing printed here'."""
    if hier:
        fields = sorted(fields, key=lambda f: len(
            {str(r.get(f)) for r in rows if isinstance(r, dict) and r.get(f) not in (None, "")}))
    last, n = {}, 0
    for row in rows:
        if not isinstance(row, dict):
            continue
        for lvl, f in enumerate(fields):
            v = row.get(f)
            if v not in (None, ""):
                if hier and last.get(f) not in (None, v):
                    for lower in fields[lvl + 1:]:      # outer scope changed
                        last.pop(lower, None)
                last[f] = v
            elif f in last and not _blank_elsewhere(row, fields):
                row[f] = last[f]
                n += 1
    return n


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--hier", action="store_true")
    ap.add_argument("--only", default="", help="comma-separated field names, for ablation")
    args = ap.parse_args()
    src, dst = Path(args.run), Path(args.out)
    dst.mkdir(parents=True, exist_ok=True)
    keep = set(args.only.split(",")) if args.only else None

    recs = {r["id"].split("/")[-1]: r for r in ebscore.load_records(os.environ.get("EB_SPLIT", "long"))}
    total, touched = 0, []
    for name, rec in recs.items():
        f = src / f"{name}.json"
        if not f.exists():
            continue
        pred = json.loads(f.read_text())
        filled, flds = 0, []
        for aname, item, _d in find_all_arrays(rec["data_schema"]):
            sf = scoped_fields(item)
            if keep is not None:
                sf = [x for x in sf if x in keep]
            rows = pred.get(aname)
            if sf and isinstance(rows, list) and rows:
                filled += fill(rows, sf, args.hier)
                flds += sf
        if filled:
            touched.append((filled, name, ",".join(sorted(set(flds)))))
        total += filled
        (dst / f"{name}.json").write_text(json.dumps(pred))
    touched.sort(reverse=True)
    print(f"carried {total} values across {len(touched)} documents"
          f"{'  [hierarchical scope reset]' if args.hier else ''}")
    for nf, name, flds in touched:
        print(f"  {nf:6d}  {name[:38]:38s} {flds[:70]}")


if __name__ == "__main__":
    main()
