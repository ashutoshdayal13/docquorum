"""
Ground page provenance in the document instead of asking the model for it.

`source_page` is 71,082 of the ~412k gold field values on the long split -- 17% of
everything scored -- and the extractor gets 30.0% of them right. Two separable causes:

1. The schema for four documents says outright: "This document's printed page numbering
   is offset from the PDF page index; report the number printed on the page, not the PDF
   page position." The pipeline reported the PDF index, so every value was wrong by a
   constant: +7 on 99% of credit_strategies rows, +2 on 96% of ishares rows. The printed
   folio is sitting in the parsed text as the page's trailing number
   ("CONSOLIDATED SCHEDULE OF INVESTMENTS\n1"), so it can just be read off.

2. Where the numbering is not offset, the model still guesses: 21-34% correct on ftx,
   26% on sm0801_ae. A chunk spans several pages, so the model has no reliable way to
   say which one a row came from -- but we can look it up, because the row's own text is
   printed on exactly one page.

Neither step uses gold. Both read only the parsed document and the schema description
the benchmark supplies as input.
"""
import os
import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ebscore
from schemautil import find_all_arrays

CACHE = __import__("settings").PARSE_CACHE
PRINTED_RE = re.compile(r"as printed|not the PDF|printed page numbering", re.I)
_WS = re.compile(r"\s+")


def page_texts(doc):
    d = CACHE / doc
    if not d.is_dir():
        return []
    return [f.read_text(errors="ignore") for f in sorted(d.glob("*.txt"))]


def folio_map(pages):
    """pdf page (1-based) -> the page number printed on it, where one is printed.

    The folio sits on a line of its own beneath the running footer
    ("CONSOLIDATED SCHEDULE OF INVESTMENTS" / "1"), so take the last line that is
    nothing but an integer; matching any trailing number instead picks digits out of
    table cells ("501,737" -> "737").

    A map, not a single offset, because the numbering is sectioned: in
    credit_strategies the schedule pages (pdf 8-26) print 1-19 while pdf page 30
    prints 33, so no constant shift describes the document. Translating each page
    through its own printed number handles both.
    """
    out = {}
    for i, t in enumerate(pages, 1):
        for line in reversed(t.strip().splitlines()[-6:]):
            line = line.strip().strip("|*# ")
            if line.isdigit() and len(line) <= 4:
                out[i] = int(line)
                break
    return out


TOKEN_RE = re.compile(r"[a-z0-9]{4,}")


def build_index(pages, max_pages_per_token=8):
    """token -> pages carrying it, keeping only tokens rare enough to identify a page.

    Whole-value substring lookup is too brittle: the extractor reconstructs a value
    rather than copying it ("Aby Liquid Credit CLO Ltd., Series 2025-2A, Class C" for a
    row printed with its coupon and maturity appended), and joins cells together
    ("EATON BETHINA PT 1 BOX 230"), so the string is absent from every page even though
    the row plainly came from one. Rare tokens survive both.
    """
    inv = {}
    for i, t in enumerate(pages, 1):
        for tok in set(TOKEN_RE.findall(t.casefold())):
            inv.setdefault(tok, []).append(i)
    return {tok: ps for tok, ps in inv.items() if len(ps) <= max_pages_per_token}


def locate(values, inv, margin=2):
    """The page best supported by this row's rare tokens, or None if it is not clear.

    `margin` is how far ahead of the runner-up the winner must be, so a row whose
    tokens are spread over two pages is left to the model rather than guessed.
    """
    votes = Counter()
    for v in values:
        if not isinstance(v, str) or len(v) < 4:
            continue
        for tok in set(TOKEN_RE.findall(v.casefold())):
            for pg in inv.get(tok, ()):  # absent when the token is not page-identifying
                votes[pg] += 1
    if not votes:
        return None
    top = votes.most_common(2)
    if len(top) == 1:
        return top[0][0] if top[0][1] >= margin else None
    return top[0][0] if top[0][1] - top[1][1] >= margin else None


def row_key_fields(item, gold_rows_unused=None):
    """Fields worth locating: free-text identifiers, longest first at use time."""
    out = []
    for f, spec in (item.get("properties") or {}).items():
        if not isinstance(spec, dict):
            continue
        t = spec.get("type")
        types = t if isinstance(t, list) else [t]
        if "string" in types or "anyOf" in spec:
            if "page" not in f.lower():
                out.append(f)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--no-locate", action="store_true", help="offset fix only")
    ap.add_argument("--no-offset", action="store_true", help="locate fix only")
    args = ap.parse_args()
    src, dst = Path(args.run), Path(args.out)
    dst.mkdir(parents=True, exist_ok=True)

    recs = {r["id"].split("/")[-1]: r for r in ebscore.load_records(os.environ.get("EB_SPLIT", "long"))}
    for name, rec in sorted(recs.items()):
        f = src / f"{name}.json"
        if not f.exists():
            continue
        pred = json.loads(f.read_text())
        pages = page_texts(name)
        report = []
        for aname, item, _d in find_all_arrays(rec["data_schema"]):
            props = item.get("properties") or {}
            if "source_page" not in props:
                continue
            rows = [r for r in (pred.get(aname) or []) if isinstance(r, dict)]
            if not rows or not pages:
                continue
            desc = props["source_page"].get("description") or ""
            wants_printed = bool(PRINTED_RE.search(desc))
            fmap = {}
            if wants_printed and not args.no_offset:
                fmap = folio_map(pages)
            inv = build_index(pages) if not args.no_locate else {}
            kf = row_key_fields(item)
            located = changed = translated = 0
            for r in rows:
                pdf_page = locate([r.get(f) for f in kf], inv) if inv else None
                if pdf_page is not None:
                    located += 1
                else:
                    # fall back to the page the model itself named, which is a PDF index
                    mv = r.get("source_page")
                    pdf_page = int(mv) if isinstance(mv, (int, float)) else None
                if pdf_page is None:
                    continue
                new = fmap.get(pdf_page, pdf_page) if fmap else pdf_page
                if fmap and pdf_page in fmap:
                    translated += 1
                if r.get("source_page") != new:
                    changed += 1
                r["source_page"] = new
            report.append(f"folios={len(fmap)} located={located}/{len(rows)} "
                          f"translated={translated} changed={changed}")
        if report:
            print(f"  {name[:36]:36s} " + "; ".join(report))
        (dst / f"{name}.json").write_text(json.dumps(pred))


if __name__ == "__main__":
    main()
