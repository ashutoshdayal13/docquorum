"""
Convert a parsed table to records directly when its header names the schema's fields.

The corrupted ftx scan parses cleanly -- one well-formed 9-column HTML table per page,
headed 'Name | Address1 | ... | PostalCode | Country' -- yet the extractor turned page 4's
65 rows into 147, 143 of them consecutive 'NAME ON FILE'. Most rows on these pages are
genuinely identical ('NAME ON FILE' / 'ADDRESS ON FILE'), and once the model enters such a
run it cannot count its way out. That happens reading the parse text AND reading the page
image under structured decoding, so it is a property of generating the rows, not of
either input.

When the parsed header maps onto the schema's field names, there is nothing left for a
model to decide: each table row is a record and each cell a field. Converting it
deterministically cannot loop, drop a row, or invent one.

Per page, the tool is chosen from the parse's own health, with no gold:
  * a table whose header maps onto the schema, with a row count near the document's
    median           -> convert it directly;
  * anything else     -> the page is listed for the page-image extractor (imgview.py).
imedia_corrupted needs both: most pages parse cleanly, but page 1 is LaTeX junk repeated
441 times and page 22 invents a 327-row table where the page prints ~74 rows.
"""
import os
import argparse
import html
import json
import re
import statistics
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from schemautil import find_all_arrays

ROW = re.compile(r"<tr[^>]*>(.*?)</tr>", re.S | re.I)
CELL = re.compile(r"<t[dh][^>]*>(.*?)</t[dh]>", re.S | re.I)


def key(s):
    return re.sub(r"[^a-z0-9]", "", s.lower())


def table_rows(text):
    for tb in re.findall(r"<table[^>]*>.*?</table>", text, re.S | re.I):
        yield [[" ".join(html.unescape(re.sub(r"<[^>]+>", " ", c)).split())
                for c in CELL.findall(r)] for r in ROW.findall(tb)]


def header_map(header, fields):
    """column index -> schema field, by exact match of the normalised names."""
    fk = {key(f): f for f in fields}
    out = {}
    for i, h in enumerate(header):
        f = fk.get(key(h))
        if f and f not in out.values():
            out[i] = f
    return out


def convert_doc(name, rec, cache, min_cover=0.7):
    arrs = find_all_arrays(rec["data_schema"])
    if not arrs:                       # a form with single fields only: no table to convert
        return None
    aname, item, _ = arrs[0]
    fields = [f for f in (item.get("properties") or {}) if "page" not in f.lower()]
    pdir = cache / name
    if not pdir.is_dir():
        return None
    # First pass: learn the column mapping from pages whose table carries its header.
    # A table that continues onto a page without repeating the header is the same table,
    # so a headerless table of the same width reuses the mapping learned here.
    texts = {int(f.stem): f.read_text(errors="ignore") for f in sorted(pdir.glob("*.txt"))}
    learned = {}
    for t in texts.values():
        for rows in table_rows(t):
            if rows:
                m = header_map(rows[0], fields)
                if len(m) >= min_cover * len(fields):
                    learned.setdefault(len(rows[0]), m)
    pages = {}
    for pg, t in texts.items():
        recs, ok = [], False
        for rows in table_rows(t):
            if not rows:
                continue
            m = header_map(rows[0], fields)
            body = rows[1:]
            if len(m) < min_cover * len(fields):
                m = learned.get(len(rows[0]))
                if not m:
                    continue
                body = rows                      # headerless continuation
            ok = True
            w = len(rows[0])
            for r in body:
                if len(r) != w or [key(c) for c in r] == [key(c) for c in rows[0]]:
                    continue
                if not any(r):
                    continue
                d = {f: None for f in fields}
                for i, fld in m.items():
                    d[fld] = r[i] or None
                d["source_page"] = pg
                recs.append(d)
        pages[pg] = (ok, recs)
    counts = [len(r) for ok, r in pages.values() if ok and r]
    if not counts:
        return aname, {}, sorted(pages)
    med = statistics.median(counts)
    good, bad = {}, []
    for pg, (ok, r) in sorted(pages.items()):
        if ok and 0.5 * med <= len(r) <= 1.6 * med:
            good[pg] = r
        else:
            bad.append(pg)
    return aname, good, bad


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--docs", required=True)
    ap.add_argument("--cache", default=str(__import__("settings").PARSE_CACHE))
    ap.add_argument("--out", default="runs/tabconv")
    ap.add_argument("--scalars-from", default="runs/sf_set")
    args = ap.parse_args()
    import ebscore
    recs = {r["id"].split("/")[-1]: r for r in ebscore.load_records(os.environ.get("EB_SPLIT", "long"))}
    dst = Path(args.out)
    dst.mkdir(parents=True, exist_ok=True)
    for name in args.docs.split(","):
        res = convert_doc(name, recs[name], Path(args.cache))
        if res is None:
            print(f"  {name}: no parse cache")
            continue
        aname, good, bad = res
        base = {}
        sf = Path(args.scalars_from) / f"{name}.json"
        if sf.exists():
            base = {k: v for k, v in json.loads(sf.read_text()).items()
                    if not isinstance(v, list)}
        base[aname] = [r for pg in sorted(good) for r in good[pg]]
        (dst / f"{name}.json").write_text(json.dumps(base))
        (dst / f"{name}.fallback_pages").write_text(",".join(map(str, bad)))
        print(f"  {name}: converted {len(good)} pages / {len(base[aname])} rows; "
              f"fallback to image for {len(bad)} pages: {bad[:12]}{'...' if len(bad) > 12 else ''}")


if __name__ == "__main__":
    main()
