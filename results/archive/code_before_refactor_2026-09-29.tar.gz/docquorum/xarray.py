"""
Drop rows one array copied from another.

Measured defect: pueblo's register has 511 checks and 51 batch subtotals; its schema gives
`batches` no description, only the field names, and the chunked reader filed every check
line under `batches` as well (562 rows; precision 73.55). A printed line is one record:
when a row of array B carries ALL its distinctive values together inside a single row of
array A, it is the same printed line read twice.

Distinctive values are strings of >= 4 characters and numbers with >= 3 digits (a two-digit
batch year or a page number identifies nothing). A row needs >= 2 of them to be judged, and
an array is cleaned only when most of its judged rows (>= 50%) are copies -- contamination
at scale, not a coincidental shared amount.

A copy counts only when some value moved to a DIFFERENTLY named field (pueblo: a check's
check_number became a batch_number). Aggregates legitimately repeat their only member in
same-named fields -- wright_co_mn's gold has 146 single-line vendors whose subtotal row
equals their line (vendor_name -> vendor_name, amount -> amount) -- and are kept.

    python xarray.py <run_dir> <out_dir>
"""
import json
import re
import sys
from pathlib import Path

_WS = re.compile(r"\s+")


def distinctive(row):
    """value -> field it sits in, for the values that can identify a printed line."""
    out = {}
    for k, v in row.items():
        if isinstance(v, bool) or v is None:
            continue
        if isinstance(v, (int, float)):
            s = str(v)
            if sum(ch.isdigit() for ch in s) >= 3:
                out[s] = k
        elif isinstance(v, str):
            s = _WS.sub(" ", v).strip().casefold()
            if len(s) >= 4:
                out[s] = k
    return out


def clean(pred, stat):
    arrays = {k: v for k, v in pred.items()
              if isinstance(v, list) and len(v) >= 3 and all(isinstance(x, dict) for x in v)}
    if len(arrays) < 2:
        return pred
    sets = {k: [distinctive(r) for r in v] for k, v in arrays.items()}
    for b, rows_b in arrays.items():
        for a in arrays:
            if a == b:
                continue
            index = {}
            for i, s in enumerate(sets[a]):
                for val in s:
                    index.setdefault(val, set()).add(i)
            judged, copies = 0, []
            for j, s in enumerate(sets[b]):
                if len(s) < 2:
                    continue
                judged += 1
                common = None
                for val in s:
                    hit = index.get(val, set())
                    common = hit if common is None else common & hit
                    if not common:
                        break
                if common:
                    src = sets[a][min(common)]
                    if any(src.get(val) != fld for val, fld in s.items()):
                        copies.append(j)
            if judged and len(copies) >= 0.5 * judged and len(copies) >= 3:
                drop = set(copies)
                pred[b] = [r for j, r in enumerate(rows_b) if j not in drop]
                stat.append(f"{b}: {len(rows_b)} -> {len(pred[b])} (copies of {a})")
                break
    return pred


def main():
    src, dst = Path(sys.argv[1]), Path(sys.argv[2])
    dst.mkdir(parents=True, exist_ok=True)
    for f in sorted(src.glob("*.json")):
        if f.name.startswith("_"):
            continue
        stat = []
        out = clean(json.loads(f.read_text()), stat)
        if stat:
            print(f"  {f.stem[:40]:40s} " + "; ".join(stat))
        (dst / f.name).write_text(json.dumps(out))


if __name__ == "__main__":
    main()
