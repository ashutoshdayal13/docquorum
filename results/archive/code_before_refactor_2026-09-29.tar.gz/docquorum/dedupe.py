"""
Collapse repeated records where the schema says the list is keyed by an identifier.

gov_clin_0005 has 13 gold rows, one per CLIN, and we emit 29 -- item_no '0007' eight
times, '0008' four times -- because each CLIN's funding sub-lines print as separate
lines and the extractor reports a row per line. Every extra row is a false positive on
all twelve fields, on a document worth 5% of the mean.

Whether the list is a set or a bag is stated in the ARRAY description, and only there:

  dd1155   "DEDUPLICATED list ... EACH CLIN/SLIN APPEARS EXACTLY ONCE ... IT IS A
            SET-VALUED FIELD KEYED BY item_number, NOT A BAG OF EVERY MENTION"
  gov_clin "One entry per CLIN block where a fresh 'ITEM NO' header introduces a new
            ... identifier"
  sf1449   "Ordered list of every line item that appears"        -> a bag: 70 gold rows
                                                                    over 9 item_no
  ofac     "one record per entity NAME per directive section, so the same entity
            appears multiple times"                              -> a bag: 1,238 rows
                                                                    over 1,172 names

The field descriptions do not carry this: sf1449's item_no calls itself unique while
gold repeats it 61 times in 70 rows, so keying off the field text would delete most of
that document. Hence the test is on the array text only.

A veto on phrases like "appears multiple times" would be wrong -- in both set-valued
documents that phrasing is part of the instruction TO deduplicate ("DEDUPLICATE: if the
same CLIN appears multiple times across the primary contract's base + modifications",
"NOT A BAG OF EVERY MENTION") -- so the positive test stands alone. It selects the four
set-valued arrays and leaves sf1449 and ofac alone, which is what gold asks for.
"""
import os
import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ebscore
from schemautil import find_all_arrays

SET_RE = re.compile(
    r"deduplicate|exactly once|at most once|set-valued|one entry per", re.I)
# "Do NOT deduplicate across pages or merge rows that look similar" -- the 13F schemas
# say the word inside a prohibition, and collapsing them cost 220 of 3,063 gold rows.
NEG_RE = re.compile(r"(do not|don't|never|must not|no)\s*$", re.I)
# dd1155: "Update or merge into the first LineItem instead"
# gov_clin: "emit it EXACTLY ONCE -- use the LATEST printed values (the conformed state
# after all mods)" -- so which copy wins is also stated, and differs between them.
LATEST_RE = re.compile(r"latest printed value|use the latest|conformed state", re.I)
KEYED_RE = re.compile(r"keyed by\s+`?(\w+)`?", re.I)


def asserts_set(adesc):
    """True when the array text says the list is keyed, ignoring prohibitions."""
    for m in SET_RE.finditer(adesc or ""):
        before = adesc[max(0, m.start() - 24):m.start()]
        if not NEG_RE.search(before.strip()):
            return True
    return False


BAG_UNIT_RE = re.compile(r"one (entry|record|row|object|item) per (data |table |printed )?(row|line|record|mention)", re.I)


def _norm(x):
    return re.sub(r"[^a-z0-9]", "", x.lower())


def key_field(item, adesc):
    """The field the list is keyed by -- only when the text names it.

    The first version fell back to the item's FIRST property when no key was named. That
    held on gov_clin (item_no comes first) and failed on a Caterpillar spec sheet whose text
    says "one entry per data row" -- a bag, not a set -- where it keyed on `section` and
    collapsed 35 rows into 6 (-5.7 F1 on the short development set). Now the key must be
    named: "KEYED BY item_number", or a field / its printed label ('ITEM NO' -> item_no)
    within the sentence that asserts the set. "one entry per (data) row/line/record" is a
    bag and never collapses.
    """
    props = list((item.get("properties") or {}).keys())
    m = KEYED_RE.search(adesc or "")
    if m and m.group(1) in props:
        return m.group(1)
    if BAG_UNIT_RE.search(adesc or ""):
        return None
    nk = {_norm(f): f for f in props}
    for mm in SET_RE.finditer(adesc or ""):
        window = adesc[mm.start():mm.end() + 160]
        for tok in re.findall(r"'([^']{2,40})'|`([^`]{2,40})`|\b([A-Za-z_]{3,40})\b", window):
            cand = _norm(next(t for t in tok if t))
            if cand in nk:
                return nk[cand]
    return None


def collapse(rows, kf, latest=False):
    """One row per key, in first-seen order, filling blanks from the later copies.

    The repeated lines are the same record continued -- the sub-lines carry the ACRN and
    funding detail the first line leaves blank -- so merging recovers those fields
    instead of discarding them with the duplicate.

    `latest` overwrites with the last copy's values rather than only filling blanks,
    for the arrays whose text asks for the conformed state after all modifications.
    """
    out, seen = [], {}
    for r in rows:
        if not isinstance(r, dict):
            continue
        k = str(r.get(kf))
        if k in ("None", ""):
            out.append(r)
            continue
        if k not in seen:
            seen[k] = r
            out.append(r)
        else:
            tgt = seen[k]
            for f, v in r.items():
                if v in (None, ""):
                    continue
                if latest or tgt.get(f) in (None, ""):
                    tgt[f] = v
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    src, dst = Path(args.run), Path(args.out)
    dst.mkdir(parents=True, exist_ok=True)
    recs = {r["id"].split("/")[-1]: r for r in ebscore.load_records(os.environ.get("EB_SPLIT", "long"))}
    for name, rec in sorted(recs.items()):
        f = src / f"{name}.json"
        if not f.exists():
            continue
        pred = json.loads(f.read_text())
        for aname, item, adesc in find_all_arrays(rec["data_schema"]):
            ad = adesc or ""
            if not asserts_set(ad):
                continue
            kf = key_field(item, ad)
            rows = pred.get(aname)
            if not (kf and isinstance(rows, list) and rows):
                continue                       # no key named: never collapse
            new = collapse(rows, kf, latest=bool(LATEST_RE.search(ad)))
            if len(new) != len(rows):
                print(f"  {name[:36]:36s} {aname}: {len(rows)} -> {len(new)} rows "
                      f"(keyed by {kf}"
                      f"{', latest wins' if LATEST_RE.search(ad) else ', merge into first'})")
            pred[aname] = new
        (dst / f"{name}.json").write_text(json.dumps(pred))


if __name__ == "__main__":
    main()
