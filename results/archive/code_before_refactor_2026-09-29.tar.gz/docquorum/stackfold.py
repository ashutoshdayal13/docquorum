"""
Assemble records that print as several stacked lines.

The CSR adverse-event listing prints one record across three lines: the verbatim term
with its onset date on line 1, the MedDRA preferred term with the resolved date on
line 2, the system organ class on line 3. The extractor emits one row per LINE, so 666
gold records come back as 1,172 rows and every line-2/line-3 value lands in the wrong
field:

  gold   R1002 Irritability   onset 2009-03-22  resolved 2009-03-27  SOC 'General Dis...'
  ours   R1002 Irritability   onset 2009-03-22  resolved UNK
         R1002 Irritability   onset 2009-03-27                       <- the resolved date
         R1002 'General Dis...'                                      <- the SOC as an event

That is why system_organ_class is filled on 48% of our rows against 84% of gold's, and
resolved_time on 5% against 86%: the values were read correctly and filed under the
wrong record.

The layout is declared in the schema, which is an input: preferred_term is "(second
stacked line)" and system_organ_class is "(third stacked line)". So the number of lines
per record, and which field each line carries, are read from the schema rather than
assumed. Only one array on the long split declares this.
"""
import os
import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ebscore
from schemautil import find_all_arrays

ORD = {"first": 1, "second": 2, "third": 3, "fourth": 4, "fifth": 5}
LINE_RE = re.compile(r"\b(first|second|third|fourth|fifth)\s+stacked\s+line\b", re.I)


def line_fields(item):
    """{line number: field carried on that line}, from the schema text."""
    out = {}
    for f, spec in (item.get("properties") or {}).items():
        if not isinstance(spec, dict):
            continue
        m = LINE_RE.search(spec.get("description") or "")
        if m:
            out[ORD[m.group(1).lower()]] = f
    return out


def primary_field(item, key):
    """The column the stacked lines all print in -- required, textual, not the key."""
    req = item.get("required") or []
    props = item.get("properties") or {}
    for f in req:
        if f == key or "page" not in f.lower():
            spec = props.get(f) or {}
            t = spec.get("type")
            types = t if isinstance(t, list) else [t]
            if f != key and ("string" in types or "anyOf" in spec):
                return f
    return None


def suffix_pairs(props, skip):
    """Field pairs naming the same quantity at two stages: onset_date / resolved_date.

    `skip` excludes the fields the stacked lines themselves carry. Without it
    verbatim_term / preferred_term pair on their shared "term" tail, and line 3's text
    (the organ class) is copied into preferred_term as well as into its own field.
    """
    by_tail = {}
    for f in props:
        if "_" in f and f not in skip:
            by_tail.setdefault(f.rsplit("_", 1)[1], []).append(f)
    return [tuple(v) for v in by_tail.values() if len(v) == 2]


def filled(row, props):
    return sum(1 for p in props if row.get(p) not in (None, "", []))


def needs_fold(rows, item, lf, prim, min_gap=0.20):
    """Did this view emit a row per LINE, or already a row per record?

    Folding a view that already emits one row per record destroys records: the text view
    returned 593 rows for 666 gold and folding took it to 549, costing 2.9 F1 on the
    document and 0.15 on the routed mean.

    The signal is how empty the later-line fields are relative to the first-line field.
    When the lines are separate rows, their values are filed under those rows instead of
    the record's, so the annotated fields starve:

        gold            verbatim_term 100.0%  preferred 92.5%  organ_class 83.8%  gap +11.9
        text view       100.0%                91.9%            86.0%              gap +11.0
        parse view       99.2%                68.8%            48.1%              gap +40.8
        30B view         97.8%                69.3%            62.0%              gap +32.1

    So a gap far above what a correctly assembled list shows means the rows are lines.
    """
    def fill(f):
        return sum(1 for r in rows if isinstance(r, dict)
                   and r.get(f) not in (None, "", [])) / max(1, len(rows))
    later = [fill(lf[k]) for k in sorted(lf) if k > 1]
    if not later:
        return False
    return fill(prim) - sum(later) / len(later) >= min_gap


def fold(rows, item, key):
    lf = line_fields(item)
    n_lines = max(lf) if lf else 1
    props = list((item.get("properties") or {}).keys())
    prim = primary_field(item, key)
    if not prim or n_lines < 2:
        return rows, 0
    if not needs_fold(rows, item, lf, prim):
        return rows, 0
    pairs = suffix_pairs(props, set(lf.values()) | {prim, key})

    groups, cur = [], []
    for r in rows:
        if not isinstance(r, dict):
            continue
        if cur and str(r.get(key)) == str(cur[0].get(key)) and len(cur) < n_lines \
                and filled(r, props) < filled(cur[0], props):
            cur.append(r)          # a continuation line: same record, fewer columns inked
        else:
            if cur:
                groups.append(cur)
            cur = [r]
    if cur:
        groups.append(cur)

    out = []
    for grp in groups:
        rec = dict(grp[0])
        for idx, cont in enumerate(grp[1:], start=2):
            tgt = lf.get(idx)
            if tgt:
                rec[tgt] = cont.get(prim)
            # the later stage of a paired quantity prints in the earlier stage's column
            for a, b in pairs:
                first, second = (a, b) if grp[0].get(a) not in (None, "") else (b, a)
                if cont.get(first) not in (None, ""):
                    rec[second] = cont.get(first)
            for f, v in cont.items():
                if v not in (None, "") and rec.get(f) in (None, "") and f not in lf.values():
                    rec[f] = v
        out.append(rec)
    return out, len(rows) - len(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    src, dst = Path(args.run), Path(args.out)
    dst.mkdir(parents=True, exist_ok=True)
    recs = {r["id"].split("/")[-1]: r for r in ebscore.load_records(os.environ.get("EB_SPLIT", "long"))}
    for name, rec in sorted(recs.items()):
        f = src / f"{name}.json"
        if not f.exists():
            continue
        pred = json.loads(f.read_text())
        for aname, item, _d in find_all_arrays(rec["data_schema"]):
            if not line_fields(item):
                continue
            rows = pred.get(aname)
            if not isinstance(rows, list) or not rows:
                continue
            key = list((item.get("properties") or {}).keys())[0]
            new, saved = fold(rows, item, key)
            if saved:
                print(f"  {name[:36]:36s} {aname}: {len(rows)} -> {len(new)} rows "
                      f"(record spans {max(line_fields(item))} stacked lines)")
            pred[aname] = new
        (dst / f"{name}.json").write_text(json.dumps(pred))


if __name__ == "__main__":
    main()
