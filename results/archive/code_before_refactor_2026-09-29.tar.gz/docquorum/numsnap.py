"""
Numbers as printed (`numsnap`): a numeric field must carry a figure the document prints.

Readers restate figures. A deck prints net income as 26,107 (thousands) and the model, asked
for millions, writes 26.11; it prints "$7.7B" in a headline and 7,681 in the table, and the
model copies the headline. Both values are roundings of a printed figure. The check is
against the document's own text, never the model: a numeric value that is not printed at
any unit scale, or is printed only as a coarser restatement, is replaced by the one printed
figure it rounds -- only when exactly one such figure exists.

Applied only to fields whose schema type is number or integer, and only where the PDF has
a text layer.
"""
import json
import math
import re
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import settings as _S

SCALES = (1.0, 1e3, 1e6, 1e9, 1e-3, 1e-6, 1e-9)
_NUM = re.compile(r"(?<![\w.,])\(?-?\$?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?\)?(?![\w])")


def printed_numbers(text):
    """(value, significant digits) for every number in the text."""
    out = {}
    for m in _NUM.finditer(text):
        tok = m.group(0)
        neg = tok.startswith("(") and tok.endswith(")") or "-" in tok
        digits = re.sub(r"[^\d.]", "", tok)
        if not digits or digits.count(".") > 1:
            continue
        try:
            x = float(digits)
        except ValueError:
            continue
        sig = len(digits.replace(".", "").lstrip("0").rstrip("0")) if "." not in digits \
            else len(digits.replace(".", "").lstrip("0"))
        for v in ((-x, x) if neg else (x,)):
            out[v] = max(out.get(v, 0), sig)
    return out


def _sig(v):
    """Significant digits of a JSON number as written (7700 -> 2, 26.11 -> 4)."""
    s = repr(float(v)) if isinstance(v, float) else str(int(v))
    if "e" in s or "E" in s:
        return 15
    if "." in s:
        a, b = s.split(".")
        b = b.rstrip("0")
        return len((a.lstrip("-").lstrip("0") + b)) or 1
    return len(s.lstrip("-").rstrip("0")) or 1


def _decimals(v):
    if isinstance(v, int) or float(v).is_integer():
        s = str(int(v))
        return -(len(s) - len(s.rstrip("0"))) if s.strip("-0") else 0
    return len(repr(float(v)).split(".")[1].rstrip("0"))


def _close(a, b):
    return abs(a - b) <= 1e-9 * max(1.0, abs(a), abs(b))


class Printed:
    """Printed figures at every unit scale, sorted for interval lookups."""

    def __init__(self, nums):
        self.rows = sorted((x * s, s, sg, x) for x, sg in nums.items() for s in SCALES)
        self.keys = [r[0] for r in self.rows]

    def between(self, lo, hi):
        import bisect
        return self.rows[bisect.bisect_left(self.keys, lo):bisect.bisect_right(self.keys, hi)]


def snap_value(v, printed):
    """The printed figure v restates, or None. Only values that look rounded qualify:
    decimals (26.11 for 26,107 thousand), or at least two trailing zeros (7,700 for 7,681)."""
    fv = float(v)
    if fv == 0:
        return None
    d = _decimals(v)
    if not (d >= 1 or d <= -2):
        return None
    eps = 1e-9 * max(1.0, abs(fv))
    printed_at = [(x, s, sg) for _y, s, sg, x in printed.between(fv - eps, fv + eps)]
    half = 0.5 * 10 ** (-d)
    cands = {}
    for y, s, sg, x in printed.between(fv - half - eps, fv + half + eps):
        if _close(y, fv) or abs(y) < 1e-12:
            continue
        if _close(round(y, d), fv) and sg > _sig(v):
            cands[round(y, 9)] = max(cands.get(round(y, 9), 0), sg)
    if len(cands) != 1:
        return None
    (y, sg), = cands.items()
    if printed_at:
        # printed, but only as a coarser restatement at another unit ("$7.7B" for 7,681m)
        if any(s == 1.0 for _x, s, _sg in printed_at) or max(p[2] for p in printed_at) >= sg:
            return None
    return int(y) if isinstance(v, int) and float(y).is_integer() else y


def _numeric(sch, defs):
    while isinstance(sch, dict) and "$ref" in sch:
        sch = defs.get(sch["$ref"].split("/")[-1], {})
    if not isinstance(sch, dict):
        return False
    t = sch.get("type")
    ts = set(t) if isinstance(t, list) else {t}
    for a in sch.get("anyOf") or []:
        if isinstance(a, dict):
            at = a.get("type")
            ts |= set(at) if isinstance(at, list) else {at}
    ts.discard(None)
    ts.discard("null")
    return "number" in ts and ts <= {"number", "integer"}     # integer-only fields never snap


def walk(sch, val, defs, nums, log, path=""):
    while isinstance(sch, dict) and "$ref" in sch:
        sch = defs.get(sch["$ref"].split("/")[-1], {})
    if not isinstance(sch, dict):
        return val
    alts = [a for a in (sch.get("anyOf") or []) if isinstance(a, dict)]
    for a in alts:
        while "$ref" in a:
            a = defs.get(a["$ref"].split("/")[-1], {})
        if isinstance(val, dict) and "properties" in a:
            sch = a
        if isinstance(val, list) and "items" in a:
            sch = a
    if isinstance(val, dict) and "properties" in sch:
        for k, sub in sch["properties"].items():
            if k in val:
                val[k] = walk(sub, val[k], defs, nums, log, f"{path}.{k}")
        return val
    if isinstance(val, list) and "items" in sch:
        return [walk(sch["items"], x, defs, nums, log, f"{path}[]") for x in val]
    if isinstance(val, (int, float)) and not isinstance(val, bool) and _numeric(sch, defs):
        y = snap_value(val, nums)
        if y is not None:
            log.append((path, val, y))
            return y
    return val


def fix(schema, pred, text):
    nums = printed_numbers(text)
    if not nums:
        return pred, []
    nums = Printed(nums)
    log = []
    out = walk(schema, json.loads(json.dumps(pred)), schema.get("$defs") or {}, nums, log)
    return out, log


def main():
    """python numsnap.py <run_dir> <out_dir>      (EB_SPLIT selects the records)"""
    import os
    src, dst = Path(sys.argv[1]), Path(sys.argv[2])
    split = sys.argv[3] if len(sys.argv) > 3 else os.environ.get("EB_SPLIT", "long")
    dst.mkdir(parents=True, exist_ok=True)
    n = 0
    for line in open(_S.DATA / f"{split}.jsonl"):
        if not line.strip():
            continue
        rec = json.loads(line)
        name = rec["id"].split("/")[-1]
        f = src / f"{name}.json"
        if not f.exists():
            continue
        schema = rec["data_schema"] if isinstance(rec["data_schema"], dict) else json.loads(rec["data_schema"])
        pred = json.loads(f.read_text())
        pdf = _S.DATA / "docs" / rec["pdf"].replace("docs/", "", 1)
        text = subprocess.run([_S.PDFTOTEXT, str(pdf), "-"], capture_output=True, text=True).stdout
        out, log = fix(schema, pred, text)
        (dst / f.name).write_text(json.dumps(out))
        if log:
            n += 1
            print(f"  {name[:40]:40s} " + "; ".join(f"{p}: {a} -> {b}" for p, a, b in log[:6])
                  + (f" (+{len(log) - 6})" if len(log) > 6 else ""), flush=True)
    print(f"numsnap: {n} documents changed")


if __name__ == "__main__":
    main()
