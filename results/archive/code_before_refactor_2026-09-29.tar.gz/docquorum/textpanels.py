"""
Un-interleave side-by-side panels in `pdftotext -layout` text.

The text layer of a two-panel page puts both panels on every line:
    Security            Par (000)    Value    Security            Par (000) ...
    Bank of Nova Scotia (The)                 4.50%, 09/11/31, (1-day SOFR + 1.17%)(b)
so each line joins two unrelated records. Given such a page, Qwen3-VL-32B returned no
records at all (ishares pdf page 24); given the same content split into panels it read 77.

The evidence is the header line itself: a line whose cells (runs separated by 2+ spaces)
are one sequence repeated k times marks k panels, and the character offset where each
repetition starts is where every line of that page is cut. Panels are then emitted in
reading order. Pages without such a header are returned unchanged.
"""
import re

CELLS = re.compile(r"\S+(?: \S+)*")


def _key(s):
    return re.sub(r"[^a-z0-9]", "", s.lower())


def panel_offsets(line):
    cells = [(m.start(), m.group(0)) for m in CELLS.finditer(line)]
    keys = [_key(c) for _, c in cells]
    m = len(keys)
    # n >= 3: a repeated TWO-cell sequence is common inside a single table -- before/after
    # columns ('QUANTITY AMOUNT QUANTITY AMOUNT' on a contract modification, 'Destination
    # Government Destination Government' on an inspect/accept table) -- and splitting those
    # would break their rows. Three or more identical cells repeated is a duplicated panel.
    for n in range(3, m // 2 + 1):
        if m % n == 0 and all(keys[:n]) and \
                all(keys[i * n:(i + 1) * n] == keys[:n] for i in range(m // n)):
            return [cells[i * n][0] for i in range(1, m // n)]
    return None


def fix_page(text, scan_lines=40):
    lines = text.splitlines()
    for ln in lines[:scan_lines]:
        offs = panel_offsets(ln)
        if offs:
            cuts = [0] + offs + [None]
            panels = []
            for i in range(len(cuts) - 1):
                a, b = cuts[i], cuts[i + 1]
                panels.append("\n".join((l[a:b] if b else l[a:]).rstrip() for l in lines))
            return "\n\n".join(panels), len(offs) + 1
    return text, 1
