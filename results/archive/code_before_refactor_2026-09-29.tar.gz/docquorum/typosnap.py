"""
Emit the page's own typography.

Measured defect: GSA labour schedules print "Bachelor’s degree" (U+2019); the reader writes
"Bachelor's" (U+0027), and the scorer compares characters, so 90 of 106 education values
on one schedule were wrong while being right. Readers (and OCR) normalise quotes,
apostrophes and dashes; the page does not.

Only the typographic characters are transplanted, never the page's spacing: text layers
split words by kerning ("f rom", "f our"), so copying a whole printed span would "repair"
a correct value into a broken spelling. A value that contains a quote, apostrophe or dash
is located in the page's whitespace-free text with those characters folded; where it
occurs (with one rendering), each of its quote/dash characters takes the page's character
at that position. Its words, digits, extent and spacing are unchanged by construction.
Uses the PDF text layer; scans have none and pass through.

    python typosnap.py <run_dir> <out_dir>      (EB_SPLIT selects the records)
"""
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import pipeline as P

_TYPO = str.maketrans({"’": "'", "‘": "'", "‛": "'", "′": "'",
                       "“": '"', "”": '"', "‟": '"', "″": '"',
                       "–": "-", "—": "-", "‒": "-", "−": "-"})
# Quotes and apostrophes only. Dashes were measured and rejected: gold keeps a plain hyphen
# where several pages print an en dash or minus (caterpillar -2.93, ti_spec -2.25,
# budget_appendix_doe -2.74), so transplanting dashes cost short 0.03 net.
_PLAIN = set("'\"")


def squeeze(s):
    return "".join(s.split())


class Page:
    def __init__(self, pages):
        self.raw = squeeze("\u0000".join(pages))        # page breaks never match
        self.fold = self.raw.translate(_TYPO)

    def render(self, value):
        """The value with the page's typography, or None if not printed (or ambiguous)."""
        key = squeeze(value).translate(_TYPO)
        if len(key) < 3:
            return None
        pos, found = self.fold.find(key), set()
        while pos != -1 and len(found) < 2:
            found.add(self.raw[pos:pos + len(key)])
            pos = self.fold.find(key, pos + 1)
        if len(found) != 1:
            return None
        printed = iter(next(iter(found)))
        out = []
        for ch in value:
            if ch.isspace():
                out.append(ch)
            else:
                p = next(printed)
                out.append(p if ch in _PLAIN or ch.translate(_TYPO) != ch else ch)
        return "".join(out)


def snap(o, page, stat):
    if isinstance(o, dict):
        return {k: snap(v, page, stat) for k, v in o.items()}
    if isinstance(o, list):
        return [snap(v, page, stat) for v in o]
    if isinstance(o, str) and any(ch in _PLAIN for ch in o):
        new = page.render(o)
        if new is not None and new != o:
            stat["snapped"] += 1
            return new
    return o


def main():
    src, dst = Path(sys.argv[1]), Path(sys.argv[2])
    dst.mkdir(parents=True, exist_ok=True)
    split = os.environ.get("EB_SPLIT", "long")
    for line in open(P.DATA / f"{split}.jsonl"):
        if not line.strip():
            continue
        rec = json.loads(line)
        name = rec["id"].split("/")[-1]
        f = src / f"{name}.json"
        if not f.exists():
            continue
        pred = json.loads(f.read_text())
        pages = P.page_texts(P.DATA / "docs" / rec["pdf"].replace("docs/", "", 1))
        if sum(len(t.strip()) for t in pages) >= 50 * max(1, len(pages)):
            page = Page(pages)
            if page.raw != page.fold:                   # the page has typography to copy
                stat = {"snapped": 0}
                pred = snap(pred, page, stat)
                if stat["snapped"]:
                    print(f"  {name[:40]:40s} snapped {stat['snapped']}", flush=True)
        (dst / f"{name}.json").write_text(json.dumps(pred))


if __name__ == "__main__":
    main()
