"""
DocQuorum: agentic document extraction by a quorum of grounded readings.

The modules of this package import one another by plain module name (they were developed
as a flat set of scripts), so the package directory is placed on sys.path on import.
"""
import sys as _sys
from pathlib import Path as _Path

_HERE = str(_Path(__file__).resolve().parent)
if _HERE not in _sys.path:
    _sys.path.insert(0, _HERE)

__version__ = "1.0.0"
