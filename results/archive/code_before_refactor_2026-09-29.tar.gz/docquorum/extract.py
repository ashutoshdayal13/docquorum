"""
DocQuorum -- extract structured data from one document.

    python -m docquorum.extract DOC --schema SCHEMA.json [--task "..."] [-o OUT.json]

DOC is a PDF or an image (png/jpg/...). SCHEMA is a JSON Schema, or a JSON template whose
values are empty strings / lists / objects (the result then follows the template, with ""
for anything absent). The same chain that produced the benchmark results runs on the one
document:

  1. front end   PDF text layer; for scans and images the MinerU parse (if the parser runs)
  2. readings    primary  -- the agentic extractor on the text layer (page images for scans):
                             one whole-document call when it fits the budget, the schema split
                             into parts when the schema is what does not fit, page chunks
                             (verified by finish_reason, split and re-asked) otherwise
                 parse    -- the same extractor on the MinerU parse
                 oneshot  -- the whole document in a single call, when it fits one call
  3. per reading schema-driven repairs of the agentic readings (carry-down, page fields, keyed
                 dedupe, stacked rows; the parse reading is first snapped onto the text
                 layer), then output stages grounded in the page for every reading
                 (conform, template rows, cross-array copies, record counts, printed page
                 numbers, typography)
  4. consensus   keep the reading that agrees most with the others (recall-weighted, beta=2)
"""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

PKG = Path(__file__).resolve().parent
sys.path.insert(0, str(PKG))
import settings as S

SNAP = [("reconcile.py", "{i} {o}")]
REPAIRS = [("headfill.py", "--run {i} --out {o}"), ("pagefix.py", "--run {i} --out {o} --no-locate"),
           ("dedupe.py", "--run {i} --out {o}"), ("stackfold.py", "--run {i} --out {o}")]
STAGES = [(m, "{i} {o}") for m in ("conform.py", "boolblank.py", "emptyrows.py", "xarray.py", "dupcap.py",
                                    "pagegrid.py", "typosnap.py", "numsnap.py")]
# Per reading, exactly as the benchmark results were produced: the primary reading gets the
# schema-driven repairs (it is the chunked extractor's output); the parse reading is first
# snapped onto the text layer; the one-shot reading has no chunking artifacts to repair.
CHAIN = {"primary": REPAIRS + STAGES, "parse": SNAP + REPAIRS + STAGES, "oneshot": STAGES}


# ---------- schema / template ----------
def is_template(obj):
    """A JSON template (UNIKIE style): no JSON-Schema keywords, only empty leaves."""
    if isinstance(obj, dict):
        if {"type", "properties", "$schema"} & set(obj):
            return False
        return all(is_template(v) for v in obj.values())
    if isinstance(obj, list):
        return all(is_template(v) for v in obj)
    return obj in ("", None)


def to_schema(t):
    if isinstance(t, dict):
        return {"type": "object", "additionalProperties": False,
                "properties": {k: to_schema(v) for k, v in t.items()}}
    if isinstance(t, list):
        return {"type": "array", "items": to_schema(t[0] if t else "")}
    return {"type": ["string", "null"]}


def to_template(pred, t):
    if isinstance(t, dict):
        pred = pred if isinstance(pred, dict) else {}
        return {k: to_template(pred.get(k), v) for k, v in t.items()}
    if isinstance(t, list):
        return [to_template(x, t[0] if t else "") for x in pred] if isinstance(pred, list) else []
    return "" if pred is None or isinstance(pred, (dict, list)) else str(pred)


# ---------- front end ----------
def as_pdf(doc, dst):
    doc = Path(doc)
    if doc.suffix.lower() == ".pdf":
        shutil.copy(doc, dst)
        return
    from PIL import Image
    Image.open(doc).convert("RGB").save(dst, "PDF", resolution=150)


def parser_up():
    import urllib.request
    try:
        with urllib.request.urlopen(S.PARSER_URL.rstrip("/") + "/models", timeout=3):
            return True
    except Exception:
        return False


def run(cmd, env):
    r = subprocess.run([sys.executable] + cmd, env=env, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"{cmd[0]} failed:\n{r.stderr[-2000:]}")
    return r.stdout


# ---------- the pipeline ----------
def extract(doc, schema, task=None, readings=("primary", "parse", "oneshot"), workers=8,
            workdir=None, log=print):
    """Returns (result, report). `schema` is a JSON Schema or a JSON template (dict)."""
    template = schema if is_template(schema) else None
    schema = to_schema(template) if template is not None else dict(schema)
    if task:
        schema["description"] = task
    raw = Path(doc).read_bytes()
    name = "doc_" + hashlib.sha1(raw).hexdigest()[:12]
    W = Path(workdir or tempfile.mkdtemp(prefix="docquorum_"))
    (W / "data" / "docs" / "doc").mkdir(parents=True, exist_ok=True)
    pdf = W / "data" / "docs" / "doc" / f"{name}.pdf"
    as_pdf(doc, pdf)
    rec = {"id": f"doc/{name}", "pdf": f"docs/doc/{name}.pdf", "category": "doc", "tags": [],
           "data_schema": schema, "expected_output": {}, "field_rules": {}, "repeated_structure": {}}
    (W / "data" / "doc.jsonl").write_text(json.dumps(rec) + "\n")
    env = {**os.environ, "DQ_EXTRACTBENCH_DATA": str(W / "data"), "DQ_RUNS": str(W / "runs"),
           "EB_SPLIT": "doc", "EB_GUIDED": "1", "EB_NOTHINK": "1", "EB_WHOLE": "1",
           "CONSENSUS_BETA": "2", "PYTHONPATH": str(PKG)}

    # 1. front end: MinerU parse of every page (cached by content hash) when the parser runs
    sys.path.insert(0, str(PKG))
    import imgview
    n_pages = imgview.npages(pdf)
    # The input decides the readings: a PDF that carries a text layer (born-digital, or a scan
    # with an OCR layer) is read once, by the agentic reader grounded in its characters --
    # there the other readings only add noise (RESULTS section 14) -- and so is a scan too long
    # for one call. An image or a short scan without text is read several ways, and the quorum
    # keeps the reading the others agree with most.
    import pipeline as P
    text_layer = sum(len(t.strip()) for t in P.page_texts(pdf)) >= 50 * max(1, n_pages)
    if (text_layer or n_pages > 12) and "primary" in readings:
        readings = ("primary",)
    have_parse = False
    if parser_up() and "parse" in readings:
        import docparse
        docparse.parse_pages(pdf, list(range(1, n_pages + 1)), cache_key=name)
        have_parse = True
    log(f"[docquorum] {Path(doc).name}: {n_pages} page(s); "
        f"{'text layer' if text_layer else 'no text layer'}; parse {'yes' if have_parse else 'not used'}")

    # 2. readings
    done = []
    for r in readings:
        try:
            if r == "primary":
                run([str(PKG / "agentic.py"), "--tag", r, "--only", name, "--workers", str(workers)], env)
            elif r == "parse" and have_parse:
                run([str(PKG / "agentic.py"), "--tag", r, "--parsed", "--only", name,
                     "--workers", str(workers)], env)
            elif r == "oneshot" and n_pages <= 12:
                run([str(PKG / "oneshot.py"), name, str(W / "runs" / r)], env)
            else:
                continue
            if (W / "runs" / r / f"{name}.json").exists():
                done.append(r)
        except RuntimeError as e:
            log(f"[docquorum] reading '{r}' failed: {str(e)[:200]}")
    if not done:
        raise RuntimeError("no reading succeeded")
    log(f"[docquorum] readings: {', '.join(done)}")

    # 3. repairs + output stages on every reading
    for r in done:
        cur = W / "runs" / r
        for i, (mod, args) in enumerate(CHAIN[r]):
            nxt = W / "runs" / f"{r}.s{i}"
            run([str(PKG / mod)] + args.format(i=cur, o=nxt).split(), env)
            cur = nxt
        shutil.copytree(cur, W / "runs" / f"{r}.final", dirs_exist_ok=True)

    # 4. consensus
    finals = [str(W / "runs" / f"{r}.final") for r in done]
    report = {"readings": done, "picked": done[0], "agreement": {}}
    if len(finals) > 1:
        run([str(PKG / "medoidroute.py"), ",".join(finals), ",".join(finals), str(W / "runs" / "final")], env)
        med = json.loads((W / "runs" / "final" / "_medoid.json").read_text())[name]
        report["picked"] = Path(med["pick"]).name.replace(".final", "")
        report["agreement"] = {Path(k).name.replace(".final", ""): round(v, 4) for k, v in med["agreement"].items()}
        result = json.loads((W / "runs" / "final" / f"{name}.json").read_text())
    else:
        result = json.loads(Path(finals[0], f"{name}.json").read_text())
    if template is not None:
        result = to_template(result, template)
    if workdir is None:
        shutil.rmtree(W, ignore_errors=True)
    return result, report


def main():
    ap = argparse.ArgumentParser(description="DocQuorum: schema-guided document extraction")
    ap.add_argument("doc", help="PDF or image")
    ap.add_argument("--schema", required=True, help="JSON Schema or JSON template file")
    ap.add_argument("--task", default=None, help="optional task description (what to extract, and how)")
    ap.add_argument("-o", "--out", default=None, help="write the result here (default: stdout)")
    ap.add_argument("--readings", default="primary,parse,oneshot")
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--workdir", default=None, help="keep intermediate readings in this folder")
    a = ap.parse_args()
    result, report = extract(a.doc, json.loads(Path(a.schema).read_text()), a.task,
                             tuple(a.readings.split(",")), a.workers, a.workdir,
                             log=lambda m: print(m, file=sys.stderr))
    print(f"[docquorum] picked '{report['picked']}' {report['agreement']}", file=sys.stderr)
    out = json.dumps(result, indent=2, ensure_ascii=False)
    if a.out:
        Path(a.out).write_text(out)
    else:
        print(out)


if __name__ == "__main__":
    main()
