"""
One-shot reading: the whole document and the schema in a single call.

This is one of the consensus's readings for documents that fit one call. It uses
ExtractBench's own one-shot reader (extract_bench ... VLLMExtractProvider, Apache-2.0) with
that benchmark's registered configuration -- 150 DPI page images, its system prompt,
json_object mode -- so the reading is the benchmark's reference one-shot on our served model.
Only the served model name, the endpoint and (for 32k-context models) the output budget
are changed.

    EB_SPLIT=<split> python oneshot.py <comma-separated names> <out_dir>     (benchmark use)
"""
import json
import os
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import settings as S

os.environ.setdefault("DQ_ONESHOT_URL", S.LLM_URL[:-3] if S.LLM_URL.endswith("/v1") else S.LLM_URL)
os.environ["PATH"] = str(Path(S.PDFTOPPM).parent) + os.pathsep + os.environ.get("PATH", "")  # pdftoppm


def _provider():
    from extract_bench.inference.providers.extract.vllm_extract import VLLMExtractProvider
    return VLLMExtractProvider("vllm_extract", {
        "model": S.MODEL,
        "endpoint_env_var": "DQ_ONESHOT_URL",      # the provider appends /v1
        "additional_properties_false": True,
        "max_tokens": int(os.environ.get("DQ_ONESHOT_MAX_TOKENS", "32768")),
        "dpi": int(os.environ.get("DQ_ONESHOT_DPI", "150")),   # the provider's default is 150
        "timeout_s": 3600,
        "structured_output": False,
    })


def read(pdf, schema, provider=None):
    """One-shot reading of one PDF against a JSON schema; returns the extracted object."""
    prov = provider or _provider()
    raw = prov._call_api_fitting_context(prov._prepare_schema(schema),
                                         prov._render_page_images(Path(pdf)))
    return raw.get("data")


def main():
    import ebscore
    split = os.environ.get("EB_SPLIT", "short")
    names = set(sys.argv[1].split(","))
    out = Path(sys.argv[2])
    out.mkdir(parents=True, exist_ok=True)
    prov = _provider()
    recs = [r for r in ebscore.load_records(split) if r["id"].split("/")[-1] in names]

    def one(rec):
        nm = rec["id"].split("/")[-1]
        pdf = S.DATA / "docs" / rec["pdf"].replace("docs/", "", 1)
        try:
            (out / f"{nm}.json").write_text(json.dumps(read(pdf, rec["data_schema"], prov)))
            print(f"  {nm[:40]:40s} ok", flush=True)
        except Exception as e:                      # the document does not fit: no reading
            print(f"  {nm[:40]:40s} FAILED {type(e).__name__}: {str(e)[:120]}", flush=True)

    with ThreadPoolExecutor(max_workers=int(os.environ.get("DQ_WORKERS", "6"))) as ex:
        list(ex.map(one, recs))


if __name__ == "__main__":
    main()
