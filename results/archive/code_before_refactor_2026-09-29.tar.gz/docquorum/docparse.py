"""
Document-parsing front end: page image -> structured blocks with real tables.

Why this exists. Scoring the pipeline by document type showed one clean pattern: we reach
94-97 F1 wherever `pdftotext -layout` renders the page faithfully (single-column tables:
imedia 97.12, ftx 94.17, eco 96.78) and collapse wherever it does not --
  13F, 11 columns with 2 blank      -> 63-73, values shift one column left
  government forms, block structure -> 37-80
  image-only PDFs, no text at all   -> 47-59
  oklahoma, 6-column newspaper      -> 8.52
Every remaining failure is a layout failure, and we were optimising the extraction loop on
top of a lossy linearisation. The systems above 90 on this benchmark are parsing stacks
(layout detection, table structure, reading order) with extraction as the last step; we had
that last step and no front end.

MinerU2.5-2509-1.2B is used as the parser: 90.67 on OmniDocBench (above Gemini-2.5 Pro's
88.03) at 1.2B, and it exposes `Qwen2VLForConditionalGeneration`, so plain vLLM serves it --
which avoids this box's broken Paddle CUDA build. It runs a layout pass on a downsampled
page, then recognises content on native-resolution crops, emitting tables as HTML.
"""
import base64
import io
import json
import subprocess
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
import settings as _S
PARSER_URL = _S.PARSER_URL
PDFTOPPM = _S.PDFTOPPM
CACHE = _S.PARSE_CACHE


def render_page(pdf, page, dpi=200, max_pixels=9_000_000, dense=False):
    """
    Render one page for the parser.

    Resolution matters more than it looks. The first version rendered at 144 DPI and then
    downsampled to 2.2M pixels; on oklahoma, which prints 462 records per page in six
    columns of small type, that destroyed the glyphs -- the parse came back with 'POBOX757'
    for 'PO BOX 757', 'WAI KER DEBBIE' for 'WALKER DEBBIE', and outright garbage like
    'SITETATIDENDENES'. A letter page at 300 DPI is ~8.4M pixels, so the old cap was
    discarding three quarters of the detail before the parser ever saw it.
    """
    if dense:
        dpi, max_pixels = 300, 16_000_000
    from PIL import Image
    with tempfile.TemporaryDirectory() as td:
        subprocess.run([PDFTOPPM, "-jpeg", "-r", str(dpi), "-f", str(page), "-l", str(page),
                        str(pdf), str(Path(td) / "p")], capture_output=True, timeout=600)
        got = sorted(Path(td).glob("p*.jpg"))
        if not got:
            return None
        im = Image.open(got[0]).convert("RGB")
    w, h = im.size
    if w * h > max_pixels:
        sc = (max_pixels / (w * h)) ** 0.5
        im = im.resize((max(1, int(w * sc)), max(1, int(h * sc))))
    return im


def make_client():
    from mineru_vl_utils import MinerUClient
    return MinerUClient(backend="http-client", model_name="mineru", server_url=PARSER_URL)


def blocks_to_text(blocks):
    """
    Flatten MinerU blocks into text that keeps table structure.

    Tables arrive as HTML, which is what makes this better than whitespace columns: a cell
    is addressed by its row and column instead of by character offset, so a blank column
    can no longer shift every value after it.
    """
    out = []
    for b in blocks or []:
        if not isinstance(b, dict):
            continue
        t = (b.get("type") or "").lower()
        c = b.get("content") or ""
        if not str(c).strip():
            continue
        if t == "table":
            out.append("<TABLE>\n" + str(c).strip() + "\n</TABLE>")
        elif t in ("title", "header", "section"):
            out.append(f"## {str(c).strip()}")
        else:
            out.append(str(c).strip())
    return "\n".join(out)


def parse_pages(pdf, pages, cache_key=None, client=None, dense=None):
    """
    Parse the given 1-based page numbers; returns {page_no: structured_text}.

    `dense` raises the render resolution for pages that pack a lot of small text; when not
    given it is inferred from how many characters pdftotext finds per page.
    """
    client = client or make_client()
    if dense is None:
        try:
            import pipeline as _P
            pg = _P.page_texts(pdf)
            cpp = sum(len(x) for x in pg) / max(1, len(pg))
            # Dense text pages need the resolution, and so do image-only PDFs: those report
            # ~0 characters, so a plain "chars > 6000" test marked them NOT dense and sent
            # the very documents that depend on the parser through at low resolution.
            dense = cpp > 6000 or cpp < 100
        except Exception:
            dense = False
    res = {}
    cdir = (CACHE / cache_key) if cache_key else None
    if cdir:
        cdir.mkdir(parents=True, exist_ok=True)
    for pno in pages:
        cf = (cdir / f"{pno:04d}.txt") if cdir else None
        if cf is not None and cf.exists():
            res[pno] = cf.read_text()
            continue
        im = render_page(pdf, pno, dense=dense)
        if im is None:
            res[pno] = ""
            continue
        try:
            blocks = client.two_step_extract(im)
            txt = blocks_to_text(blocks)
        except Exception as e:
            txt = ""
            print(f"    ! parse {Path(pdf).stem} p{pno}: {type(e).__name__}: {str(e)[:80]}",
                  flush=True)
        res[pno] = txt
        if cf is not None:
            cf.write_text(txt)
    return res
