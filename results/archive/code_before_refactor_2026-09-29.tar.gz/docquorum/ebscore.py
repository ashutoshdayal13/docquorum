"""
Score predictions with ExtractBench's own scorer (extract_bench.extract_unified_value_f1).

Builds an ExtractTestCase from a long.jsonl record and calls the harness. Nothing is
reimplemented. Run with ./ebenv/bin/python (the harness needs Python >= 3.12).
"""
import json
from pathlib import Path

from extract_bench.evaluation.score_case import score_extract_prediction
from extract_bench.test_cases.schema import ExtractTestCase

DATA = __import__("settings").DATA


_JSON_FIELDS = ("data_schema", "expected_output", "field_rules", "repeated_structure")


def load_records(split="long"):
    """long.jsonl stores data_schema / expected_output / field_rules /
    repeated_structure as JSON *strings*, so they are parsed here."""
    out = []
    for line in (DATA / f"{split}.jsonl").open():
        if not line.strip():
            continue
        r = json.loads(line)
        for k in _JSON_FIELDS:
            if isinstance(r.get(k), str):
                r[k] = json.loads(r[k])
        out.append(r)
    return out


def make_case(rec):
    return ExtractTestCase(
        test_id=rec["id"],
        group=rec.get("category") or "long",
        file_path=str(DATA / "docs" / (rec["pdf"] if not rec["pdf"].startswith("docs/")
                                       else rec["pdf"][5:])),
        tags=rec.get("tags") or [],
        data_schema=rec["data_schema"],
        expected_output=rec["expected_output"],
        # field_rules is a dict keyed by field_path; the harness wants a list of rules
        test_rules=[{**v, "field_path": k, "type": "extract_field"}
                    for k, v in (rec.get("field_rules") or {}).items()
                    if isinstance(v, dict)],
        row_identity=rec.get("repeated_structure") or {},
    )


def score(rec, prediction):
    return score_extract_prediction(make_case(rec), prediction)


if __name__ == "__main__":
    recs = load_records("long")
    print(f"{len(recs)} long cases")
    # sanity: gold in must score 1.0
    for rec in recs[:4]:
        r = score(rec, rec["expected_output"])
        f1 = r.get("extract_unified_value_f1")
        print(f"  GOLD-IN {rec['id'][:44]:44s} value_f1={f1}")
    # and an empty prediction must score ~0
    for rec in recs[:2]:
        r = score(rec, {})
        print(f"  EMPTY   {rec['id'][:44]:44s} value_f1={r.get('extract_unified_value_f1')}")
