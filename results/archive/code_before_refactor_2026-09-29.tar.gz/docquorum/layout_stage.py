"""
Per-document reader selection from measured layout evidence (no gold, no per-document rule).

For every document in a split, measure, then decide:
  * column flow   -- >= 3 equal-width text columns on most sampled pages (colflow.py)
                     -> read column by column;
  * ruled scan    -- no text layer, parsed table headers map onto the schema's fields,
                     and deterministic conversion keeps >= 90% of the table body rows
                     -> ruled-band reader (row count fixed by the printed rules);
  * otherwise     -- the ordinary text / parse front ends and routing.
The decisions are written to runs/<split>_layout.json with the evidence behind each, and
the chosen readers are run. Everything is keyed by split, so nothing from the long split
(where these readers were developed) is reused.
"""
import json, os, subprocess, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import settings as _S
import colflow, imgview as V, tabconv as T

PY = sys.executable
split = os.environ.get("EB_SPLIT", "long")
decide_only = "--decide-only" in sys.argv
recs = {}
for line in open(_S.DATA / f"{split}.jsonl"):
    if line.strip():
        r = json.loads(line)
        for k in ("data_schema", "expected_output"):
            if isinstance(r.get(k), str):
                r[k] = json.loads(r[k])
        recs[r["id"].split("/")[-1]] = r
out = {}
for name, rec in sorted(recs.items()):
    pdf = _S.DATA / "docs" / split / f"{name}.pdf"
    n = V.npages(pdf)
    txt = subprocess.run([_S.PDFTOTEXT,
                          str(pdf), "-"], capture_output=True, text=True).stdout
    has_text = len(txt.strip()) >= 50 * max(1, n)
    ev = {"pages": n, "text_layer": has_text}
    if n >= 2 and colflow.is_column_flow(pdf, n):
        ev["reader"] = "colflow"
    elif not has_text and (_S.PARSE_CACHE / name).is_dir():
        res = T.convert_doc(name, rec, _S.PARSE_CACHE)
        if res and res[1]:
            aname, good, bad = res
            body = 0
            for f in sorted((_S.PARSE_CACHE / name).glob("*.txt")):
                if int(f.stem) not in set(bad):
                    body += sum(max(0, len(r) - 1) for r in T.table_rows(f.read_text(errors="ignore")))
            comp = sum(len(v) for v in good.values()) / max(1, body)
            ev["table_completeness"] = round(comp, 3)
            if comp >= 0.9:
                ev["reader"] = "ruled"
    ev.setdefault("reader", "route")
    out[name] = ev
Path(f"runs/{split}_layout.json").write_text(json.dumps(out, indent=1))
from collections import Counter
print(split, dict(Counter(e["reader"] for e in out.values())), flush=True)
if decide_only:
    sys.exit()
procs = []
for name, ev in out.items():
    if ev["reader"] == "colflow":
        procs.append(subprocess.Popen([PY, "colflow.py", "--doc", name, "--out", f"runs/{split}_colflow",
                                       "--workers", "4"], stdout=open(f"logs/{split}_colflow_{name}.log", "w"),
                                      stderr=subprocess.STDOUT))
    elif ev["reader"] == "ruled":
        procs.append(subprocess.Popen([PY, "ruledview.py", "--doc", name, "--pages",
                                       ",".join(map(str, range(1, ev["pages"] + 1))),
                                       "--out", f"runs/{split}_ruled", "--workers", "4"],
                                      stdout=open(f"logs/{split}_ruled_{name}.log", "w"),
                                      stderr=subprocess.STDOUT))
for p in procs:
    p.wait()
over = {}
for name, ev in out.items():
    d = {"colflow": f"runs/{split}_colflow", "ruled": f"runs/{split}_ruled"}.get(ev["reader"])
    if d and (Path(d) / f"{name}.json").exists():
        over[name] = d
Path(f"runs/{split}_overrides.json").write_text(json.dumps(over, indent=1))
print("LAYOUT_STAGE_DONE", split, len(over), "overrides", flush=True)
