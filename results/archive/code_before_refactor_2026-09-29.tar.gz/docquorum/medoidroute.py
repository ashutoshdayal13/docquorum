"""
Route by consensus: per document, pick the candidate view that agrees most with the other
independent readings of the same document.

Agreement between two predictions is measured with the benchmark's own scorer (one
prediction treated as the reference), so it counts exactly what scoring counts. The
readings come from different models (Qwen3-VL-8B, -32B) and front ends (text layer,
parse), so their errors are partly independent and the reading closest to the rest is
the likeliest to be right. Unlike field-level arbitration, a whole view is chosen, so no
record is stitched together from different readings. No gold and no tuned parameter.
"""
import copy, json, os, sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import ebscore


BETA = float(os.environ.get("CONSENSUS_BETA", "1"))


NORMALIZE = os.environ.get("DQ_AGREE_NORMALIZE", "0") == "1"
_NORMALIZERS = ["case_insensitive", "punctuation_spacing", "optional_terminal_punctuation", "lenient_date"]


def _string_paths(o, path=""):
    """Concrete paths (a.b[0].c) of every string leaf -- taken from a READING, never from gold."""
    if isinstance(o, dict):
        for k, v in o.items():
            yield from _string_paths(v, f"{path}.{k}" if path else k)
    elif isinstance(o, list):
        for i, v in enumerate(o):
            yield from _string_paths(v, f"{path}[{i}]")
    elif isinstance(o, str):
        yield path


def agree(args):
    """(precision, recall) of reading b measured against reading a as the reference."""
    rec, a, b = args
    # Agreement uses the schema only. The benchmark record also carries its scoring metadata
    # (per-field comparators in field_rules, row identity keys in repeated_structure); a
    # deployed pipeline never has those, so they must not shape which reading is chosen.
    r = {k: v for k, v in rec.items() if k not in ("field_rules", "repeated_structure")}
    r = copy.deepcopy(r); r["expected_output"] = a; r["field_rules"] = {}; r["repeated_structure"] = {}
    if NORMALIZE:   # generic string normalisation for every string leaf of the reference reading
        r["field_rules"] = {p: {"normalizers": _NORMALIZERS} for p in _string_paths(a)}
    try:
        m = ebscore.score(r, b)["metrics"]
        return (m.get("extract_unified_value_precision", 0.0), m.get("extract_unified_value_recall", 0.0))
    except Exception:
        return (0.0, 0.0)


def fbeta(p, r, beta):
    """beta > 1 weights recall: omissions are correlated across readers (a hard page is hard
    for every model) while inventions are idiosyncratic, so symmetric agreement rewards
    readings that share an omission; recall-weighted agreement asks whether a reading
    contains what the others found, and still penalises unsupported extra content."""
    if p <= 0 or r <= 0:
        return 0.0
    b2 = beta * beta
    return (1 + b2) * p * r / (b2 * p + r)


def main():
    cands = sys.argv[1].split(","); refs = sys.argv[2].split(",")
    out = Path(sys.argv[3]); out.mkdir(parents=True, exist_ok=True)
    over = json.loads(Path(sys.argv[4]).read_text()) if len(sys.argv) > 4 else {}
    recs = {r["id"].split("/")[-1]: r for r in ebscore.load_records(os.environ.get("EB_SPLIT", "long"))}
    report = {}
    for name, rec in sorted(recs.items()):
        if name in over:
            (out / f"{name}.json").write_text((Path(over[name]) / f"{name}.json").read_text()); continue
        views = {v: json.loads((Path(v) / f"{name}.json").read_text())
                 for v in dict.fromkeys(cands + refs) if (Path(v) / f"{name}.json").exists()}
        cs = [c for c in cands if c in views]
        if not cs:                      # document not in this run (e.g. outside a subset)
            continue
        jobs = [(rec, views[o], views[c]) for c in cs for o in views if o != c]
        with ProcessPoolExecutor(max_workers=8) as ex:
            vals = list(ex.map(agree, jobs))
        sc, pairs, i = {}, {}, 0
        for c in cs:
            others = [o for o in views if o != c]; k = len(others)
            pr = vals[i:i + k]; i += k
            pairs[c] = {o: list(v) for o, v in zip(others, pr)}
            # rounded so that mathematically tied readings tie exactly and the tie goes to the
            # earlier reading on every Python version (3.12 changed float sum() rounding)
            sc[c] = round(sum(fbeta(p_, r_, BETA) for p_, r_ in pr) / max(1, k), 9)
        best = max(sc, key=sc.get)
        report[name] = {"pick": best, "agreement": sc, "pairs": pairs}
        (out / f"{name}.json").write_text(json.dumps(views[best]))
        print(f"  {name[:36]:36s} {Path(best).name:18s} " +
              "  ".join(f"{Path(c).name[-14:]}={s:.3f}" for c, s in sc.items()), flush=True)
    (out / "_medoid.json").write_text(json.dumps(report, indent=1))


if __name__ == "__main__":
    main()
