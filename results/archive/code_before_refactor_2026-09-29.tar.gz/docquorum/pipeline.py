"""
Page-chunked accumulating extraction for ExtractBench's long split.

Why this shape. Every long case here is the same: a few scalar header fields plus ONE
large repeated array -- 8,624 creditors, 3,063 holdings, 20 line items. The published
failure mode is recall: single-pass VLMs "stop early, truncating the remaining records"
and score under 35% on documents past 50 pages, while systems that iterate reach 79-94%.

So coverage is made structural rather than something to verify afterwards:
  * the document is split into page groups and every group is visited exactly once,
    so no region can be skipped and nothing depends on the model deciding it is done;
  * each call only has to emit the records visible in its own pages, so the output token
    limit -- the actual cause of truncation -- can never bound the record count;
  * records are concatenated in page order, so ordering is preserved for array alignment.

Text comes from `pdftotext -layout`, which preserves column alignment on these documents.
The repeated array is found from `data_schema` alone; `repeated_structure` / `row_identity`
is scoring metadata and is deliberately not used as input.
"""
import argparse
import base64
import io
import json
import re
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from openai import OpenAI

HERE = Path(__file__).resolve().parent
import settings as _S
DATA = _S.DATA
BASE_URL = _S.LLM_URL
PDFTOTEXT = _S.PDFTOTEXT
PDFTOPPM = _S.PDFTOPPM

ARRAY_PROMPT = """You are extracting rows of a table from one part of a long document.

Below is the text of pages {p0}-{p1}, with column alignment preserved.

{header}--- PAGE TEXT ---
{text}
--- END PAGE TEXT ---

You are collecting the list called "{array_name}".
{array_desc}Each entry of that list is one JSON object with this schema:
{item_schema}

{colmap}Return EVERY entry of "{array_name}" that appears in the text above, in the order
it appears. Only rows belonging to "{array_name}" count -- if the pages also contain other
kinds of rows, leave those out.
- Do not include column headers, page headers/footers, case captions or totals.
- Do not invent rows, and do not skip rows that look similar to their neighbours.
- If a field is blank for a row, use null.
- If there are no data rows in this text at all, return [].

Reply with a JSON array only:
[{{...}}, {{...}}]"""

COLMAP_PROMPT = """Below is text from a long document containing one repeated table.

--- SAMPLE PAGES ---
{text}
--- END SAMPLE ---

The rows of that table must be returned as JSON objects with these fields:
{item_schema}

Work out how the table's columns line up with those fields.

Two different things make a field unusable, and both matter:
  (a) there is no column for it at all, and
  (b) a column header exists but its CELLS ARE BLANK in every data row you can see.
Put the field in "absent_fields" in BOTH cases. Check the actual data rows, not just the
header line: a header can name a column that is never filled in.

Reply with a JSON object only:
{{"columns_left_to_right": ["<column header text, in order>"],
  "field_to_column": {{"<schema field>": "<column header text, or null if absent or always blank>"}},
  "absent_fields": ["<schema fields with no column, or whose cells are always blank>"]}}"""

SCALAR_PROMPT = """Extract the document-level fields below from this document's text.

--- DOCUMENT TEXT ---
{text}
--- END TEXT ---

Fields to extract (ignore any array/table fields, they are handled separately):
{scalar_schema}

Reply with a JSON object only, using null for anything not present."""


def page_texts(pdf):
    """One string per page, layout preserved."""
    out = subprocess.run([PDFTOTEXT, "-layout", str(pdf), "-"],
                         capture_output=True, text=True, timeout=600).stdout
    pages = out.split("\f")
    # pdftotext ends EVERY page with a form feed, so the split leaves one empty element
    # after the last page. Counting it made an n-page PDF look like n+1 pages, and the
    # parse-cache gate (>= 90% of pages parsed) then failed for every document of 8 pages or
    # fewer: on the short split the parse view was never used for 243 of 252 documents.
    if len(pages) > 1 and not pages[-1].strip():
        pages = pages[:-1]
    return pages


_NUMERIC_TOKEN = re.compile(r"^[\d,.$()\-]+$")


def _is_row_line(ln):
    """
    A data row, not a running page header.

    'contains a digit' was too loose: it matched the running header
    '5/17/26, 8:48 PM  SEC FORM 13-F Information Table' on every page, so the header block
    above the first real row came out empty. Require tokens that are purely numeric
    (digits with separators), which timestamps and titles do not produce.
    """
    parts = ln.split()
    n = 0
    for x in parts:
        if _NUMERIC_TOKEN.match(x) and (len(x) >= 3 or "," in x or "." in x):
            n += 1
    return len(parts) >= 4 and n >= 2


def row_density(t):
    return sum(1 for ln in t.splitlines() if _is_row_line(ln))


def find_header(pages, max_lines=14):
    """
    The table's header block, taken from the first page that actually has data rows.

    Needed because these documents print the header once. On the 13F filings the header
    names eleven columns including FIGI and PUT/CALL, both of which are blank in every
    data row; a chunk from page 40 sees only bare rows, so the model guessed the column
    order and slid every numeric field one position left. Carrying the header into each
    chunk restores the alignment, and pdftotext -layout keeps the header horizontally
    aligned with the data beneath it.
    """
    for pi, txt in enumerate(pages[:12]):
        lines = txt.splitlines()
        first_row = next((i for i, ln in enumerate(lines) if _is_row_line(ln)), None)
        if first_row is None or row_density(txt) < 3:
            continue
        head = [ln for ln in lines[:first_row] if ln.strip()][-max_lines:]
        if head:
            return "\n".join(head), pi + 1
    return "", 0


def page_images(pdf, first, last, max_pixels=4_000_000, dpi=200):
    """
    Render pages as JPEGs. Used only when the PDF carries no extractable text.

    pdftoppm writes to a filename prefix rather than a usable JPEG stream on stdout, so
    the pages go to a temporary directory and are read back.
    """
    import tempfile
    from PIL import Image
    imgs = []
    with tempfile.TemporaryDirectory() as td:
        # Was 110 DPI capped at 1.4 MP. That is too coarse for scanned forms and degraded
        # captures -- the same setting the corrupted long scans exposed (MinerU at 300 DPI
        # and the ruled reader at 200 DPI both read them far better). 134 of the 370
        # documents are scans and their text front end runs entirely through this path.
        subprocess.run([PDFTOPPM, "-jpeg", "-r", str(dpi), "-f", str(first), "-l", str(last),
                        str(pdf), str(Path(td) / "pg")],
                       capture_output=True, timeout=900)
        for p in sorted(Path(td).glob("pg*.jpg")):
            try:
                im = Image.open(p).convert("RGB")
            except Exception:
                continue
            w, h = im.size
            if w * h > max_pixels:
                sc = (max_pixels / (w * h)) ** 0.5
                im = im.resize((max(1, int(w * sc)), max(1, int(h * sc))))
            buf = io.BytesIO()
            im.save(buf, format="JPEG", quality=88)
            imgs.append(base64.b64encode(buf.getvalue()).decode())
    return imgs


def find_array_field(schema):
    """The single top-level array property, plus its resolved item schema."""
    defs = schema.get("$defs") or schema.get("definitions") or {}

    def resolve(node, depth=0):
        if depth > 6 or not isinstance(node, dict):
            return node
        if "$ref" in node:
            name = node["$ref"].split("/")[-1]
            return resolve(defs.get(name, {}), depth + 1)
        for comb in ("anyOf", "oneOf", "allOf"):
            if comb in node:
                for opt in node[comb]:
                    r = resolve(opt, depth + 1)
                    if isinstance(r, dict) and r.get("type") == "array":
                        return r
                return resolve(node[comb][0], depth + 1)
        return node

    arrays = []
    for name, prop in (schema.get("properties") or {}).items():
        r = resolve(prop)
        if isinstance(r, dict) and r.get("type") == "array":
            item = resolve(r.get("items") or {})
            desc = prop.get("description") or r.get("description") or ""
            arrays.append((name, item, desc))
    if not arrays:
        return None
    arrays.sort(key=lambda a: -len((a[1].get("properties") or {})))
    return arrays[0]


def find_all_arrays(schema):
    """Every top-level array property, largest record type first."""
    defs = schema.get("$defs") or schema.get("definitions") or {}
    out = []
    for name, prop in (schema.get("properties") or {}).items():
        a = find_array_field({"properties": {name: prop}, "$defs": defs})
        if a:
            out.append(a)
    out.sort(key=lambda a: -len((a[1].get("properties") or {})))
    return out


def scalar_fields(schema):
    names = {a[0] for a in find_all_arrays(schema)}
    return {k: v for k, v in (schema.get("properties") or {}).items() if k not in names}


def parse_json(text):
    if not text:
        return None
    m = re.search(r"```(?:json)?\s*(.*?)```", text, re.S)
    if m:
        text = m.group(1)
    for o, c in (("[", "]"), ("{", "}")):
        i, j = text.find(o), text.rfind(c)
        if i != -1 and j > i:
            try:
                return json.loads(text[i:j + 1])
            except json.JSONDecodeError:
                pass
    # salvage a truncated array: keep the objects that closed
    i = text.find("[")
    if i == -1:
        return None
    depth, last = 0, None
    for k in range(i, len(text)):
        if text[k] == "{":
            depth += 1
        elif text[k] == "}":
            depth -= 1
            if depth == 0:
                last = k
    if last is None:
        return None
    try:
        return json.loads(text[i:last + 1] + "]")
    except json.JSONDecodeError:
        return None


# Structured decoding was never active before this switch existed. vLLM 0.27.1 removed the
# `guided_json` request field in favour of `structured_outputs={"json": ...}`, and drops
# unknown fields without an error -- so every run in this directory until now decoded
# unconstrained, and the `required` / `$defs` / `maxItems` fixes documented in RESULTS.md
# never reached inference. That is why b30_clean, produced AFTER the `required` fix, still
# had no `unit`/`quantity` key on any sf1449 row. Verified directly: with `guided_json` the
# model wraps its answer in a ```json fence and omits required keys; with
# `structured_outputs` neither happens.
#
# EB_GUIDED=0 reproduces the old (unconstrained) behaviour exactly, for comparison.
import os as _os
GUIDED = _os.environ.get("EB_GUIDED", "1") != "0"


# Qwen3.8's chat template reasons by default (enable_thinking undefined -> true). For
# extraction over thousands of chunks that multiplies the tokens for no measured gain, so
# EB_NOTHINK=1 turns it off. Templates without the variable (Qwen3-VL) ignore it.
NOTHINK = _os.environ.get("EB_NOTHINK", "0") == "1"


# Under structured decoding a property the schema does not list as `required` may simply be
# left out, and the model does leave fields out -- a labelled requisition number, a vendor
# phone -- which the output stages later fill with null. DQ_REQUIRE_ALL=1 decodes with every
# property required and nullable, so each field gets an explicit value or an explicit null.
REQUIRE_ALL = _os.environ.get("DQ_REQUIRE_ALL", "0") == "1"


def _nullable(node):
    t = node.get("type")
    if "enum" in node and None not in node["enum"]:
        node["enum"] = list(node["enum"]) + [None]
    if "oneOf" in node and "anyOf" not in node:
        node["anyOf"] = node.pop("oneOf")
    if "anyOf" in node:
        if not any(isinstance(a, dict) and a.get("type") == "null" for a in node["anyOf"]):
            node["anyOf"] = list(node["anyOf"]) + [{"type": "null"}]
    elif isinstance(t, list):
        if "null" not in t:
            node["type"] = t + ["null"]
    elif isinstance(t, str) and t != "null":
        node["type"] = [t, "null"]
    elif "$ref" in node:
        ref = node.pop("$ref")
        node["anyOf"] = [{"$ref": ref}, {"type": "null"}]


def require_all(schema):
    """The decoding schema: every object property required, every added requirement nullable."""
    import copy
    s = copy.deepcopy(schema)

    def walk(node):
        if isinstance(node, dict):
            props = node.get("properties")
            if isinstance(props, dict) and props:
                had = set(node.get("required") or [])
                for k, v in props.items():
                    if k not in had and isinstance(v, dict):
                        _nullable(v)
                node["required"] = list(props.keys())
            for v in list(node.values()):
                walk(v)
        elif isinstance(node, list):
            for v in node:
                walk(v)
    walk(s)
    return s


def missing_keys(schema, obj):
    """How many schema properties the output leaves out (objects and array items, recursively).
    Observable without any annotation: under structured decoding a key that is not `required`
    can simply be skipped."""
    defs = schema.get("$defs") or schema.get("definitions") or {}

    def res(s, depth=0):
        while isinstance(s, dict) and "$ref" in s and depth < 20:
            s = defs.get(s["$ref"].split("/")[-1], {}); depth += 1
        if isinstance(s, dict) and "anyOf" in s:
            for a in s["anyOf"]:
                a = res(a, depth + 1)
                if isinstance(a, dict) and ("properties" in a or "items" in a):
                    return a
        return s

    def walk(s, o):
        s = res(s)
        if not isinstance(s, dict):
            return 0
        if isinstance(o, dict) and isinstance(s.get("properties"), dict):
            return sum(1 if k not in o else walk(v, o[k]) for k, v in s["properties"].items())
        if isinstance(o, list) and isinstance(s.get("items"), dict):
            return sum(walk(s["items"], x) for x in o)
        return 0
    return walk(schema, obj)


def extra_body(schema=None):
    eb = {}
    if schema and GUIDED:
        eb["structured_outputs"] = {"json": require_all(schema) if REQUIRE_ALL else schema}
    if NOTHINK:
        eb["chat_template_kwargs"] = {"enable_thinking": False}
    return eb


def ask(client, prompt, max_tokens=8000, schema=None, images=()):
    eb = extra_body(schema)
    kw = {"extra_body": eb} if eb else {}
    if images:
        content = [{"type": "image_url",
                    "image_url": {"url": f"data:image/jpeg;base64,{b}"}} for b in images]
        content.append({"type": "text", "text": prompt})
    else:
        content = prompt
    r = client.chat.completions.create(
        model=_S.MODEL, temperature=0.0, max_tokens=max_tokens,
        messages=[{"role": "user", "content": content}], **kw)
    ch = r.choices[0]
    return (ch.message.content, (r.usage.total_tokens if r.usage else 0),
            ch.finish_reason)


COLMAP_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "required": ["columns_left_to_right", "field_to_column", "absent_fields"],
    "properties": {
        "columns_left_to_right": {"type": "array", "maxItems": 40,
                                  "items": {"type": "string", "maxLength": 80}},
        "field_to_column": {"type": "object"},
        "absent_fields": {"type": "array", "maxItems": 40,
                          "items": {"type": "string", "maxLength": 80}},
    },
}


def build_colmap(client, pages, item_txt, char_cap):
    """
    Resolve schema fields to table columns once per document.

    Measured need: on the 13F cases the schema carries a `figi` field that has no column
    in the document, and the model slid every later value one column left -- `value` into
    `figi`, `shares` into `value`, 'SOLE' into `put_call`. Name/title/cusip stayed correct,
    so precision held at 84% while recall fell to 50%. Naming the columns once, and naming
    the fields that have no column, removes that shift for every chunk at the cost of one
    extra call per document.
    """
    # Pick the densest table page rather than a fixed position. Sampling at len/3 broke
    # dd1155, whose line items sit on only a few pages: that page held no rows, the mapper
    # declared every field absent, and the run returned 0 rows.
    order = sorted(range(len(pages)), key=lambda i: -row_density(pages[i]))
    if not order or row_density(pages[order[0]]) < 3:
        return "", 0, 0
    best = order[0]
    sample = "\n".join(pages[best:best + 2])[:char_cap // 2]
    try:
        txt, tk, _fr = ask(client, COLMAP_PROMPT.format(text=sample, item_schema=item_txt),
                      max_tokens=1500, schema=COLMAP_SCHEMA)
    except Exception:
        return "", 0, 0
    got = parse_json(txt)
    if not isinstance(got, dict):
        return "", 1, tk
    cols = [c for c in (got.get("columns_left_to_right") or []) if isinstance(c, str)]
    absent = [a for a in (got.get("absent_fields") or []) if isinstance(a, str)]
    f2c = got.get("field_to_column") or {}
    if not isinstance(f2c, dict):
        f2c = {}
    mapped = [k for k, v in f2c.items() if isinstance(k, str) and v]
    # Refuse a mapping that explains nothing or nulls the whole row: either is worse than
    # giving the model no mapping at all.
    try:
        n_fields = len(json.loads(item_txt).get("properties") or {})
    except Exception:
        n_fields = 0
    if not mapped or (n_fields and len(absent) >= n_fields):
        return "", 1, tk
    lines = []
    if cols:
        lines.append("The table's columns, left to right, are: " + " | ".join(cols) + ".")
    pairs = [f"{k} <- {f2c[k]}" for k in mapped]
    if pairs:
        lines.append("Take each field from its column: " + "; ".join(pairs) + ".")
    absent = [a for a in absent if a not in mapped]
    if absent:
        lines.append("These fields have NO column in this document and must always be "
                     "null: " + ", ".join(absent) + ".")
    return (("\n".join(lines) + "\n\n") if lines else ""), 1, tk


def run_case(client, rec, pages_per_chunk, workers, char_cap, map_columns=True,
             use_header=True):
    schema = rec["data_schema"]
    pdf = DATA / "docs" / rec["pdf"].replace("docs/", "", 1)
    pages = page_texts(pdf)
    # ExtractBench's long split includes image-only PDFs (the *_corrupted cases): pdftotext
    # returns one character per page for those, and a text-only pipeline scored 0 on 3 of
    # 20 cases. Fall back to rendering the pages and reading them with the VLM.
    text_chars = sum(len(p.strip()) for p in pages)
    image_mode = text_chars < 50 * max(1, len(pages))
    arr = find_array_field(schema)
    result, n_calls, n_tok = {}, 0, 0

    # ---- scalar header fields: first two and last page are enough here ----
    sc = scalar_fields(schema)
    if sc:
        head_imgs = ()
        if image_mode:
            try:
                head_imgs = tuple(page_images(pdf, 1, 2))
            except Exception:
                head_imgs = ()
            head = "(no extractable text; read the attached page images instead)"
        else:
            head = "\n".join(pages[:2] + ([pages[-1]] if len(pages) > 2 else []))[:char_cap]
        try:
            txt, tk, _fr = ask(client, SCALAR_PROMPT.format(
                text=head, scalar_schema=json.dumps(sc, indent=1)[:6000]),
                max_tokens=1500, images=head_imgs)
            n_calls += 1
            n_tok += tk
            got = parse_json(txt)
            if isinstance(got, dict):
                result.update({k: v for k, v in got.items() if k in sc})
        except Exception as e:
            print(f"    ! scalars {rec['id']}: {type(e).__name__}", flush=True)

    if not arr:
        return result, n_calls, n_tok, 0

    arr_name, item_schema, arr_desc = arr
    item_txt = json.dumps(item_schema, indent=1)[:4000]
    # Carry only the HEADER LINES of the first page into every chunk.
    #
    # These documents print the column header once, so a chunk from page 40 sees bare rows:
    # on the 13F filings the model then slid every numeric field one column left, because
    # FIGI and PUT/CALL are named in the header but blank in every row (precision 84,
    # recall 50). Carrying the *whole* first page was worse still (F1 62.7 -> 37.8): page 1
    # also holds data rows, and the model re-emitted them in every chunk, inflating 3,063
    # gold rows to 3,999 predicted. So the page is cut at its first real data row.
    header_block = ""
    if use_header and pages and pages[0].strip():
        lines = pages[0].splitlines()
        cut = next((i for i, ln in enumerate(lines) if _is_row_line(ln)), len(lines))
        head = "\n".join(lines[:cut])[:5000]
        if head.strip():
            header_block = ("--- COLUMN HEADERS (reference only; these lines come from the "
                            "document's header and contain NO data rows -- never extract a "
                            "row from this block). Column positions are preserved, so line "
                            "each value up under its own column, and leave a field null "
                            "when its column is blank for that row ---\n%s\n"
                            "--- END COLUMN HEADERS ---\n\n" % head)

    colmap = ""
    if map_columns:
        colmap, c, t = build_colmap(client, pages, item_txt, char_cap)
        n_calls += c
        n_tok += t
    array_schema = {"type": "array", "maxItems": 400,
                    "items": item_schema if item_schema.get("properties") else {"type": "object"}}

    chunks = [(i, min(i + pages_per_chunk, len(pages)))
              for i in range(0, len(pages), pages_per_chunk)]
    rows_by_chunk = [None] * len(chunks)
    lock = threading.Lock()
    stat = {"calls": 0, "tok": 0}

    def do_chunk(ci):
        lo, hi = chunks[ci]
        imgs = ()
        if image_mode:
            try:
                imgs = tuple(page_images(pdf, lo + 1, hi))
            except Exception as e:
                print(f"    ! render {rec['id']} p{lo+1}-{hi}: {type(e).__name__}", flush=True)
            text = "(no extractable text; read the attached page images instead)"
        else:
            text = "\n".join(pages[lo:hi])[:char_cap]
            if not text.strip():
                rows_by_chunk[ci] = []
                return
        try:
            txt, tk, _fr = ask(client, ARRAY_PROMPT.format(
                p0=lo + 1, p1=hi, text=text, item_schema=item_txt,
                array_name=arr_name,
                array_desc=((f"TASK\n{(schema.get('description') or '').strip()}\n\n"
                             if (schema.get("description") or "").strip() else "")
                            + ((arr_desc + "\n") if arr_desc else "")),
                colmap=colmap, header=header_block),
                max_tokens=12000, schema=array_schema, images=imgs)
        except Exception as e:
            print(f"    ! chunk {rec['id']} p{lo+1}-{hi}: {type(e).__name__}", flush=True)
            rows_by_chunk[ci] = []
            return
        got = parse_json(txt)
        rows = [r for r in got if isinstance(r, dict)] if isinstance(got, list) else []
        with lock:
            stat["calls"] += 1
            stat["tok"] += tk
        rows_by_chunk[ci] = rows

    with ThreadPoolExecutor(max_workers=workers) as ex:
        list(ex.map(do_chunk, range(len(chunks))))

    rows = [r for part in rows_by_chunk for r in (part or [])]
    result[arr_name] = rows
    return result, n_calls + stat["calls"], n_tok + stat["tok"], len(chunks)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", required=True)
    ap.add_argument("--pages-per-chunk", type=int, default=2)
    ap.add_argument("--workers", type=int, default=24)
    ap.add_argument("--char-cap", type=int, default=60000)
    ap.add_argument("--only", default="")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--no-colmap", action="store_true",
                    help="ablation: skip the column-mapping pass")
    ap.add_argument("--no-header", action="store_true",
                    help="ablation: do not carry column headers into each chunk")
    args = ap.parse_args()

    recs = [json.loads(l) for l in (DATA / "long.jsonl").open() if l.strip()]
    for r in recs:
        for k in ("data_schema", "expected_output", "field_rules", "repeated_structure"):
            if isinstance(r.get(k), str):
                r[k] = json.loads(r[k])
    if args.only:
        want = set(args.only.split(","))
        recs = [r for r in recs if r["id"] in want or r["id"].split("/")[-1] in want]
    if args.limit:
        recs = recs[: args.limit]

    client = OpenAI(base_url=BASE_URL, api_key="EMPTY", timeout=1800, max_retries=4)
    outdir = _S.RUNS / args.tag
    outdir.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    for rec in recs:
        ts = time.time()
        pred, calls, tok, nch = run_case(client, rec, args.pages_per_chunk,
                                         args.workers, args.char_cap,
                                         map_columns=not args.no_colmap,
                                         use_header=not args.no_header)
        arr = find_array_field(rec["data_schema"])
        gold_n = len(rec["expected_output"].get(arr[0], [])) if arr else 0
        pred_n = len(pred.get(arr[0], [])) if arr else 0
        (outdir / (rec["id"].split("/")[-1] + ".json")).write_text(json.dumps(pred))
        print(f"  {rec['id'].split('/')[-1][:42]:42s} chunks={nch:4d} calls={calls:4d} "
              f"rows={pred_n:6d} gold={gold_n:6d} {time.time()-ts:6.0f}s", flush=True)
    print(f"TOTAL {time.time()-t0:.0f}s")


if __name__ == "__main__":
    main()

def array_schema(item_guide, root_schema=None, **bounds):
    """A constrained-decoding schema for a list of items.

    Defect 13: the item's definitions were nested INSIDE "items", but "$ref": "#/$defs/X"
    resolves from the schema ROOT, so every reference dangled and the grammar compiler
    failed (HTTP 500 on every chunk of census_statab). Definitions are hoisted to the root,
    under the name the original schema uses ("$defs" or "definitions") so its references
    still resolve."""
    items = {k: v for k, v in item_guide.items() if k not in ("$defs", "definitions")}
    out = {"type": "array", **bounds, "items": items}
    src = root_schema or item_guide
    for key in ("$defs", "definitions"):
        if src.get(key):
            out[key] = src[key]
    return out

